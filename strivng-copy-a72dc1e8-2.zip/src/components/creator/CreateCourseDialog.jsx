import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Loader2, UploadCloud, User } from 'lucide-react';
import { Combobox } from '@/components/ui/combobox';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const categoryOptions = [
    { value: "Technology", label: "Technology" },
    { value: "Science", label: "Science" },
    { value: "Arts", label: "Arts" },
    { value: "Business", label: "Business" },
    { value: "Health", label: "Health" },
    { value: "Math", label: "Math" },
    { value: "History", label: "History" },
    { value: "Engineering", label: "Engineering" },
    { value: "Literature", label: "Literature" },
    { value: "Music", label: "Music" },
];
const languages = ["English", "Cantonese", "Mandarin", "Spanish"];
const educationLevels = ["High School", "Undergraduate", "Postgraduate", "Professional"];
const educationSystems = ["General", "HKDSE", "IB", "GCE A-Level", "SAT/AP"];

export default function CreateCourseDialog({ user, setDialogOpen }) {
    const [details, setDetails] = useState({
        title: '',
        description: '',
        thumbnail_url: '',
        category: 'Technology',
        price: 0,
        language: 'English',
        education_level: 'Undergraduate',
        education_system: 'General',
    });
    const [thumbnailFile, setThumbnailFile] = useState(null);
    const queryClient = useQueryClient();

    const mutation = useMutation({
        mutationFn: async (courseData) => {
            let finalData = { ...courseData };
            if (thumbnailFile) {
                const { file_url } = await base44.integrations.Core.UploadFile({ file: thumbnailFile });
                finalData.thumbnail_url = file_url;
            }
            return base44.entities.Course.create(finalData);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['createdCourses', user.email] });
            queryClient.invalidateQueries({ queryKey: ['courses'] }); // To refresh EduTube
            setDialogOpen(false);
        }
    });

    const handleSave = () => {
        if (!details.title) {
            alert("Please enter a title for the course.");
            return;
        }
        const payload = {
            ...details,
            creator_name: user.full_name || user.email,
            creator_avatar_url: user.avatar_url || '',
        };
        mutation.mutate(payload);
    };

    const handleDetailChange = (key, value) => {
        setDetails(prev => ({ ...prev, [key]: value }));
    };

    return (
        <DialogContent className="max-w-2xl">
            <DialogHeader>
                <DialogTitle>Create New Course</DialogTitle>
                <DialogDescription>
                    Fill in the essential details for your course. It will be public on EduTube immediately after creation. You can add lessons and other content later.
                </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
                 <div className="flex items-center gap-6">
                    <Avatar className="w-24 h-24 rounded-lg">
                        <AvatarImage src={thumbnailFile ? URL.createObjectURL(thumbnailFile) : ''} className="object-cover" />
                        <AvatarFallback className="rounded-lg bg-gray-100">
                           <UploadCloud className="w-8 h-8 text-gray-400"/>
                        </AvatarFallback>
                    </Avatar>
                    <div className="grid w-full max-w-sm items-center gap-1.5">
                        <Label htmlFor="thumbnail-upload">Course Thumbnail</Label>
                        <Input id="thumbnail-upload" type="file" accept="image/*" onChange={(e) => setThumbnailFile(e.target.files[0])} />
                         <p className="text-xs text-gray-500">Upload a thumbnail image for your course.</p>
                    </div>
                </div>

                <div>
                    <Label htmlFor="title">Title</Label>
                    <Input id="title" value={details.title} onChange={e => handleDetailChange('title', e.target.value)} />
                </div>
                <div>
                    <Label htmlFor="description">Introduction (Description)</Label>
                    <Textarea id="description" value={details.description} onChange={e => handleDetailChange('description', e.target.value)} />
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                     <div>
                        <Label>Category</Label>
                        <Combobox
                            options={categoryOptions}
                            value={details.category}
                            onChange={v => handleDetailChange('category', v)}
                            placeholder="Select category..."
                            creatable={true}
                        />
                    </div>
                    <Select value={details.language} onValueChange={v => handleDetailChange('language', v)}>
                         <Label>Language</Label>
                        <SelectTrigger><SelectValue placeholder="Language"/></SelectTrigger>
                        <SelectContent>{languages.map(c=><SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                    <Select value={details.education_level} onValueChange={v => handleDetailChange('education_level', v)}>
                        <Label>Education Level</Label>
                        <SelectTrigger><SelectValue placeholder="Education Level"/></SelectTrigger>
                        <SelectContent>{educationLevels.map(c=><SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                    <Select value={details.education_system} onValueChange={v => handleDetailChange('education_system', v)}>
                         <Label>Education System</Label>
                        <SelectTrigger><SelectValue placeholder="Education System"/></SelectTrigger>
                        <SelectContent>{educationSystems.map(c=><SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                    <div>
                        <Label htmlFor="price">Price ($)</Label>
                        <Input id="price" type="number" value={details.price} onChange={e => handleDetailChange('price', parseFloat(e.target.value) || 0)} placeholder="Price" />
                    </div>
                </div>
            </div>
            <DialogFooter>
                <Button variant="ghost" onClick={() => setDialogOpen(false)}>Cancel</Button>
                <Button onClick={handleSave} disabled={mutation.isPending}>
                    {mutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : null}
                    Create Course
                </Button>
            </DialogFooter>
        </DialogContent>
    )
}