
import React, { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { X, Send, Loader2, RefreshCw, History, Maximize2, Minimize2, ChevronLeft, ChevronRight, Trash2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import ReactMarkdown from 'react-markdown';
import { format } from 'date-fns';
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const MessageBubble = React.memo(({ message }) => {
  const isUser = message.role === 'user';

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className={cn(
          "max-w-[85%] rounded-xl px-4 py-3 shadow-md backdrop-blur-xl border transition-all",
          isUser
            ? "bg-gradient-to-r from-orange-400 to-amber-500 text-white border-white/20"
            : "bg-white/80 text-gray-800 border-white/30"
        )}
      >
        {isUser ? (
          <p className="text-sm">{message.content}</p>
        ) : message.content === null || message.content === undefined ? (
          <Loader2 className="h-5 w-5 animate-spin text-orange-500" />
        ) : (
          <ReactMarkdown className="prose prose-sm max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
            {message.content || ""}
          </ReactMarkdown>
        )}
      </div>
    </div>
  );
});

MessageBubble.displayName = 'MessageBubble';

export default function StudyAgent({ deckContext = null, onClose = null }) {
  const [isOpen, setIsOpen] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [error, setError] = useState(null);
  const [showHistorySidebar, setShowHistorySidebar] = useState(false);
  const [isFirstMessage, setIsFirstMessage] = useState(true);
  const [isInitializing, setIsInitializing] = useState(false);
  const messagesEndRef = useRef(null);
  const queryClient = useQueryClient();
  const retryCount = useRef(0);
  const maxRetries = 2;

  const { data: conversationHistory = [] } = useQuery({
    queryKey: ['conversationHistory', 'study_scheduler'],
    queryFn: async () => {
      const conversations = await base44.agents.listConversations({ agent_name: 'study_scheduler' });
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      return conversations.filter(conv => new Date(conv.created_date) > thirtyDaysAgo);
    },
    enabled: isOpen,
    staleTime: 60000,
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    if (deckContext) setIsOpen(true);
  }, [deckContext]);

  useEffect(() => {
    if (isOpen && !conversation && !isInitializing) {
      const initConversation = async () => {
        setIsInitializing(true);
        setError(null);

        try {
          const conv = await base44.agents.createConversation({ agent_name: 'study_scheduler' });
          if (conv?.id) {
            setConversation(conv);
            setMessages(Array.isArray(conv.messages) ? conv.messages : []);
            setIsFirstMessage(true);
            retryCount.current = 0;
            setIsInitializing(false);
          } else {
            throw new Error("Invalid conversation response");
          }
        } catch (error) {
          if (retryCount.current < maxRetries) {
            retryCount.current += 1;
            toast.info(`Retrying... (${retryCount.current}/${maxRetries})`, { id: 'agent-retry', duration: 1000 });
            setTimeout(() => setIsInitializing(false), 1000 * retryCount.current);
          } else {
            setError("Unable to connect. Please try again.");
            toast.error("Connection failed", { id: 'agent-retry' });
            setIsInitializing(false);
          }
        }
      };

      initConversation();
    }
  }, [isOpen, conversation, isInitializing]);

  useEffect(() => {
    if (!conversation?.id) return;

    try {
      const unsubscribe = base44.agents.subscribeToConversation(conversation.id, (data) => {
        if (data?.messages && Array.isArray(data.messages)) {
          setMessages(data.messages);
          setError(null);

          if (data.status !== 'in_progress') {
            queryClient.invalidateQueries({ queryKey: ['goals'] });
            queryClient.invalidateQueries({ queryKey: ['studyHubDailyHours'] });
          }
        }
      });

      return () => unsubscribe?.();
    } catch (error) {
      setError("Connection issue. Messages may not update in real-time.");
    }
  }, [conversation?.id, queryClient]);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(scrollToBottom, [messages, scrollToBottom]);

  const handleLoadConversation = useCallback(async (conv) => {
    try {
      setError(null);
      setShowHistorySidebar(false);
      const fullConv = await base44.agents.getConversation(conv.id);
      if (fullConv?.id) {
        setConversation(fullConv);
        setMessages(Array.isArray(fullConv.messages) ? fullConv.messages : []);
        setIsFirstMessage(false);
      }
    } catch (error) {
      setError("Failed to load conversation. Please try again.");
      toast.error("Failed to load conversation");
    }
  }, []);

  const handleResetChat = useCallback(async () => {
    try {
      setError(null);
      setIsInitializing(true);
      const conv = await base44.agents.createConversation({ agent_name: 'study_scheduler' });
      if (conv?.id) {
        setConversation(conv);
        setMessages(Array.isArray(conv.messages) ? conv.messages : []);
        setInput("");
        setIsFirstMessage(true);
        queryClient.invalidateQueries({ queryKey: ['conversationHistory'] });
        toast.success("New chat started");
      } else {
        throw new Error("Invalid conversation response");
      }
    } catch (error) {
      setError("Failed to start new chat. Please try again.");
      toast.error("Failed to start new chat");
    } finally {
      setIsInitializing(false);
    }
  }, [queryClient]);

  const handleClearHistory = useCallback(() => {
    queryClient.invalidateQueries({ queryKey: ['conversationHistory'] });
    setShowHistorySidebar(false);
    toast.success("Conversation history cleared from display");
  }, [queryClient]);

  const handleSend = useCallback(async () => {
    if (!input.trim() || !conversation) return;

    let userMessage = input.trim();

    if (isFirstMessage && deckContext) {
      const contextInfo = `[Context: I'm studying "${deckContext.title}". ${
        deckContext.summary ? `Summary: ${deckContext.summary.summary.substring(0, 200)}... ` : ''
      }${
        deckContext.flashcards?.cards ? `It has ${deckContext.flashcards.cards.length} flashcards.` : ''
      }]

My question: ${userMessage}`;

      userMessage = contextInfo;
      setIsFirstMessage(false);
    }

    setInput("");
    setError(null);

    const optimisticMessages = [
      ...messages,
      { role: "user", content: userMessage },
      { role: 'assistant', content: null }
    ];
    setMessages(optimisticMessages);

    try {
      await base44.agents.addMessage(conversation, {
        role: "user",
        content: userMessage,
      });
    } catch (error) {
      const errorMsg = error?.message || "Failed to send message";
      setError(`Message error: ${errorMsg}`);
      toast.error("Failed to send message");
      setMessages(prev => prev.slice(0, -2));
    }
  }, [input, conversation, isFirstMessage, deckContext, messages]);

  const handleKeyDown = useCallback((e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }, [handleSend]);

  const handleClose = useCallback(() => {
    setIsOpen(false);
    setIsFullScreen(false);
    setShowHistorySidebar(false);
    setConversation(null);
    setMessages([]);
    setError(null);
    retryCount.current = 0;
    onClose?.();
  }, [onClose]);

  const isAgentThinking = useMemo(() =>
    messages.length > 0 &&
    messages[messages.length - 1].role === 'assistant' &&
    messages[messages.length - 1].content === null
  , [messages]);

  const getConversationTitle = useCallback((conv) => {
    if (conv.metadata?.name) return conv.metadata.name;
    const firstUserMessage = conv.messages?.find(m => m.role === 'user');
    const title = firstUserMessage?.content?.substring(0, 50) || 'Untitled Conversation';
    return title.length === 50 ? title + '...' : title;
  }, []);

  const displayMessages = useMemo(() =>
    messages.map(msg => {
      if (msg.role === 'user' && msg.content?.startsWith('[Context:')) {
        const questionStart = msg.content.indexOf('My question:');
        if (questionStart !== -1) {
          return { ...msg, content: msg.content.substring(questionStart + 12).trim() };
        }
      }
      return msg;
    })
  , [messages]);

  const placeholderText = useMemo(() =>
    deckContext
      ? `Ask about "${deckContext.title}"...`
      : "Schedule a study goal..."
  , [deckContext]);

  if (deckContext && !isOpen) return null;

  const ChatWindow = ({ className = "" }) => (
    <Card className={cn("overflow-hidden shadow-2xl border-white/20 backdrop-blur-2xl bg-white/70 flex flex-col", className)}>
      <div className="bg-gradient-to-r from-orange-400 to-amber-500 p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {!showHistorySidebar && isFullScreen && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowHistorySidebar(true)}
              className="text-white hover:bg-white/20"
              title="Show history"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          )}
          <img
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ead5d076c2b7a3765c1ee0/ab4d088ff_PHOTO-2025-10-08-15-31-34.jpg"
            alt="Strive"
            className={cn("rounded-full shadow-lg", isFullScreen ? "w-6 h-6" : "w-5 h-5")}
          />
          <h3 className={cn("font-semibold text-white", isFullScreen ? "text-lg" : "")}>
            Strive {deckContext && `- ${deckContext.title}`}
          </h3>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleResetChat}
            className={cn("text-white hover:bg-white/20", isFullScreen ? "h-9 w-9" : "h-8 w-8")}
            title="Start new chat"
            disabled={!conversation || isInitializing}
          >
            <RefreshCw className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsFullScreen(!isFullScreen)}
            className={cn("text-white hover:bg-white/20", isFullScreen ? "h-9 w-9" : "h-8 w-8")}
            title={isFullScreen ? "Exit full screen" : "Full screen"}
          >
            {isFullScreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleClose}
            className={cn("text-white hover:bg-white/20", isFullScreen ? "h-9 w-9" : "h-8 w-8")}
            title="Close"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className={cn("overflow-y-auto space-y-4 bg-gradient-to-b from-orange-50/40 to-amber-50/40 flex-1", isFullScreen ? "p-6" : "p-4")}>
        {error && (
          <div className="backdrop-blur-xl bg-red-50/90 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm shadow-lg">
            <p className="font-semibold mb-1">Connection Error</p>
            <p>{error}</p>
            <Button
              size="sm"
              variant="outline"
              className="mt-2"
              onClick={() => {
                setError(null);
                setConversation(null);
                setIsInitializing(false);
              }}
            >
              Try Again
            </Button>
          </div>
        )}

        {(!conversation || isInitializing) && !error && (
          <div className="flex flex-col items-center justify-center h-full">
            <Loader2 className={cn("animate-spin text-orange-500 mb-3", isFullScreen ? "w-10 h-10" : "w-8 h-8")} />
            <p className={cn("text-gray-600", isFullScreen ? "" : "text-sm")}>Connecting to Strive...</p>
          </div>
        )}

        {conversation && messages.length === 0 && deckContext && !isInitializing && (
          <div className={cn("backdrop-blur-xl bg-orange-100/90 border border-orange-200 rounded-xl text-sm shadow-lg", isFullScreen ? "p-5" : "p-4")}>
            <p className="font-semibold text-orange-800 mb-2">📚 Ready to help with "{deckContext.title}"</p>
            <p className="text-orange-700">Ask me anything about this deck!</p>
          </div>
        )}

        {conversation && displayMessages.map((msg, index) => (
          <MessageBubble key={`${msg.role}-${index}`} message={msg} />
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div className={cn("border-t border-white/20 backdrop-blur-xl bg-white/80", isFullScreen ? "p-4" : "p-4")}>
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={placeholderText}
            className={cn("flex-grow px-4 border border-orange-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-300 backdrop-blur-sm bg-white/90 transition-all", isFullScreen ? "py-3" : "py-2 text-sm")}
            disabled={isAgentThinking || !conversation || isInitializing}
          />
          <Button
            onClick={handleSend}
            className={cn("bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white rounded-xl shadow-lg", isFullScreen ? "px-6" : "")}
            disabled={isAgentThinking || !input.trim() || !conversation || isInitializing}
          >
            {isAgentThinking ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </div>
      </div>
    </Card>
  );

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <>
            {isFullScreen ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-50 bg-gradient-to-br from-orange-50/95 via-amber-50/95 to-orange-100/95 backdrop-blur-xl"
              >
                <div className="flex h-full">
                  {showHistorySidebar && (
                    <div className="w-80 border-r border-white/20 backdrop-blur-2xl bg-white/70 flex flex-col shadow-xl">
                      <div className="p-4 border-b bg-white flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <History className="w-5 h-5 text-gray-600" />
                          <h3 className="font-semibold text-gray-800">History</h3>
                        </div>
                        <div className="flex items-center gap-1">
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-red-500" title="Clear history">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Clear Conversation History?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will remove all conversations from your displayed history.
                                  Please note, this only clears the display; conversations are not permanently deleted from the server.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={handleClearHistory} className="bg-red-500 hover:bg-red-600 text-white">
                                  Clear History
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                          <Button variant="ghost" size="icon" onClick={() => setShowHistorySidebar(false)} className="h-8 w-8" title="Hide history">
                            <ChevronLeft className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex-1 overflow-y-auto p-3">
                        {conversationHistory.length === 0 ? (
                          <p className="text-xs text-gray-500 text-center py-8">No conversation history yet</p>
                        ) : (
                          <div className="space-y-1">
                            {conversationHistory.map((conv) => (
                              <div
                                key={conv.id}
                                className={cn(
                                  "rounded-lg transition-colors cursor-pointer p-3",
                                  conversation?.id === conv.id ? "bg-orange-100 border border-orange-200" : "hover:bg-gray-100"
                                )}
                                onClick={() => handleLoadConversation(conv)}
                              >
                                <p className="text-sm font-medium text-gray-800 truncate">{getConversationTitle(conv)}</p>
                                <p className="text-xs text-gray-500 mt-1">{format(new Date(conv.created_date), 'MMM d, yyyy')}</p>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="flex-1 flex flex-col">
                    <ChatWindow className="h-full rounded-none" />
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                transition={{ duration: 0.2 }}
                className="fixed bottom-24 right-6 z-50 w-[500px] max-w-[calc(100vw-3rem)] h-[600px]"
              >
                <ChatWindow className="h-full rounded-2xl" />
              </motion.div>
            )}
          </>
        )}
      </AnimatePresence>

      {!isFullScreen && !deckContext && (
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsOpen(!isOpen)}
          className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-gradient-to-r from-orange-400 to-amber-500 rounded-full shadow-2xl flex items-center justify-center hover:shadow-xl transition-all duration-300 overflow-hidden backdrop-blur-sm"
          title={isOpen ? "Close Strive Chat" : "Open Strive Chat"}
        >
          {isOpen ? (
            <X className="w-6 h-6 text-white" />
          ) : (
            <img
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ead5d076c2b7a3765c1ee0/ab4d088ff_PHOTO-2025-10-08-15-31-34.jpg"
              alt="Strive"
              className="w-8 h-8 rounded-full shadow-md"
            />
          )}
        </motion.button>
      )}
    </>
  );
}
