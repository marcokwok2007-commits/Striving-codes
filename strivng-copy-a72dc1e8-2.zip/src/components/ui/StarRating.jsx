import React from 'react';
import { Star } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function StarRating({ rating = 0, count = null, onRate, size = 'md', interactive = true }) {
  const starSizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6',
  };

  const stars = Array.from({ length: 5 }, (_, i) => i + 1);

  return (
    <div className="flex items-center gap-2">
      <div className={cn("flex items-center", interactive && "cursor-pointer")}>
        {stars.map((star) => (
          <Star
            key={star}
            className={cn(
              starSizeClasses[size],
              star <= Math.round(rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300',
              interactive && 'hover:scale-125 transition-transform'
            )}
            onClick={interactive ? () => onRate(star) : undefined}
          />
        ))}
      </div>
      {count !== null && (
        <span className="text-sm text-gray-500">({count})</span>
      )}
    </div>
  );
}