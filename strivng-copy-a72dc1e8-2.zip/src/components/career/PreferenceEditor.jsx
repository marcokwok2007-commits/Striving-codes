import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { DialogFooter, DialogHeader, DialogTitle, DialogDescription, DialogContent } from '@/components/ui/dialog';
import { X, Search } from 'lucide-react';

const opportunityTypes = ["internship", "competition", "job", "scholarship", "research", "hackathon", "fellowship", "part-time", "full-time", "volunteer", "workshop"];

export default function PreferenceEditor({ initialPreferences, onSave, onCancel }) {
    const [prefs, setPrefs] = useState(initialPreferences);
    const [searchTerm, setSearchTerm] = useState('');

    const handleTypeChange = (type) => {
        const newTypes = prefs.types.includes(type)
            ? prefs.types.filter(t => t !== type)
            : [...prefs.types, type];
        setPrefs({ ...prefs, types: newTypes });
    };
    
    const handleSave = () => {
        onSave(prefs);
    }

    const filteredTypes = opportunityTypes.filter(type => 
        type.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <DialogContent className="max-w-md">
            <DialogHeader>
                <DialogTitle>Edit Search Preferences</DialogTitle>
                <DialogDescription>
                    Customize the criteria for your opportunity search.
                </DialogDescription>
            </DialogHeader>
            <div className="grid gap-6 py-4">
                <div className="grid gap-2">
                    <Label htmlFor="disciplines">Disciplines & Interests</Label>
                    <Input
                        id="disciplines"
                        value={prefs.disciplines}
                        onChange={e => setPrefs({ ...prefs, disciplines: e.target.value })}
                        placeholder="e.g., machine learning, product design"
                    />
                </div>
                <div className="grid gap-2">
                    <Label htmlFor="locations">Locations</Label>
                    <Input
                        id="locations"
                        value={prefs.locations}
                        onChange={e => setPrefs({ ...prefs, locations: e.target.value })}
                        placeholder="e.g., remote, New York"
                    />
                </div>
                <div className="grid gap-2">
                    <Label>Opportunity Types</Label>
                     <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"/>
                        <Input 
                            placeholder="Search types..."
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className="pl-10 mb-2"
                        />
                    </div>
                    <div className="flex flex-wrap gap-x-4 gap-y-2 max-h-32 overflow-y-auto pr-2">
                        {filteredTypes.map(type => (
                            <div key={type} className="flex items-center space-x-2">
                                <Checkbox
                                    id={`type-${type}`}
                                    checked={prefs.types.includes(type)}
                                    onCheckedChange={() => handleTypeChange(type)}
                                />
                                <Label htmlFor={`type-${type}`} className="font-normal capitalize">{type}</Label>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
            <DialogFooter>
                <Button variant="ghost" onClick={onCancel}>Cancel</Button>
                <Button onClick={handleSave}>Save Preferences</Button>
            </DialogFooter>
        </DialogContent>
    );
}