import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize, Minimize } from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import { cn } from '@/lib/utils';

export default function CustomVideoPlayer({ src }) {
    const videoRef = useRef(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [progress, setProgress] = useState(0);
    const [volume, setVolume] = useState(1);
    const [isMuted, setIsMuted] = useState(false);
    const [duration, setDuration] = useState(0);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const [showControls, setShowControls] = useState(true);
    const containerRef = useRef(null);
    let controlsTimeout = useRef(null);

    const formatTime = (timeInSeconds) => {
        const minutes = Math.floor(timeInSeconds / 60);
        const seconds = Math.floor(timeInSeconds % 60);
        return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    };

    const handlePlayPause = () => {
        if (isPlaying) {
            videoRef.current.pause();
        } else {
            videoRef.current.play();
        }
        setIsPlaying(!isPlaying);
    };

    const handleTimeUpdate = () => {
        const currentProgress = (videoRef.current.currentTime / videoRef.current.duration) * 100;
        setProgress(currentProgress);
    };

    const handleSeek = (value) => {
        const seekTime = (value / 100) * duration;
        videoRef.current.currentTime = seekTime;
        setProgress(value);
    };
    
    const handleVolumeChange = (value) => {
        const newVolume = value[0];
        videoRef.current.volume = newVolume;
        setVolume(newVolume);
        if (newVolume > 0 && isMuted) {
            setIsMuted(false);
            videoRef.current.muted = false;
        }
    };

    const toggleMute = () => {
        videoRef.current.muted = !isMuted;
        setIsMuted(!isMuted);
        if (!isMuted && volume === 0) setVolume(1);
    };

    const toggleFullscreen = () => {
        if (!document.fullscreenElement) {
            containerRef.current.requestFullscreen();
            setIsFullscreen(true);
        } else {
            document.exitFullscreen();
            setIsFullscreen(false);
        }
    };
    
    useEffect(() => {
        const video = videoRef.current;
        if (video) {
            const setVideoDuration = () => setDuration(video.duration);
            video.addEventListener('loadedmetadata', setVideoDuration);
            return () => video.removeEventListener('loadedmetadata', setVideoDuration);
        }
    }, []);

    useEffect(() => {
        const handleFullscreenChange = () => {
            setIsFullscreen(!!document.fullscreenElement);
        };
        document.addEventListener('fullscreenchange', handleFullscreenChange);
        return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
    }, []);

    const handleMouseMove = () => {
        setShowControls(true);
        clearTimeout(controlsTimeout.current);
        controlsTimeout.current = setTimeout(() => setShowControls(false), 3000);
    };

    return (
        <div 
            ref={containerRef}
            className="relative w-full aspect-video bg-black rounded-lg group overflow-hidden"
            onMouseMove={handleMouseMove}
            onMouseLeave={() => clearTimeout(controlsTimeout.current)}
        >
            <video
                ref={videoRef}
                src={src}
                className="w-full h-full"
                onClick={handlePlayPause}
                onTimeUpdate={handleTimeUpdate}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
            />
            <div 
                className={cn(
                    "absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/60 to-transparent transition-opacity duration-300",
                    showControls || !isPlaying ? "opacity-100" : "opacity-0"
                )}
            >
                <div className="flex items-center gap-4 text-white">
                    <button onClick={handlePlayPause}>
                        {isPlaying ? <Pause size={20} /> : <Play size={20} />}
                    </button>

                    <div className="flex-grow flex items-center gap-2">
                        <span className="text-xs font-mono">{formatTime(videoRef.current?.currentTime || 0)}</span>
                        <Slider
                            value={[progress]}
                            onValueChange={(v) => handleSeek(v[0])}
                            className="w-full"
                        />
                        <span className="text-xs font-mono">{formatTime(duration)}</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                         <button onClick={toggleMute}>
                            {isMuted || volume === 0 ? <VolumeX size={20} /> : <Volume2 size={20} />}
                        </button>
                        <Slider 
                            value={[isMuted ? 0 : volume]} 
                            onValueChange={handleVolumeChange} 
                            max={1} 
                            step={0.1} 
                            className="w-20"
                        />
                    </div>
                   
                    <button onClick={toggleFullscreen}>
                        {isFullscreen ? <Minimize size={20}/> : <Maximize size={20} />}
                    </button>
                </div>
            </div>
        </div>
    );
}