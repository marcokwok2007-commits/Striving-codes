import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Search } from 'lucide-react';

const categories = ["All", "Technology", "Science", "Arts", "Business", "Health", "Math"];
const languages = ["All", "English", "Cantonese", "Mandarin", "Spanish"];
const educationLevels = ["All", "High School", "Undergraduate", "Postgraduate", "Professional"];
const educationSystems = ["All", "General", "HKDSE", "IB", "GCE A-Level", "SAT/AP"];

export default function FilterBar({ filters, onFilterChange }) {
  
  const handleSelectChange = (key, value) => {
    onFilterChange(key, value === 'All' ? '' : value);
  };
  
  return (
    <div className="mb-8 p-4 bg-gray-50 rounded-xl border">
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <Input 
          placeholder="Search for courses..."
          value={filters.searchTerm}
          onChange={e => onFilterChange('searchTerm', e.target.value)}
          className="pl-10"
        />
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        <Select onValueChange={(value) => handleSelectChange('category', value)} value={filters.category || 'All'}>
          <SelectTrigger><SelectValue placeholder="Category" /></SelectTrigger>
          <SelectContent>
            {categories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select onValueChange={(value) => handleSelectChange('language', value)} value={filters.language || 'All'}>
          <SelectTrigger><SelectValue placeholder="Language" /></SelectTrigger>
          <SelectContent>
            {languages.map(l => <SelectItem key={l} value={l}>{l}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select onValueChange={(value) => handleSelectChange('education_level', value)} value={filters.education_level || 'All'}>
          <SelectTrigger><SelectValue placeholder="Education Level" /></SelectTrigger>
          <SelectContent>
            {educationLevels.map(el => <SelectItem key={el} value={el}>{el}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select onValueChange={(value) => handleSelectChange('education_system', value)} value={filters.education_system || 'All'}>
          <SelectTrigger><SelectValue placeholder="Education System" /></SelectTrigger>
          <SelectContent>
            {educationSystems.map(es => <SelectItem key={es} value={es}>{es}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select onValueChange={(value) => onFilterChange('price', value)} value={filters.price || 'all'}>
          <SelectTrigger><SelectValue placeholder="Price" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Prices</SelectItem>
            <SelectItem value="free">Free</SelectItem>
            <SelectItem value="paid">Paid</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="mt-4 pt-4 border-t flex items-center space-x-2">
        <Switch 
          id="my-courses-toggle" 
          checked={filters.myCoursesOnly}
          onCheckedChange={(checked) => onFilterChange('myCoursesOnly', checked)}
        />
        <Label htmlFor="my-courses-toggle">Show my enrolled courses only</Label>
      </div>
    </div>
  );
}