import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function SummaryViewer({ data }) {
  const summary = data?.summary;
  
  if (!summary || typeof summary !== 'string') {
    return (
      <Card>
        <CardHeader>
          <CardTitle>AI-Generated Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500">No summary was generated.</p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>AI-Generated Summary</CardTitle>
      </CardHeader>
      <CardContent className="prose max-w-none">
        <p className="whitespace-pre-wrap">{summary}</p>
      </CardContent>
    </Card>
  );
}