
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { motion } from 'framer-motion';
import { Brain, ArrowRight, RotateCcw, CheckCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { format, addDays } from 'date-fns';
import { toast } from 'sonner';

export default function SpacedRepetitionMode({ deck, onExit }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [cardSchedule, setCardSchedule] = useState([]);
  const [shuffledCards, setShuffledCards] = useState([]);
  const [isShuffled, setIsShuffled] = useState(false);
  const queryClient = useQueryClient();

  const cards = deck?.flashcards?.cards || [];

  const { data: existingProgress } = useQuery({
    queryKey: ['deckProgress', deck.id, 'spaced_repetition'],
    queryFn: async () => {
      const user = await base44.auth.me();
      const progress = await base44.entities.DeckProgress.filter({
        deck_id: deck.id,
        user_email: user.email,
        mode: 'spaced_repetition',
      });
      return progress[0] || null;
    },
  });

  useEffect(() => {
    if (existingProgress && existingProgress.card_data) {
      // Ensure card_data has entries for all current cards, even if new cards were added
      const initialSchedule = cards.map((_, index) => {
        const existing = existingProgress.card_data.find(item => item.card_index === index);
        return existing || {
          card_index: index,
          difficulty: 'medium',
          next_review_date: format(new Date(), 'yyyy-MM-dd'),
        };
      });
      setCardSchedule(initialSchedule);
    } else {
      setCardSchedule(cards.map((_, index) => ({
        card_index: index,
        difficulty: 'medium',
        next_review_date: format(new Date(), 'yyyy-MM-dd'),
      })));
    }
  }, [existingProgress, cards]);

  const handleShuffle = () => {
    const shuffled = [...cards].sort(() => Math.random() - 0.5);
    setShuffledCards(shuffled);
    setIsShuffled(true);
    setCurrentIndex(0);
    setIsFlipped(false);
    toast.success('Cards shuffled!');
  };

  const handleResetOrder = () => {
    setIsShuffled(false);
    setCurrentIndex(0);
    setIsFlipped(false);
    toast.success('Original order restored');
  };

  const saveProgressMutation = useMutation({
    mutationFn: async (progressData) => {
      const user = await base44.auth.me();
      if (existingProgress) {
        return base44.entities.DeckProgress.update(existingProgress.id, {
          cards_completed: progressData.cards_completed,
          card_data: progressData.card_data,
          last_practiced_date: format(new Date(), 'yyyy-MM-dd'),
        });
      } else {
        return base44.entities.DeckProgress.create({
          deck_id: deck.id,
          user_email: user.email,
          mode: 'spaced_repetition',
          total_cards: cards.length,
          cards_completed: progressData.cards_completed,
          correct_answers: 0, // This mode doesn't track correct answers directly for score_percentage
          score_percentage: 0, // This mode doesn't track score_percentage
          card_data: progressData.card_data,
          last_practiced_date: format(new Date(), 'yyyy-MM-dd'),
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['deckProgress', deck.id] });
    },
  });

  const displayCards = isShuffled ? shuffledCards : cards;
  const currentCard = displayCards[currentIndex];

  const handleDifficulty = (difficulty) => {
    const today = new Date();
    let nextReviewDays;
    
    switch (difficulty) {
      case 'easy':
        nextReviewDays = 7;
        break;
      case 'medium':
        nextReviewDays = 3;
        break;
      case 'hard':
        nextReviewDays = 1;
        break;
      default:
        nextReviewDays = 3;
    }

    // Find the actual index of the current card in the original `cards` array
    // This is crucial because cardSchedule is indexed by the original card order.
    const actualCardIndex = isShuffled 
      ? cards.findIndex(c => c.front === currentCard.front && c.back === currentCard.back)
      : currentIndex;

    const updatedSchedule = [...cardSchedule];
    if (actualCardIndex !== -1) { // Ensure card was found in original deck
      updatedSchedule[actualCardIndex] = {
        card_index: actualCardIndex,
        difficulty,
        next_review_date: format(addDays(today, nextReviewDays), 'yyyy-MM-dd'),
      };
      setCardSchedule(updatedSchedule);
    } else {
      console.warn("Could not find current card in original deck for schedule update.");
    }


    if (currentIndex < displayCards.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setIsFlipped(false);
    } else {
      saveProgressMutation.mutate({
        cards_completed: displayCards.length, // All cards in the current display set (shuffled or not)
        card_data: updatedSchedule,
      });
      setCompleted(true);
      toast.success('Spaced repetition session completed!');
    }
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setIsFlipped(false);
    setCompleted(false);
    if (isShuffled) {
      handleShuffle(); // Re-shuffle if it was shuffled before
    }
  };

  if (!cards || cards.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <p className="text-gray-500">No flashcards available for spaced repetition.</p>
          <Button onClick={onExit} className="mt-4">Go Back</Button>
        </CardContent>
      </Card>
    );
  }

  if (completed) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
      >
        <Card>
          <CardHeader className="text-center">
            <Brain className="w-16 h-16 mx-auto mb-4 text-purple-500" />
            <CardTitle className="text-2xl">Session Complete!</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-lg text-gray-600">
              You've reviewed all {cards.length} cards
            </p>
            <p className="text-sm text-gray-500">
              Your next review dates have been scheduled based on your difficulty ratings
            </p>
            <div className="flex justify-center gap-3 mt-6">
              <Button onClick={handleRestart} variant="outline">
                <RotateCcw className="w-4 h-4 mr-2" />
                Review Again
              </Button>
              <Button onClick={onExit}>
                Exit
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  // Ensure currentCard is valid before rendering
  if (!currentCard) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <p className="text-gray-500">Error: Could not load current card.</p>
          <Button onClick={onExit} className="mt-4">Go Back</Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center mb-4">
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-purple-600" />
            Spaced Repetition Mode
          </CardTitle>
          <div className="flex items-center gap-2">
            {!isShuffled ? (
              <Button variant="outline" size="sm" onClick={handleShuffle}>
                <RotateCcw className="w-4 h-4 mr-2" />
                Shuffle
              </Button>
            ) : (
              <Button variant="outline" size="sm" onClick={handleResetOrder}>
                Reset Order
              </Button>
            )}
            <div className="text-sm text-gray-500 ml-2">
              Card {currentIndex + 1} of {displayCards.length}
            </div>
          </div>
        </div>
        <Progress value={((currentIndex + 1) / displayCards.length) * 100} className="h-2" />
      </CardHeader>
      <CardContent>
        <div className="mb-6">
          <div className="relative w-full max-w-lg mx-auto h-72 [perspective:1000px]">
            <motion.div
              className="relative w-full h-full transition-transform duration-700 [transform-style:preserve-3d]"
              initial={false}
              animate={{ rotateY: isFlipped ? 180 : 0 }}
              transition={{ duration: 0.6, ease: "easeInOut" }}
            >
              <div className="absolute w-full h-full [backface-visibility:hidden] flex items-center justify-center p-6 bg-gradient-to-br from-purple-50 to-blue-50 border-2 border-purple-200 rounded-lg shadow-md overflow-y-auto">
                <p className="text-xl text-center whitespace-pre-wrap font-semibold text-gray-800">
                  {currentCard.front}
                </p>
              </div>
              <div className="absolute w-full h-full [backface-visibility:hidden] [transform:rotateY(180deg)] flex items-center justify-center p-6 bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200 rounded-lg shadow-md overflow-y-auto">
                <p className="text-lg text-center whitespace-pre-wrap text-gray-700">
                  {currentCard.back}
                </p>
              </div>
            </motion.div>
          </div>
          
          {!isFlipped ? (
            <Button 
              onClick={() => setIsFlipped(true)} 
              className="mt-6 w-full"
            >
              Show Answer
            </Button>
          ) : (
            <div className="mt-6 space-y-3">
              <p className="text-sm text-gray-600 text-center mb-3">How well did you know this?</p>
              <div className="grid grid-cols-3 gap-3">
                <Button
                  onClick={() => handleDifficulty('hard')}
                  variant="outline"
                  className="border-red-300 hover:bg-red-50 hover:border-red-400"
                >
                  <div className="text-center">
                    <div className="font-semibold text-red-600">Hard</div>
                    <div className="text-xs text-gray-500">Review in 1 day</div>
                  </div>
                </Button>
                <Button
                  onClick={() => handleDifficulty('medium')}
                  variant="outline"
                  className="border-yellow-300 hover:bg-yellow-50 hover:border-yellow-400"
                >
                  <div className="text-center">
                    <div className="font-semibold text-yellow-600">Medium</div>
                    <div className="text-xs text-gray-500">Review in 3 days</div>
                  </div>
                </Button>
                <Button
                  onClick={() => handleDifficulty('easy')}
                  variant="outline"
                  className="border-green-300 hover:bg-green-50 hover:border-green-400"
                >
                  <div className="text-center">
                    <div className="font-semibold text-green-600">Easy</div>
                    <div className="text-xs text-gray-500">Review in 7 days</div>
                  </div>
                </Button>
              </div>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="justify-between text-sm text-gray-500">
        <span className="flex items-center gap-1">
          <CheckCircle className="w-4 h-4" />
          {currentIndex} reviewed
        </span>
        <Button variant="ghost" size="sm" onClick={onExit}>Exit</Button>
      </CardFooter>
    </Card>
  );
}
