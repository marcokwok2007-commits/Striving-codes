import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Pencil, Type, Highlighter, Eraser, Save, X } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function PDFAnnotator({ deck, currentPage, annotations = {}, onAnnotationsChange }) {
  const [tool, setTool] = useState(null); // 'text', 'highlight', 'draw', 'erase'
  const [color, setColor] = useState('#FFD700'); // Default yellow for highlights
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentAnnotation, setCurrentAnnotation] = useState(null);
  const canvasRef = useRef(null);
  const queryClient = useQueryClient();

  const pageAnnotations = annotations[currentPage] || [];

  const saveAnnotationsMutation = useMutation({
    mutationFn: async (updatedAnnotations) => {
      return base44.entities.Deck.update(deck.id, {
        annotations: updatedAnnotations
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['decks'] });
      toast.success('Annotations saved!');
    },
    onError: (error) => {
      toast.error('Failed to save annotations: ' + error.message);
    }
  });

  const addAnnotation = (annotation) => {
    const updated = { ...annotations };
    if (!updated[currentPage]) {
      updated[currentPage] = [];
    }
    updated[currentPage] = [...updated[currentPage], annotation];
    onAnnotationsChange(updated);
  };

  const removeAnnotation = (index) => {
    const updated = { ...annotations };
    updated[currentPage] = updated[currentPage].filter((_, i) => i !== index);
    onAnnotationsChange(updated);
  };

  const handleSave = () => {
    saveAnnotationsMutation.mutate(annotations);
  };

  const handleCanvasClick = (e) => {
    if (tool === 'text') {
      const rect = canvasRef.current.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      
      setCurrentAnnotation({
        type: 'text',
        x,
        y,
        content: '',
        color: '#000000'
      });
    }
  };

  const handleTextSubmit = (content) => {
    if (content.trim() && currentAnnotation) {
      addAnnotation({
        ...currentAnnotation,
        content: content.trim(),
        timestamp: new Date().toISOString()
      });
      setCurrentAnnotation(null);
      setTool(null);
    }
  };

  const handleHighlight = (e) => {
    if (tool === 'highlight') {
      const rect = canvasRef.current.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      
      addAnnotation({
        type: 'highlight',
        x,
        y,
        width: 15,
        height: 2,
        color,
        timestamp: new Date().toISOString()
      });
    }
  };

  const colors = [
    { name: 'Yellow', value: '#FFD700' },
    { name: 'Green', value: '#90EE90' },
    { name: 'Pink', value: '#FFB6C1' },
    { name: 'Blue', value: '#ADD8E6' },
    { name: 'Orange', value: '#FFA500' }
  ];

  return (
    <div className="absolute inset-0 pointer-events-none z-20">
      {/* Annotation Tools */}
      <div className="absolute top-4 left-4 flex flex-col gap-2 pointer-events-auto">
        <div className="bg-white rounded-lg shadow-lg p-2 flex flex-col gap-2">
          <Button
            variant={tool === 'text' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setTool(tool === 'text' ? null : 'text')}
            title="Add Text Note"
          >
            <Type className="w-4 h-4" />
          </Button>
          
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant={tool === 'highlight' ? 'default' : 'ghost'}
                size="sm"
                title="Highlight"
              >
                <Highlighter className="w-4 h-4" />
              </Button>
            </PopoverTrigger>
            <PopoverContent side="right" className="w-auto p-2">
              <div className="flex gap-2">
                {colors.map(c => (
                  <button
                    key={c.value}
                    className="w-8 h-8 rounded border-2 hover:border-gray-400"
                    style={{ backgroundColor: c.value }}
                    onClick={() => {
                      setColor(c.value);
                      setTool('highlight');
                    }}
                    title={c.name}
                  />
                ))}
              </div>
            </PopoverContent>
          </Popover>

          <Button
            variant={tool === 'erase' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setTool(tool === 'erase' ? null : 'erase')}
            title="Erase Annotation"
          >
            <Eraser className="w-4 h-4" />
          </Button>

          <div className="border-t pt-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleSave}
              disabled={saveAnnotationsMutation.isPending}
              title="Save All Annotations"
              className="w-full"
            >
              <Save className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {tool && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-2 text-xs text-blue-800 max-w-[150px]">
            {tool === 'text' && 'Click where you want to add a note'}
            {tool === 'highlight' && 'Click to add a highlight'}
            {tool === 'erase' && 'Click on an annotation to remove it'}
          </div>
        )}
      </div>

      {/* Annotation Canvas */}
      <div
        ref={canvasRef}
        className={`absolute inset-0 ${tool ? 'pointer-events-auto cursor-crosshair' : ''}`}
        onClick={tool === 'text' ? handleCanvasClick : tool === 'highlight' ? handleHighlight : undefined}
      >
        {/* Render Highlights */}
        {pageAnnotations.filter(a => a.type === 'highlight').map((annotation, index) => (
          <div
            key={`highlight-${index}`}
            className={`absolute rounded ${tool === 'erase' ? 'cursor-pointer hover:opacity-70' : ''}`}
            style={{
              left: `${annotation.x}%`,
              top: `${annotation.y}%`,
              width: `${annotation.width}%`,
              height: `${annotation.height}%`,
              backgroundColor: annotation.color,
              opacity: 0.5,
              pointerEvents: tool === 'erase' ? 'auto' : 'none'
            }}
            onClick={() => tool === 'erase' && removeAnnotation(index)}
          />
        ))}

        {/* Render Text Notes */}
        {pageAnnotations.filter(a => a.type === 'text').map((annotation, index) => (
          <div
            key={`text-${index}`}
            className={`absolute bg-yellow-100 border-2 border-yellow-400 rounded-lg p-2 shadow-lg max-w-xs ${
              tool === 'erase' ? 'cursor-pointer hover:border-red-400' : ''
            }`}
            style={{
              left: `${annotation.x}%`,
              top: `${annotation.y}%`,
              pointerEvents: 'auto'
            }}
            onClick={() => tool === 'erase' && removeAnnotation(index)}
          >
            <p className="text-xs text-gray-800 whitespace-pre-wrap">{annotation.content}</p>
          </div>
        ))}

        {/* Current Text Input */}
        {currentAnnotation && currentAnnotation.type === 'text' && (
          <div
            className="absolute bg-white border-2 border-orange-400 rounded-lg p-2 shadow-lg"
            style={{
              left: `${currentAnnotation.x}%`,
              top: `${currentAnnotation.y}%`,
              width: '250px',
              pointerEvents: 'auto'
            }}
          >
            <Textarea
              autoFocus
              placeholder="Type your note..."
              className="w-full mb-2 text-sm"
              rows={3}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && e.ctrlKey) {
                  handleTextSubmit(e.target.value);
                } else if (e.key === 'Escape') {
                  setCurrentAnnotation(null);
                  setTool(null);
                }
              }}
            />
            <div className="flex gap-2 justify-end">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  setCurrentAnnotation(null);
                  setTool(null);
                }}
              >
                <X className="w-3 h-3" />
              </Button>
              <Button
                size="sm"
                onClick={(e) => {
                  const textarea = e.target.closest('div').querySelector('textarea');
                  handleTextSubmit(textarea.value);
                }}
              >
                Add
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-1">Ctrl+Enter to save, Esc to cancel</p>
          </div>
        )}
      </div>
    </div>
  );
}