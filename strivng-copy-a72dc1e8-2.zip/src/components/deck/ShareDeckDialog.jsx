import React, { useState } from 'react';
import { DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Switch } from '@/components/ui/switch';
import { Copy, Check, Share2, Users, Eye } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

export default function ShareDeckDialog({ deck, onClose }) {
  const [permissionLevel, setPermissionLevel] = useState('view_only');
  const [isPublic, setIsPublic] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: existingShare } = useQuery({
    queryKey: ['sharedDeck', deck.id],
    queryFn: async () => {
      const shares = await base44.entities.SharedDeck.filter({ deck_id: deck.id, owner_email: user.email });
      return shares[0] || null;
    },
    enabled: !!user,
  });

  const createShareMutation = useMutation({
    mutationFn: async (shareData) => {
      const shareToken = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
      return base44.entities.SharedDeck.create({
        ...shareData,
        share_token: shareToken,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sharedDeck', deck.id] });
      toast.success('Deck shared successfully!');
    },
    onError: (error) => {
      toast.error('Failed to share deck: ' + error.message);
    },
  });

  const updateShareMutation = useMutation({
    mutationFn: async (updates) => {
      return base44.entities.SharedDeck.update(existingShare.id, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sharedDeck', deck.id] });
      toast.success('Share settings updated!');
    },
  });

  const deleteShareMutation = useMutation({
    mutationFn: () => base44.entities.SharedDeck.delete(existingShare.id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sharedDeck', deck.id] });
      toast.success('Sharing disabled');
      onClose();
    },
  });

  const handleCreateShare = () => {
    createShareMutation.mutate({
      deck_id: deck.id,
      original_deck_title: deck.title,
      owner_email: user.email,
      owner_name: user.full_name || user.email,
      permission_level: permissionLevel,
      is_public: isPublic,
      collaborator_emails: [],
    });
  };

  const handleUpdateShare = () => {
    updateShareMutation.mutate({
      permission_level: permissionLevel,
      is_public: isPublic,
    });
  };

  const shareLink = existingShare
    ? `${window.location.origin}${window.location.pathname}?shared_deck=${existingShare.share_token}`
    : '';

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareLink);
    setLinkCopied(true);
    setTimeout(() => setLinkCopied(false), 2000);
    toast.success('Link copied to clipboard!');
  };

  return (
    <DialogContent className="max-w-md">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Share2 className="w-5 h-5" />
          Share "{deck.title}"
        </DialogTitle>
        <DialogDescription>
          Share this deck with others or collaborate with your study group
        </DialogDescription>
      </DialogHeader>

      <div className="space-y-6 py-4">
        {existingShare && (
          <div className="space-y-3">
            <Label>Shareable Link</Label>
            <div className="flex gap-2">
              <Input value={shareLink} readOnly className="text-sm" />
              <Button onClick={handleCopyLink} size="icon" variant="outline">
                {linkCopied ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-1">
                <Eye className="w-4 h-4" />
                {existingShare.view_count || 0} views
              </div>
              <div className="flex items-center gap-1">
                <Users className="w-4 h-4" />
                {existingShare.clone_count || 0} clones
              </div>
            </div>
          </div>
        )}

        <div className="space-y-3">
          <Label>Permission Level</Label>
          <RadioGroup value={permissionLevel} onValueChange={setPermissionLevel}>
            <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50">
              <RadioGroupItem value="view_only" id="view_only" />
              <Label htmlFor="view_only" className="flex-1 cursor-pointer">
                <div className="font-medium">View Only</div>
                <div className="text-sm text-gray-500">Users can view and clone the deck</div>
              </Label>
            </div>
            <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50">
              <RadioGroupItem value="contribute" id="contribute" />
              <Label htmlFor="contribute" className="flex-1 cursor-pointer">
                <div className="font-medium">Contribute</div>
                <div className="text-sm text-gray-500">Users can add and edit flashcards</div>
              </Label>
            </div>
          </RadioGroup>
        </div>

        <div className="flex items-center justify-between p-3 border rounded-lg">
          <div>
            <Label htmlFor="public-toggle" className="font-medium">Public Deck</Label>
            <p className="text-sm text-gray-500">Anyone with the link can access</p>
          </div>
          <Switch
            id="public-toggle"
            checked={isPublic}
            onCheckedChange={setIsPublic}
          />
        </div>
      </div>

      <DialogFooter className="gap-2">
        {existingShare && (
          <Button
            variant="destructive"
            onClick={() => deleteShareMutation.mutate()}
            disabled={deleteShareMutation.isPending}
          >
            Disable Sharing
          </Button>
        )}
        <Button variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button
          onClick={existingShare ? handleUpdateShare : handleCreateShare}
          disabled={createShareMutation.isPending || updateShareMutation.isPending}
        >
          {existingShare ? 'Update Settings' : 'Create Share Link'}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}