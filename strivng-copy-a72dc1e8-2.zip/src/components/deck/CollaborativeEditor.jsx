import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Plus, Send, Check, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function CollaborativeEditor({ deck, sharedDeck }) {
  const [isAdding, setIsAdding] = useState(false);
  const [newCard, setNewCard] = useState({ front: '', back: '' });
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: contributions = [] } = useQuery({
    queryKey: ['contributions', deck.id],
    queryFn: () => base44.entities.DeckContribution.filter({ deck_id: deck.id }, '-created_date'),
  });

  const isOwner = deck.created_by === user?.email;
  const canContribute = sharedDeck?.permission_level === 'contribute';

  const addContributionMutation = useMutation({
    mutationFn: async (cardData) => {
      return base44.entities.DeckContribution.create({
        deck_id: deck.id,
        contributor_email: user.email,
        contributor_name: user.full_name || user.email,
        contribution_type: 'add_card',
        card_data: cardData,
        status: isOwner ? 'approved' : 'pending',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contributions', deck.id] });
      toast.success(isOwner ? 'Card added!' : 'Contribution submitted for review');
      setNewCard({ front: '', back: '' });
      setIsAdding(false);
      
      if (isOwner) {
        // Automatically add to deck if owner
        const updatedCards = [...(deck.flashcards?.cards || []), newCard];
        updateDeckMutation.mutate(updatedCards);
      }
    },
  });

  const updateDeckMutation = useMutation({
    mutationFn: async (cards) => {
      return base44.entities.Deck.update(deck.id, {
        flashcards: { cards },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['decks'] });
    },
  });

  const approveContributionMutation = useMutation({
    mutationFn: async (contribution) => {
      // Update contribution status
      await base44.entities.DeckContribution.update(contribution.id, { status: 'approved' });
      
      // Add card to deck
      const updatedCards = [...(deck.flashcards?.cards || []), contribution.card_data];
      return base44.entities.Deck.update(deck.id, {
        flashcards: { cards: updatedCards },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contributions', deck.id] });
      queryClient.invalidateQueries({ queryKey: ['decks'] });
      toast.success('Contribution approved and added!');
    },
  });

  const rejectContributionMutation = useMutation({
    mutationFn: (contributionId) => {
      return base44.entities.DeckContribution.update(contributionId, { status: 'rejected' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contributions', deck.id] });
      toast.success('Contribution rejected');
    },
  });

  const handleSubmitCard = () => {
    if (!newCard.front.trim() || !newCard.back.trim()) {
      toast.error('Both front and back are required');
      return;
    }
    addContributionMutation.mutate(newCard);
  };

  const pendingContributions = contributions.filter(c => c.status === 'pending');

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Collaborative Editing</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {canContribute && (
            <div className="space-y-3">
              {!isAdding ? (
                <Button onClick={() => setIsAdding(true)} className="w-full">
                  <Plus className="w-4 h-4 mr-2" />
                  Contribute a Flashcard
                </Button>
              ) : (
                <div className="border rounded-lg p-4 space-y-3">
                  <Input
                    placeholder="Front of card (question)"
                    value={newCard.front}
                    onChange={(e) => setNewCard({ ...newCard, front: e.target.value })}
                  />
                  <Textarea
                    placeholder="Back of card (answer)"
                    value={newCard.back}
                    onChange={(e) => setNewCard({ ...newCard, back: e.target.value })}
                    className="h-24"
                  />
                  <div className="flex gap-2">
                    <Button
                      onClick={handleSubmitCard}
                      disabled={addContributionMutation.isPending}
                      className="flex-1"
                    >
                      <Send className="w-4 h-4 mr-2" />
                      Submit
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setIsAdding(false);
                        setNewCard({ front: '', back: '' });
                      }}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}

          {!canContribute && !isOwner && (
            <div className="p-4 bg-gray-50 rounded-lg text-center text-sm text-gray-600">
              This deck is view-only. You cannot contribute flashcards.
            </div>
          )}
        </CardContent>
      </Card>

      {isOwner && pendingContributions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Pending Contributions ({pendingContributions.length})</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {pendingContributions.map((contribution) => (
              <div key={contribution.id} className="border rounded-lg p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="text-sm text-gray-500">
                    by {contribution.contributor_name}
                  </div>
                  <Badge variant="outline">Pending</Badge>
                </div>
                <div className="bg-gray-50 rounded p-3">
                  <p className="font-semibold text-sm mb-1">Q: {contribution.card_data?.front}</p>
                  <p className="text-sm text-gray-600">A: {contribution.card_data?.back}</p>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={() => approveContributionMutation.mutate(contribution)}
                    disabled={approveContributionMutation.isPending}
                    className="flex-1"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    Approve
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => rejectContributionMutation.mutate(contribution.id)}
                    disabled={rejectContributionMutation.isPending}
                    className="flex-1"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Reject
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}