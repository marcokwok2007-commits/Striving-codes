
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import FlashcardViewer from "./FlashcardViewer";
import MindmapViewer from "./MindmapViewer";
import SummaryViewer from "./SummaryViewer";
import FileViewer from "./FileViewer";
import FlashcardEditorNew from "./FlashcardEditorNew";
import QuizMode from "./QuizMode";
import { Lightbulb, Map, FileText, Edit, Trophy, BookOpen, Loader2, ArrowLeft, Check, X, File, Maximize2, Minimize2, ExternalLink } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Dialog } from "@/components/ui/dialog";
import ReactMarkdown from 'react-markdown';

export default function ViewDeckDialog({ deck, initialTab = 'flashcards', readOnly = false }) {
  const [activeTab, setActiveTab] = useState(initialTab);
  const [isEditing, setIsEditing] = useState(false);
  const [aiNotes, setAiNotes] = useState(null);
  const [isGeneratingNotes, setIsGeneratingNotes] = useState(false);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [editedTitle, setEditedTitle] = useState(deck.title);
  const [targetPage, setTargetPage] = useState(1);
  const [isNotesFullscreen, setIsNotesFullscreen] = useState(false);
  const queryClient = useQueryClient();

  const { data: currentUser } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const isOwner = currentUser?.email === deck.created_by;
  const canEdit = isOwner && !readOnly;
  const hasSourceFile = !!deck.source_file_url;

  useEffect(() => {
    if (initialTab === 'edit') {
      setIsEditing(true);
      setActiveTab('flashcards');
    } else if (deck.flashcards) {
      setActiveTab('flashcards');
    } else if (deck.mindmap) {
      setActiveTab('mindmap');
    } else if (deck.summary) {
      setActiveTab('summary');
    } else if (hasSourceFile) {
      setActiveTab('notes');
    } else {
      setActiveTab('');
    }
  }, [deck, initialTab, hasSourceFile]);

  const updateTitleMutation = useMutation({
    mutationFn: async (newTitle) => {
      return base44.entities.Deck.update(deck.id, { title: newTitle });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['decks'] });
      toast.success('Deck name updated!');
      setIsEditingTitle(false);
    },
    onError: (error) => {
      toast.error('Failed to update name: ' + error.message);
    }
  });

  const generateNotesMutation = useMutation({
    mutationFn: async () => {
      setIsGeneratingNotes(true);
      
      let context = `Topic: ${deck.title}\n\n`;
      
      if (deck.summary?.summary) {
        context += `Summary: ${deck.summary.summary}\n\n`;
      }
      
      if (deck.flashcards?.cards) {
        context += `Key Concepts:\n`;
        deck.flashcards.cards.slice(0, 10).forEach((card, idx) => {
          context += `${idx + 1}. ${card.front}: ${card.back}\n`;
        });
      }
      
      const prompt = `Based on the following study material, generate comprehensive, well-structured study notes.

${context}

Create detailed study notes that include:
1. Overview and Introduction
2. Key Concepts (organized with clear headings)
3. Important Details and Explanations
4. Examples and Applications
5. Study Tips and Memory Aids

Format the notes with proper markdown formatting (headings, bullet points, bold text).
Make them clear, organized, and helpful for exam preparation.
Aim for 400-600 words.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        add_context_from_internet: false,
        response_json_schema: {
          type: "object",
          properties: {
            notes: { type: "string" }
          },
          required: ["notes"]
        }
      });

      return result.notes;
    },
    onSuccess: (notes) => {
      setAiNotes(notes);
      setIsGeneratingNotes(false);
      toast.success('Study notes generated successfully!');
    },
    onError: (error) => {
      setIsGeneratingNotes(false);
      toast.error('Failed to generate notes: ' + error.message);
    }
  });

  const handleGenerateNotes = () => {
    generateNotesMutation.mutate();
  };

  const handleEditSave = () => {
    setIsEditing(false);
    queryClient.invalidateQueries({ queryKey: ['decks'] });
  };

  const handleTitleDoubleClick = () => {
    if (canEdit) {
      setIsEditingTitle(true);
      setEditedTitle(deck.title);
    }
  };

  const handleTitleSave = () => {
    if (editedTitle.trim() && editedTitle !== deck.title) {
      updateTitleMutation.mutate(editedTitle.trim());
    } else {
      setIsEditingTitle(false);
    }
  };

  const handleTitleCancel = () => {
    setIsEditingTitle(false);
    setEditedTitle(deck.title);
  };

  const handleTitleKeyDown = (e) => {
    if (e.key === 'Enter') {
      handleTitleSave();
    } else if (e.key === 'Escape') {
      handleTitleCancel();
    }
  };

  const handlePageReferenceClick = (pageRef) => {
    const pageNumber = parseInt(pageRef.split('-')[0]);
    if (!isNaN(pageNumber) && pageNumber > 0) {
      setTargetPage(pageNumber);
      setTimeout(() => {
        setActiveTab('notes');
      }, 50);
    }
  };

  const handleToggleNotesFullscreen = () => {
    setIsNotesFullscreen(!isNotesFullscreen);
  };

  const handleOpenNotesInBrowser = (e) => {
    e?.preventDefault();
    e?.stopPropagation();
    
    if (!deck.source_file_url) {
      toast.error('No file URL available');
      return;
    }
    
    try {
      // Simple, reliable approach - just open in new tab
      window.open(deck.source_file_url, '_blank', 'noopener,noreferrer');
      toast.success('Opening in browser...');
    } catch (error) {
      console.error('Failed to open in browser:', error);
      toast.error('Failed to open PDF');
    }
  };

  if (isEditing && canEdit) {
    return (
      <Dialog open={isEditing} onOpenChange={setIsEditing}>
        <FlashcardEditorNew 
          deck={deck} 
          onSave={handleEditSave} 
          onCancel={() => setIsEditing(false)} 
        />
      </Dialog>
    );
  }

  if (activeTab === 'quiz') {
    return (
      <DialogContent className="max-w-2xl h-[90vh] backdrop-blur-2xl bg-white/80 border-white/20 shadow-2xl">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={() => setActiveTab('flashcards')}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <DialogTitle>{deck.title} - Quiz Mode</DialogTitle>
          </div>
        </DialogHeader>
        <div className="overflow-y-auto pr-2 h-full">
          <QuizMode deck={deck} onExit={() => setActiveTab('flashcards')} />
        </div>
      </DialogContent>
    );
  }

  if (activeTab === 'ai-notes') {
    return (
      <DialogContent className="max-w-4xl h-[90vh] bg-gradient-to-br from-orange-50 to-amber-50">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={() => setActiveTab('flashcards')}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
              AI Study Notes - {deck.title}
            </DialogTitle>
          </div>
        </DialogHeader>
        <div className="overflow-y-auto pr-2 h-full">
          {!aiNotes && !isGeneratingNotes && (
            <div className="flex flex-col items-center justify-center py-20 px-6">
              <div className="relative mb-8">
                <div className="absolute inset-0 bg-gradient-to-r from-orange-400 to-amber-400 blur-2xl opacity-30 rounded-full"></div>
                <div className="relative bg-gradient-to-br from-orange-100 to-amber-100 p-8 rounded-full">
                  <BookOpen className="w-20 h-20 text-orange-600" />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-3">Generate AI Study Notes</h3>
              <p className="text-gray-600 text-center mb-8 max-w-md leading-relaxed">
                Let AI analyze your deck and create comprehensive, well-organized study notes tailored specifically for your learning needs.
              </p>
              <div className="bg-white rounded-xl p-6 shadow-lg mb-8 max-w-md">
                <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
                  <span className="text-orange-600">✨</span> What you'll get:
                </h4>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-0.5">✓</span>
                    <span>Clear overview and key concepts</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-0.5">✓</span>
                    <span>Detailed explanations with examples</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-0.5">✓</span>
                    <span>Study tips and memory aids</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-0.5">✓</span>
                    <span>Well-formatted markdown notes</span>
                  </li>
                </ul>
              </div>
              <Button 
                onClick={handleGenerateNotes}
                size="lg"
                className="bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white shadow-lg hover:shadow-xl transition-all"
              >
                <BookOpen className="w-5 h-5 mr-2" />
                Generate Notes
              </Button>
            </div>
          )}
          
          {isGeneratingNotes && (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="relative mb-6">
                <Loader2 className="w-16 h-16 text-orange-500 animate-spin" />
                <div className="absolute inset-0 bg-orange-400 blur-xl opacity-20 animate-pulse"></div>
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Creating your study notes...</h3>
              <p className="text-gray-600">This may take a few moments</p>
            </div>
          )}
          
          {aiNotes && (
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="bg-gradient-to-r from-orange-500 to-amber-500 p-6">
                <h3 className="text-2xl font-bold text-white">📚 Your Study Notes</h3>
                <p className="text-orange-100 text-sm mt-1">Generated by AI for {deck.title}</p>
              </div>
              <div className="p-8">
                <div className="prose prose-lg max-w-none prose-headings:text-orange-900 prose-h1:text-3xl prose-h2:text-2xl prose-h3:text-xl prose-p:text-gray-700 prose-strong:text-orange-800 prose-ul:text-gray-700 prose-ol:text-gray-700">
                  <ReactMarkdown>{aiNotes}</ReactMarkdown>
                </div>
              </div>
              <div className="bg-gray-50 p-6 border-t flex justify-end gap-3">
                <Button variant="outline" onClick={() => setActiveTab('flashcards')} size="lg">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Flashcards
                </Button>
                <Button 
                  variant="default" 
                  onClick={handleGenerateNotes} 
                  disabled={isGeneratingNotes}
                  size="lg"
                  className="bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600"
                >
                  <BookOpen className="w-4 h-4 mr-2" />
                  Regenerate Notes
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    );
  }

  if (isNotesFullscreen && activeTab === 'notes') {
    return (
      <DialogContent className="max-w-[95vw] w-[95vw] h-[95vh] p-0">
        <Button
          variant="ghost"
          size="icon"
          onClick={handleToggleNotesFullscreen}
          className="absolute top-4 right-4 z-50 bg-white/90 hover:bg-white shadow-lg"
          title="Exit fullscreen"
        >
          <Minimize2 className="w-4 h-4" />
        </Button>
        <FileViewer 
          fileUrl={deck.source_file_url} 
          initialPage={targetPage} 
          isFullscreenMode={true}
          deck={deck}
          onExit={handleToggleNotesFullscreen}
        />
      </DialogContent>
    );
  }

  return (
    <DialogContent className="max-w-4xl h-[90vh]">
      <DialogHeader className="flex-row items-center justify-between pr-6">
        {isEditingTitle ? (
          <div className="flex items-center gap-2 flex-1">
            <Input
              value={editedTitle}
              onChange={(e) => setEditedTitle(e.target.value)}
              onKeyDown={handleTitleKeyDown}
              className="text-lg font-semibold"
              autoFocus
            />
            <Button size="icon" variant="ghost" onClick={handleTitleSave}>
              <Check className="w-4 h-4 text-green-600" />
            </Button>
            <Button size="icon" variant="ghost" onClick={handleTitleCancel}>
              <X className="w-4 h-4 text-red-600" />
            </Button>
          </div>
        ) : (
          <>
            <DialogTitle 
              onDoubleClick={handleTitleDoubleClick}
              className={canEdit ? "cursor-pointer hover:text-orange-600 transition-colors" : ""}
              title={canEdit ? "Double-click to edit" : ""}
            >
              {deck.title}
              {readOnly && <span className="text-sm text-gray-500 ml-2">(View Only)</span>}
            </DialogTitle>
            {activeTab === 'flashcards' && deck.flashcards && canEdit && (
              <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                <Edit className="w-4 h-4 mr-2" /> Edit Flashcards
              </Button>
            )}
          </>
        )}
      </DialogHeader>
      <div className="grid grid-cols-4 gap-4 h-full overflow-hidden">
        <div className="col-span-1 border-r border-white/20 pr-4 flex flex-col gap-2">
          {deck.flashcards && (
            <>
              <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mt-2 mb-1 px-3">Study</div>
              <Button 
                variant={activeTab === 'flashcards' ? 'secondary' : 'ghost'} 
                onClick={() => setActiveTab('flashcards')} 
                className="justify-start w-full backdrop-blur-sm"
              >
                <Lightbulb className="w-4 h-4 mr-2" />Flashcards
              </Button>
              <Button 
                variant={activeTab === 'quiz' ? 'secondary' : 'ghost'} 
                onClick={() => setActiveTab('quiz')} 
                className="justify-start w-full backdrop-blur-sm"
              >
                <Trophy className="w-4 h-4 mr-2" />Quiz Mode
              </Button>
              
              <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mt-4 mb-1 px-3">Practice</div>
              <Button 
                variant={activeTab === 'ai-notes' ? 'secondary' : 'ghost'} 
                onClick={() => setActiveTab('ai-notes')} 
                className="justify-start w-full backdrop-blur-sm"
              >
                <BookOpen className="w-4 h-4 mr-2" />AI Notes
              </Button>
            </>
          )}
          {deck.mindmap && (
            <Button 
              variant={activeTab === 'mindmap' ? 'secondary' : 'ghost'} 
              onClick={() => setActiveTab('mindmap')} 
              className="justify-start backdrop-blur-sm"
            >
              <Map className="w-4 h-4 mr-2" />Mind Map
            </Button>
          )}
          {deck.summary && (
            <Button 
              variant={activeTab === 'summary' ? 'secondary' : 'ghost'} 
              onClick={() => setActiveTab('summary')} 
              className="justify-start backdrop-blur-sm"
            >
              <FileText className="w-4 h-4 mr-2" />Summary
            </Button>
          )}
          {hasSourceFile && (
            <div className="flex items-center gap-1">
              <Button 
                variant={activeTab === 'notes' ? 'secondary' : 'ghost'} 
                onClick={() => setActiveTab('notes')} 
                className="justify-start flex-1 backdrop-blur-sm"
              >
                <File className="w-4 h-4 mr-2" />Notes
              </Button>
              {activeTab === 'notes' && (
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={handleToggleNotesFullscreen}
                  title="Expand Notes"
                  className="h-8 w-8 backdrop-blur-sm"
                >
                  <Maximize2 className="w-4 h-4" />
                </Button>
              )}
            </div>
          )}
          {!deck.flashcards && !deck.mindmap && !deck.summary && !hasSourceFile && (
            <div className="p-2 text-center text-sm text-gray-500">
              <p>This deck is empty.</p>
              {canEdit && <Button variant="link" size="sm" className="h-auto p-0 mt-1" onClick={() => setIsEditing(true)}>Add flashcards manually</Button>}
            </div>
          )}
        </div>
        <div className="col-span-3 overflow-y-auto pr-2">
          {activeTab === 'flashcards' && deck.flashcards && <FlashcardViewer data={deck.flashcards} deck={deck} />}
          {activeTab === 'mindmap' && deck.mindmap && (
            <MindmapViewer 
              data={deck.mindmap} 
              deck={deck} 
              onPageReferenceClick={handlePageReferenceClick}
            />
          )}
          {activeTab === 'summary' && deck.summary && <SummaryViewer data={deck.summary} />}
          {activeTab === 'notes' && hasSourceFile && (
            <FileViewer 
              fileUrl={deck.source_file_url} 
              initialPage={targetPage} 
              isFullscreenMode={false} 
              deck={deck}
            />
          )}
          {activeTab === '' && (
            <p className="text-center text-gray-500 py-10">Select a content type to view{canEdit && ' or add flashcards'}.</p>
          )}
        </div>
      </div>
    </DialogContent>
  );
}
