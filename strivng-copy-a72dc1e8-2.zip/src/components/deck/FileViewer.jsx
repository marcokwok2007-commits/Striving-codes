import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, Loader2, Minimize2 } from 'lucide-react';
import { toast } from 'sonner';

export default function FileViewer({ fileUrl, initialPage = 1, isFullscreenMode = false, deck = null, onExit = null, onOpenBrowser = null }) {
  const [currentPage, setCurrentPage] = useState(initialPage);
  const [inputPage, setInputPage] = useState(initialPage.toString());
  const [isLoading, setIsLoading] = useState(true);
  const [iframeKey, setIframeKey] = useState(0);
  const [viewerType, setViewerType] = useState('pdfjs'); // 'pdfjs' or 'google'

  useEffect(() => {
    if (initialPage !== currentPage) {
      setCurrentPage(initialPage);
      setInputPage(initialPage.toString());
      setIsLoading(true);
      setIframeKey(prev => prev + 1);
    }
  }, [initialPage, currentPage]);

  if (!fileUrl) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <p className="text-gray-500">No notes available for this deck.</p>
        </CardContent>
      </Card>
    );
  }

  const isPDF = fileUrl.toLowerCase().endsWith('.pdf');

  const handlePageChange = (newPage) => {
    const pageNum = parseInt(newPage);
    if (!isNaN(pageNum) && pageNum > 0 && pageNum !== currentPage) {
      setCurrentPage(pageNum);
      setInputPage(pageNum.toString());
      setIsLoading(true);
      setIframeKey(prev => prev + 1);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      handlePageChange(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    handlePageChange(currentPage + 1);
  };

  if (isPDF) {
    const encodedUrl = encodeURIComponent(fileUrl);
    const pdfJsViewerUrl = `https://mozilla.github.io/pdf.js/web/viewer.html?file=${encodedUrl}#page=${currentPage}`;
    const googleDocsViewerUrl = `https://docs.google.com/viewer?url=${encodedUrl}&embedded=true`;
    
    const currentViewerUrl = viewerType === 'google' ? googleDocsViewerUrl : pdfJsViewerUrl;

    if (isFullscreenMode) {
      return (
        <div className="w-full h-full relative">
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-gray-50 z-10">
              <div className="text-center">
                <Loader2 className="w-8 h-8 animate-spin text-orange-500 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Loading PDF...</p>
              </div>
            </div>
          )}
          
          <iframe
            key={iframeKey}
            src={currentViewerUrl}
            className="w-full h-full border-0"
            title="Notes"
            onLoad={() => setIsLoading(false)}
            onError={() => {
              setIsLoading(false);
              toast.error('Failed to load PDF. Try switching viewer.');
            }}
          />
        </div>
      );
    }

    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Notes</span>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setViewerType(viewerType === 'pdfjs' ? 'google' : 'pdfjs')}
              title="Switch PDF viewer"
            >
              Switch Viewer
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {viewerType === 'pdfjs' && (
              <div className="flex items-center justify-center gap-2">
                <Button variant="outline" size="sm" onClick={handlePrevPage} disabled={currentPage <= 1}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">Page</span>
                  <Input
                    type="number"
                    min="1"
                    value={inputPage}
                    onChange={(e) => setInputPage(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handlePageChange(inputPage);
                      }
                    }}
                    onBlur={() => {
                      const pageNum = parseInt(inputPage);
                      if (!isNaN(pageNum) && pageNum > 0 && pageNum !== currentPage) {
                        handlePageChange(inputPage);
                      }
                    }}
                    className="w-16 h-8 text-center"
                  />
                </div>
                <Button variant="outline" size="sm" onClick={handleNextPage}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            )}
            
            <div className="relative w-full bg-gray-100 rounded-lg" style={{ height: '65vh' }}>
              {isLoading && (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-50 rounded-lg z-10">
                  <div className="text-center">
                    <Loader2 className="w-8 h-8 animate-spin text-orange-500 mx-auto mb-2" />
                    <p className="text-sm text-gray-600">Loading PDF...</p>
                  </div>
                </div>
              )}
              <iframe
                key={`${iframeKey}-${viewerType}`}
                src={currentViewerUrl}
                className="w-full h-full border-0 rounded-lg"
                title="Notes"
                onLoad={() => setIsLoading(false)}
                onError={() => {
                  setIsLoading(false);
                  toast.error('Failed to load PDF. Try switching viewer.');
                }}
              />
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Non-PDF files
  if (isFullscreenMode) {
    return (
      <div className="w-full h-full relative">
        <iframe
          src={fileUrl}
          className="w-full h-full border-0"
          title="Notes"
          onError={() => toast.error('Failed to load file')}
        />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Notes</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="w-full bg-gray-100 rounded-lg" style={{ height: '70vh' }}>
          <iframe
            src={fileUrl}
            className="w-full h-full border-0 rounded-lg"
            title="Notes"
            onError={() => toast.error('Failed to load file')}
          />
        </div>
      </CardContent>
    </Card>
  );
}