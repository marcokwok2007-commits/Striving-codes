import React, { useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogTrigger } from '@/components/ui/dialog';
import { Lightbulb, Map, FileText, Download, Eye, Users } from 'lucide-react';
import ViewDeckDialog from './ViewDeckDialog';
import { toast } from 'sonner';

export default function SharedDecksViewer() {
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Check URL for shared deck token
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const sharedToken = urlParams.get('shared_deck');
    if (sharedToken) {
      handleAccessSharedDeck(sharedToken);
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  const { data: publicShares = [] } = useQuery({
    queryKey: ['publicShares'],
    queryFn: () => base44.entities.SharedDeck.filter({ is_public: true }, '-created_date'),
  });

  const handleAccessSharedDeck = async (token) => {
    try {
      const shares = await base44.entities.SharedDeck.filter({ share_token: token });
      if (shares.length === 0) {
        toast.error('Invalid or expired share link');
        return;
      }
      const share = shares[0];
      
      // Increment view count
      await base44.entities.SharedDeck.update(share.id, {
        view_count: (share.view_count || 0) + 1,
      });
      
      toast.success(`Accessing "${share.original_deck_title}"`);
      queryClient.invalidateQueries({ queryKey: ['publicShares'] });
    } catch (error) {
      toast.error('Failed to access shared deck');
    }
  };

  const cloneDeckMutation = useMutation({
    mutationFn: async ({ deckId, shareId }) => {
      const originalDeck = await base44.entities.Deck.get(deckId);
      const clonedDeck = await base44.entities.Deck.create({
        title: `${originalDeck.title} (Copy)`,
        flashcards: originalDeck.flashcards,
        mindmap: originalDeck.mindmap,
        summary: originalDeck.summary,
      });
      
      // Increment clone count
      const share = await base44.entities.SharedDeck.get(shareId);
      await base44.entities.SharedDeck.update(shareId, {
        clone_count: (share.clone_count || 0) + 1,
      });
      
      return clonedDeck;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['decks'] });
      queryClient.invalidateQueries({ queryKey: ['publicShares'] });
      toast.success('Deck cloned to your library!');
    },
    onError: (error) => {
      toast.error('Failed to clone deck: ' + error.message);
    },
  });

  const handleCloneDeck = async (share) => {
    cloneDeckMutation.mutate({ deckId: share.deck_id, shareId: share.id });
  };

  if (!publicShares || publicShares.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <Users className="w-12 h-12 mx-auto mb-4 text-gray-400" />
          <h3 className="text-lg font-semibold text-gray-700 mb-2">No Public Decks Yet</h3>
          <p className="text-gray-500">Check back later for shared study materials</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-orange-600 mb-2">Public Shared Decks</h2>
        <p className="text-gray-500">Discover and clone decks shared by the community</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {publicShares.map((share) => (
          <Card key={share.id} className="flex flex-col">
            <CardHeader>
              <CardTitle className="text-lg">{share.original_deck_title}</CardTitle>
              <p className="text-sm text-gray-500">by {share.owner_name}</p>
            </CardHeader>
            <CardContent className="flex-grow">
              <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                <div className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  {share.view_count || 0}
                </div>
                <div className="flex items-center gap-1">
                  <Download className="w-4 h-4" />
                  {share.clone_count || 0}
                </div>
              </div>
              <Badge variant="outline" className="text-xs">
                {share.permission_level === 'view_only' ? 'View Only' : 'Collaborative'}
              </Badge>
            </CardContent>
            <CardFooter className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="flex-1"
                onClick={() => handleCloneDeck(share)}
                disabled={cloneDeckMutation.isPending}
              >
                <Download className="w-4 h-4 mr-2" />
                Clone
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}