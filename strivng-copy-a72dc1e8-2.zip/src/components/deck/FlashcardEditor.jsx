import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Save, Plus, Trash2, X, Loader2 } from 'lucide-react';

export default function FlashcardEditor({ deck, onSave, onCancel }) {
    const [cards, setCards] = useState(deck.flashcards?.cards || []);
    const queryClient = useQueryClient();

    const mutation = useMutation({
        mutationFn: (updatedCards) => {
            const updatedDeckData = {
                ...deck,
                flashcards: { cards: updatedCards },
            };
            const { id, ...payload } = updatedDeckData;
            return base44.entities.Deck.update(id, payload);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['decks'] });
            onSave();
        },
        onError: (error) => {
            alert("Failed to save flashcards: " + error.message);
        }
    });

    const handleCardChange = (index, field, value) => {
        const newCards = [...cards];
        newCards[index][field] = value;
        setCards(newCards);
    };

    const addCard = () => {
        setCards([...cards, { front: '', back: '' }]);
    };

    const removeCard = (index) => {
        const newCards = cards.filter((_, i) => i !== index);
        setCards(newCards);
    };

    const handleSaveChanges = () => {
        mutation.mutate(cards);
    };

    return (
        <div className="space-y-4">
            <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                {cards.map((card, index) => (
                    <Card key={index}>
                        <CardContent className="p-4 space-y-3">
                            <div className="flex justify-between items-center">
                                <label className="font-semibold text-sm">Card {index + 1}</label>
                                <Button variant="ghost" size="icon" onClick={() => removeCard(index)}>
                                    <Trash2 className="w-4 h-4 text-red-500" />
                                </Button>
                            </div>
                            <Textarea
                                placeholder="Front side"
                                value={card.front}
                                onChange={(e) => handleCardChange(index, 'front', e.target.value)}
                                className="h-20"
                            />
                            <Textarea
                                placeholder="Back side"
                                value={card.back}
                                onChange={(e) => handleCardChange(index, 'back', e.target.value)}
                                className="h-20"
                            />
                        </CardContent>
                    </Card>
                ))}
            </div>
            <Button variant="outline" onClick={addCard}>
                <Plus className="w-4 h-4 mr-2" /> Add Card
            </Button>
            <div className="flex justify-end gap-2 mt-4">
                <Button variant="ghost" onClick={onCancel} disabled={mutation.isPending}>
                    <X className="w-4 h-4 mr-2" /> Cancel
                </Button>
                <Button onClick={handleSaveChanges} disabled={mutation.isPending}>
                    {mutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                    Save Changes
                </Button>
            </div>
        </div>
    );
}