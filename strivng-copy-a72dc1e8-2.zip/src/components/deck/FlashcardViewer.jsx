import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { motion } from 'framer-motion';
import { ArrowLeft, ArrowRight, RefreshCw, RotateCcw, Brain, CheckCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { format, addDays } from 'date-fns';
import { toast } from 'sonner';

export default function FlashcardViewer({ data, deck }) {
  const cards = data?.cards || [];
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [spacedRepMode, setSpacedRepMode] = useState(false);
  const [isShuffled, setIsShuffled] = useState(false);
  const [shuffledCards, setShuffledCards] = useState([]);
  const [cardSchedule, setCardSchedule] = useState([]);
  const queryClient = useQueryClient();

  const { data: existingProgress } = useQuery({
    queryKey: ['deckProgress', deck?.id, 'spaced_repetition'],
    queryFn: async () => {
      if (!deck?.id) return null;
      const user = await base44.auth.me();
      const progress = await base44.entities.DeckProgress.filter({
        deck_id: deck.id,
        user_email: user.email,
        mode: 'spaced_repetition',
      });
      return progress[0] || null;
    },
    enabled: !!deck?.id && spacedRepMode,
  });

  useEffect(() => {
    if (spacedRepMode) {
      if (existingProgress && existingProgress.card_data) {
        setCardSchedule(existingProgress.card_data);
      } else {
        setCardSchedule(cards.map((_, index) => ({
          card_index: index,
          difficulty: 'medium',
          next_review_date: format(new Date(), 'yyyy-MM-dd'),
        })));
      }
    }
  }, [existingProgress, cards, spacedRepMode]);

  const saveProgressMutation = useMutation({
    mutationFn: async (progressData) => {
      if (!deck?.id) return;
      const user = await base44.auth.me();
      if (existingProgress) {
        return base44.entities.DeckProgress.update(existingProgress.id, {
          cards_completed: progressData.cards_completed,
          card_data: progressData.card_data,
          last_practiced_date: format(new Date(), 'yyyy-MM-dd'),
        });
      } else {
        return base44.entities.DeckProgress.create({
          deck_id: deck.id,
          user_email: user.email,
          mode: 'spaced_repetition',
          total_cards: cards.length,
          cards_completed: progressData.cards_completed,
          correct_answers: 0,
          score_percentage: 0,
          card_data: progressData.card_data,
          last_practiced_date: format(new Date(), 'yyyy-MM-dd'),
        });
      }
    },
    onSuccess: () => {
      if (deck?.id) {
        queryClient.invalidateQueries({ queryKey: ['deckProgress', deck.id] });
      }
    },
  });

  if (!cards || cards.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <p className="text-gray-500">No flashcards were generated.</p>
        </CardContent>
      </Card>
    );
  }

  const displayCards = isShuffled ? shuffledCards : cards;
  const currentCard = displayCards[currentIndex];

  if (!currentCard || !currentCard.front || !currentCard.back) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <p className="text-gray-500">Invalid flashcard data.</p>
        </CardContent>
      </Card>
    );
  }

  const handleNext = () => {
    setIsFlipped(false);
    setTimeout(() => setCurrentIndex((prev) => (prev + 1) % displayCards.length), 150);
  };
  
  const handlePrev = () => {
    setIsFlipped(false);
    setTimeout(() => setCurrentIndex((prev) => (prev - 1 + displayCards.length) % displayCards.length), 150);
  };

  const handleShuffle = () => {
    const shuffled = [...cards].sort(() => Math.random() - 0.5);
    setShuffledCards(shuffled);
    setIsShuffled(true);
    setCurrentIndex(0);
    setIsFlipped(false);
    toast.success('Cards shuffled!');
  };

  const handleResetOrder = () => {
    setIsShuffled(false);
    setCurrentIndex(0);
    setIsFlipped(false);
    toast.success('Original order restored');
  };

  const handleDifficulty = (difficulty) => {
    const today = new Date();
    let nextReviewDays;
    
    switch (difficulty) {
      case 'easy':
        nextReviewDays = 7;
        break;
      case 'medium':
        nextReviewDays = 3;
        break;
      case 'hard':
        nextReviewDays = 1;
        break;
      default:
        nextReviewDays = 3;
    }

    const actualCardIndex = isShuffled 
      ? cards.findIndex(c => c.front === currentCard.front && c.back === currentCard.back)
      : currentIndex;

    const updatedSchedule = [...cardSchedule];
    updatedSchedule[actualCardIndex] = {
      card_index: actualCardIndex,
      difficulty,
      next_review_date: format(addDays(today, nextReviewDays), 'yyyy-MM-dd'),
    };
    setCardSchedule(updatedSchedule);

    if (currentIndex < displayCards.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setIsFlipped(false);
    } else {
      saveProgressMutation.mutate({
        cards_completed: cards.length,
        card_data: updatedSchedule,
      });
      toast.success('Review session completed!');
      setCurrentIndex(0);
      setIsFlipped(false);
    }
  };

  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex flex-col items-center">
          {/* Mode Toggle and Controls */}
          <div className="w-full max-w-lg flex flex-col sm:flex-row justify-between items-center gap-3 mb-4">
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <Button
                variant={spacedRepMode ? "default" : "outline"}
                size="sm"
                onClick={() => {
                  setSpacedRepMode(!spacedRepMode);
                  setIsFlipped(false);
                }}
                className="flex-1 sm:flex-none"
              >
                <Brain className="w-4 h-4 mr-2" />
                Spaced Rep {spacedRepMode && '✓'}
              </Button>
              {!isShuffled ? (
                <Button variant="outline" size="sm" onClick={handleShuffle} className="flex-1 sm:flex-none">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Shuffle
                </Button>
              ) : (
                <Button variant="outline" size="sm" onClick={handleResetOrder} className="flex-1 sm:flex-none">
                  Reset Order
                </Button>
              )}
            </div>
            {spacedRepMode && (
              <Badge variant="outline" className="text-xs">
                <CheckCircle className="w-3 h-3 mr-1" />
                {currentIndex} / {displayCards.length} reviewed
              </Badge>
            )}
          </div>

          {spacedRepMode && (
            <Progress value={((currentIndex + 1) / displayCards.length) * 100} className="h-2 w-full max-w-lg mb-4" />
          )}

          {/* Flashcard */}
          <div className="relative w-full max-w-lg h-64 sm:h-72 [perspective:1000px]">
            <motion.div
              className="relative w-full h-full transition-transform duration-700 [transform-style:preserve-3d]"
              initial={false}
              animate={{ rotateY: isFlipped ? 180 : 0 }}
              transition={{ duration: 0.6, ease: "easeInOut" }}
            >
              <div className={`absolute w-full h-full [backface-visibility:hidden] flex items-center justify-center p-4 sm:p-6 border-2 rounded-lg shadow-md overflow-y-auto ${
                spacedRepMode ? 'bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200' : 'bg-white'
              }`}>
                <p className="text-lg sm:text-xl text-center whitespace-pre-wrap font-semibold">{currentCard.front}</p>
              </div>
              <div className={`absolute w-full h-full [backface-visibility:hidden] [transform:rotateY(180deg)] flex items-center justify-center p-4 sm:p-6 border-2 rounded-lg shadow-md overflow-y-auto ${
                spacedRepMode ? 'bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200' : 'bg-orange-50'
              }`}>
                <p className="text-base sm:text-lg text-center whitespace-pre-wrap">{currentCard.back}</p>
              </div>
            </motion.div>
          </div>
          
          <Button variant="ghost" onClick={() => setIsFlipped(!isFlipped)} className="mt-4 w-full max-w-lg sm:w-auto">
            <RefreshCw className="mr-2 h-4 w-4"/>
            Flip Card
          </Button>

          {/* Spaced Repetition Controls */}
          {spacedRepMode && isFlipped && (
            <div className="mt-4 space-y-3 w-full max-w-lg">
              <p className="text-sm text-gray-600 text-center">How well did you know this?</p>
              <div className="grid grid-cols-3 gap-2 sm:gap-3">
                <Button
                  onClick={() => handleDifficulty('hard')}
                  variant="outline"
                  size="sm"
                  className="border-red-300 hover:bg-red-50 hover:border-red-400"
                >
                  <div className="text-center">
                    <div className="font-semibold text-red-600 text-xs sm:text-sm">Hard</div>
                    <div className="text-[10px] sm:text-xs text-gray-500">1 day</div>
                  </div>
                </Button>
                <Button
                  onClick={() => handleDifficulty('medium')}
                  variant="outline"
                  size="sm"
                  className="border-yellow-300 hover:bg-yellow-50 hover:border-yellow-400"
                >
                  <div className="text-center">
                    <div className="font-semibold text-yellow-600 text-xs sm:text-sm">Medium</div>
                    <div className="text-[10px] sm:text-xs text-gray-500">3 days</div>
                  </div>
                </Button>
                <Button
                  onClick={() => handleDifficulty('easy')}
                  variant="outline"
                  size="sm"
                  className="border-green-300 hover:bg-green-50 hover:border-green-400"
                >
                  <div className="text-center">
                    <div className="font-semibold text-green-600 text-xs sm:text-sm">Easy</div>
                    <div className="text-[10px] sm:text-xs text-gray-500">7 days</div>
                  </div>
                </Button>
              </div>
            </div>
          )}

          {/* Navigation Controls */}
          <div className="flex items-center justify-between w-full max-w-lg mt-6 gap-4">
            <Button onClick={handlePrev} variant="outline" size="icon" disabled={cards.length <= 1} className="shrink-0">
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <p className="font-medium text-gray-600 text-sm sm:text-base">{currentIndex + 1} / {displayCards.length}</p>
            <Button onClick={handleNext} variant="outline" size="icon" disabled={cards.length <= 1} className="shrink-0">
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}