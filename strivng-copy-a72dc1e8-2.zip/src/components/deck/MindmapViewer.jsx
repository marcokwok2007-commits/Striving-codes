import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, MousePointer } from 'lucide-react';

export default function MindmapViewer({ data, deck, onPageReferenceClick }) {
  if (!data?.root) {
    return <p className="text-center text-gray-500 py-10">No mind map data was generated.</p>;
  }

  const renderNode = (node, level = 0) => {
    if (!node) return null;

    const getNodeStyle = () => {
      if (level === 0) {
        // Root node - black background
        return 'bg-black text-white border-gray-800';
      } else if (level === 1) {
        // Main categories - light orange
        return 'bg-orange-100 text-orange-900 border-orange-300';
      } else {
        // Sub-items - soft blue
        return 'bg-blue-50 text-blue-900 border-blue-200';
      }
    };

    const getTextSize = () => {
      if (level === 0) return 'text-xl';
      if (level === 1) return 'text-base';
      return 'text-sm';
    };

    const hasSourceFile = !!deck?.source_file_url;

    const handlePageClick = (e, pageRef) => {
      e.preventDefault();
      e.stopPropagation();
      if (onPageReferenceClick) {
        onPageReferenceClick(pageRef);
      }
    };

    return (
      <div key={node.topic} className={`mb-4 ${level > 0 ? 'ml-8' : ''}`}>
        <div
          className={`inline-flex flex-col px-4 py-2 rounded-lg border-2 font-semibold ${getNodeStyle()} ${getTextSize()}`}
        >
          <span>{node.topic}</span>
          {node.page_reference && (
            <div className="flex items-center gap-2 mt-2 text-xs font-normal opacity-80">
              <FileText className="w-3 h-3" />
              <span>
                {hasSourceFile ? (
                  <button
                    onClick={(e) => handlePageClick(e, node.page_reference)}
                    className="hover:underline flex items-center gap-1 font-semibold hover:opacity-100 transition-opacity"
                    type="button"
                  >
                    Page {node.page_reference}
                    <MousePointer className="w-3 h-3" />
                  </button>
                ) : (
                  `Page ${node.page_reference}`
                )}
              </span>
            </div>
          )}
        </div>
        {node.children && node.children.length > 0 && (
          <div className="mt-2">
            {node.children.map((child, idx) => renderNode(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Mind Map</CardTitle>
        {deck?.source_file_url && (
          <p className="text-xs text-gray-500 mt-1">
            💡 Click on page numbers to view the reference in the source file (opens in preview mode, no download!)
          </p>
        )}
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          {renderNode(data.root)}
        </div>
      </CardContent>
    </Card>
  );
}