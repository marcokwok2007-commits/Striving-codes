import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Trash2, Save } from 'lucide-react';
import { toast } from 'sonner';
import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import {
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

export default function FlashcardEditorNew({ deck, onSave, onCancel }) {
  const [editedCards, setEditedCards] = useState(
    deck.flashcards?.cards && Array.isArray(deck.flashcards.cards) 
      ? [...deck.flashcards.cards]
      : [{ front: '', back: '' }]
  );
  const queryClient = useQueryClient();

  const updateMutation = useMutation({
    mutationFn: async (updatedCards) => {
      return base44.entities.Deck.update(deck.id, {
        flashcards: { cards: updatedCards }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['decks'] });
      toast.success('Flashcards saved successfully!');
      if (onSave) onSave();
    },
    onError: (error) => {
      toast.error('Failed to save flashcards: ' + error.message);
    }
  });

  const handleAddCard = () => {
    setEditedCards([...editedCards, { front: '', back: '' }]);
    toast.success('New flashcard added');
  };

  const handleDeleteCard = (index) => {
    if (editedCards.length === 1) {
      toast.error('Deck must have at least one flashcard');
      return;
    }
    setEditedCards(editedCards.filter((_, i) => i !== index));
    toast.success('Flashcard deleted');
  };

  const handleEditCard = (index, field, value) => {
    const updated = [...editedCards];
    updated[index] = { ...updated[index], [field]: value };
    setEditedCards(updated);
  };

  const handleSave = () => {
    const validCards = editedCards.filter(card => card.front?.trim() && card.back?.trim());
    
    if (validCards.length === 0) {
      toast.error('Please ensure all flashcards have both question and answer');
      return;
    }

    const incompleteCards = editedCards.filter(card => 
      (card.front?.trim() && !card.back?.trim()) || 
      (!card.front?.trim() && card.back?.trim())
    );
    
    if (incompleteCards.length > 0) {
      toast.error('All flashcards must have both question and answer');
      return;
    }

    updateMutation.mutate(validCards);
  };

  return (
    <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle>Edit Flashcards</DialogTitle>
      </DialogHeader>
      
      <div className="space-y-4 py-4">
        {editedCards.map((card, index) => (
          <Card key={index} className="p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-semibold">Flashcard {index + 1}</h4>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => handleDeleteCard(index)}
                className="text-red-500 hover:text-red-700 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
            <div className="space-y-3">
              <div>
                <Label>Question / Front</Label>
                <Textarea
                  value={card.front || ''}
                  onChange={(e) => handleEditCard(index, 'front', e.target.value)}
                  placeholder="Enter the question, term, or prompt..."
                  className="mt-1"
                  rows={3}
                />
              </div>
              <div>
                <Label>Answer / Back</Label>
                <Textarea
                  value={card.back || ''}
                  onChange={(e) => handleEditCard(index, 'back', e.target.value)}
                  placeholder="Enter the answer, definition, or explanation..."
                  className="mt-1"
                  rows={3}
                />
              </div>
            </div>
          </Card>
        ))}
        
        <Button
          onClick={handleAddCard}
          variant="outline"
          className="w-full border-dashed border-2 py-6"
        >
          <Plus className="w-5 h-5 mr-2" />
          Add New Flashcard
        </Button>
      </div>

      <DialogFooter>
        <div className="flex justify-between items-center w-full">
          <p className="text-sm text-gray-600">
            {editedCards.length} {editedCards.length === 1 ? 'flashcard' : 'flashcards'} total
          </p>
          <div className="flex gap-3">
            <Button variant="outline" onClick={onCancel} disabled={updateMutation.isPending}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={updateMutation.isPending}>
              {updateMutation.isPending ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </div>
      </DialogFooter>
    </DialogContent>
  );
}