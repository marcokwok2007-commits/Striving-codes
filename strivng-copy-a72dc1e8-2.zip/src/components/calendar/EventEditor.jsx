import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { format } from 'date-fns';

export default function EventEditor({ date, onFinished }) {
    const [title, setTitle] = useState('');
    const [priority, setPriority] = useState('medium');
    const queryClient = useQueryClient();

    const mutation = useMutation({
        mutationFn: (goalData) => base44.entities.Goal.create(goalData),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['goals'] });
            onFinished();
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!title.trim()) {
            alert("Title is required.");
            return;
        }
        mutation.mutate({ 
            title: title.trim(), 
            target_date: format(date, 'yyyy-MM-dd'), 
            priority 
        });
    };

    return (
        <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
                <DialogTitle>Add New Goal</DialogTitle>
                <DialogDescription>
                    Schedule a new goal for {format(date, 'PPP')}.
                </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-6 py-4">
                 <div className="space-y-2">
                    <Label htmlFor="title">Title</Label>
                    <Input 
                        id="title" 
                        value={title} 
                        onChange={(e) => setTitle(e.target.value)} 
                        placeholder="e.g., Study for Math Exam"
                        required 
                    />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="priority">Priority</Label>
                    <Select onValueChange={setPriority} defaultValue={priority}>
                        <SelectTrigger id="priority">
                            <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="low">Low</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="high">High</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                 <DialogFooter>
                    <Button type="button" variant="ghost" onClick={onFinished}>Cancel</Button>
                    <Button type="submit" disabled={mutation.isPending}>
                        {mutation.isPending ? 'Saving...' : 'Save Goal'}
                    </Button>
                </DialogFooter>
            </form>
        </DialogContent>
    );
}