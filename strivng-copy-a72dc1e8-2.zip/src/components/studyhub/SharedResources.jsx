import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Layers, Eye, Trash2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import ViewDeckDialog from '../deck/ViewDeckDialog';
import { toast } from 'sonner';

function SharedDeckCard({ resource, deck, isAdmin }) {
    const queryClient = useQueryClient();

    const deleteMutation = useMutation({
        mutationFn: (resourceId) => base44.entities.SharedResource.delete(resourceId),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['shared_resources'] });
            toast.success('Resource deleted successfully!');
        },
        onError: () => {
            toast.error('Failed to delete resource.');
        }
    });

    if (!deck) {
        return null;
    }

    return (
        <Card>
            <CardContent className="p-4 flex justify-between items-center">
                <div className="flex-1">
                    <h4 className="font-semibold flex items-center gap-2">
                        <Layers className="w-4 h-4 text-orange-500" />
                        {resource.resource_title}
                    </h4>
                    <p className="text-xs text-gray-500 mt-1">Shared by {resource.shared_by_name}</p>
                </div>
                <div className="flex items-center gap-2">
                    <Dialog>
                        <DialogTrigger asChild>
                            <Button variant="outline" size="sm">
                                <Eye className="w-4 h-4 mr-2" />View
                            </Button>
                        </DialogTrigger>
                        <ViewDeckDialog deck={deck} readOnly={true} />
                    </Dialog>
                    {isAdmin && (
                        <AlertDialog>
                            <AlertDialogTrigger asChild>
                                <Button variant="ghost" size="icon" disabled={deleteMutation.isPending}>
                                    {deleteMutation.isPending ? (
                                        <Loader2 className="w-4 h-4 animate-spin" />
                                    ) : (
                                        <Trash2 className="w-4 h-4 text-red-500" />
                                    )}
                                </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                                <AlertDialogHeader>
                                    <AlertDialogTitle>Delete Resource</AlertDialogTitle>
                                    <AlertDialogDescription>
                                        Are you sure you want to delete this shared resource? This action cannot be undone.
                                    </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction 
                                        onClick={() => deleteMutation.mutate(resource.id)}
                                        className="bg-red-600 hover:bg-red-700"
                                    >
                                        Delete
                                    </AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}

export default function SharedResources({ groupId }) {
    const { data: currentUser } = useQuery({ 
        queryKey: ['currentUser'], 
        queryFn: () => base44.auth.me() 
    });

    const { data: group } = useQuery({
        queryKey: ['group', groupId],
        queryFn: () => base44.entities.StudyGroup.get(groupId),
        enabled: !!groupId
    });

    const { data: sharedResources = [], isLoading: isLoadingResources } = useQuery({
        queryKey: ['shared_resources', groupId],
        queryFn: () => base44.entities.SharedResource.filter({ group_id: groupId }, '-created_date'),
        refetchInterval: 10000
    });
    
    const deckIds = sharedResources.filter(r => r.resource_type === 'deck').map(r => r.resource_id);

    const { data: decks = [], isLoading: isLoadingDecks } = useQuery({
        queryKey: ['shared_decks', deckIds],
        queryFn: () => base44.entities.Deck.filter({ id: { '$in': deckIds } }),
        enabled: deckIds.length > 0
    });
    
    const decksById = decks.reduce((acc, deck) => {
        acc[deck.id] = deck;
        return acc;
    }, {});
    
    const isLoading = isLoadingResources || isLoadingDecks;
    const isAdmin = group?.created_by === currentUser?.email;

    return (
        <div className="mt-4 space-y-4">
            {isLoading && <Loader2 className="mx-auto w-6 h-6 animate-spin" />}
            {!isLoading && sharedResources.length === 0 && (
                <p className="text-center text-gray-500">No resources have been shared in this group yet.</p>
            )}
            {!isLoading && sharedResources.map(resource => {
                if (resource.resource_type === 'deck') {
                    const deck = decksById[resource.resource_id];
                    if (!deck) return null;
                    return <SharedDeckCard key={resource.id} resource={resource} deck={deck} isAdmin={isAdmin} />
                }
                return null;
            })}
        </div>
    );
}