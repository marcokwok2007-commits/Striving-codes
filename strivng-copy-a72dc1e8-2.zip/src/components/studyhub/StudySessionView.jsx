
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Maximize, Minimize, Pause, Play, StopCircle, X, User, Users } from 'lucide-react';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import ProfilePreviewCard from './ProfilePreviewCard';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';

const formatTime = (totalSeconds) => {
    if (isNaN(totalSeconds) || totalSeconds < 0) return "00:00:00";
    const hours = Math.floor(totalSeconds / 3600).toString().padStart(2, '0');
    const minutes = Math.floor((totalSeconds % 3600) / 60).toString().padStart(2, '0');
    const seconds = (totalSeconds % 60).toString().padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
};

const MemberCard = React.memo(({ member, currentUser }) => {
    const [elapsedTime, setElapsedTime] = useState(0);
    const [open, setOpen] = useState(false);

    useEffect(() => {
        if (member.study_status !== 'studying' || !member.current_session_start) return;
        
        const startTime = new Date(member.current_session_start).getTime();
        const updateElapsedTime = () => {
            setElapsedTime(Math.floor((Date.now() - startTime) / 1000));
        };

        updateElapsedTime();
        const interval = setInterval(updateElapsedTime, 1000);
        return () => clearInterval(interval);
    }, [member.study_status, member.current_session_start]);
    
    const displayName = member.full_name || 'Student';
    const isCurrentUser = currentUser && member.email === currentUser.email;
    
    return (
         <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <div className="bg-white p-6 rounded-2xl shadow-md border flex flex-col items-center gap-2 w-52 cursor-pointer hover:shadow-lg hover:border-orange-200 transition-all">
                    <Avatar className="w-16 h-16">
                        <AvatarImage src={member.avatar_url} />
                        <AvatarFallback><User className="w-8 h-8" /></AvatarFallback>
                    </Avatar>
                    <p className="font-semibold text-orange-600">
                      {displayName} {isCurrentUser && '(You)'}
                    </p>
                    <p className="text-2xl font-mono font-bold text-gray-800">{formatTime(elapsedTime)}</p>
                    <p className="text-sm text-gray-500 truncate w-full text-center">{member.current_goal_title}</p>
                </div>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
                <DialogHeader>
                    <DialogTitle>Student Profile</DialogTitle>
                </DialogHeader>
                <ProfilePreviewCard member={member} />
            </DialogContent>
        </Dialog>
    );
});

MemberCard.displayName = 'MemberCard';

export default function StudySessionView({ goal, group, onStopSession, onExit, initialSeconds = 0, onGroupChange }) {
    const [seconds, setSeconds] = useState(initialSeconds);
    const [isPaused, setIsPaused] = useState(false);
    const [isFocusMode, setFocusMode] = useState(false);
    const [selectedGroupId, setSelectedGroupId] = useState(group?.id || null);
    
    const { data: currentUser } = useQuery({ 
      queryKey: ['currentUser'], 
      queryFn: () => base44.auth.me(),
      staleTime: Infinity,
      refetchOnWindowFocus: false,
    });

    const { data: myGroups = [] } = useQuery({
        queryKey: ['myGroups', currentUser?.email],
        queryFn: async () => {
            if (!currentUser?.email) return [];
            return base44.entities.StudyGroup.filter({ members: { $in: [currentUser.email] } });
        },
        enabled: !!currentUser,
        staleTime: 300000,
        refetchOnWindowFocus: false,
    });

    const { data: myGroupMembers = [] } = useQuery({
        queryKey: ['myGroupMembers', selectedGroupId],
        queryFn: async () => {
            if (!selectedGroupId) return [];
            const selectedGroup = await base44.entities.StudyGroup.get(selectedGroupId);
            return selectedGroup?.members || [];
        },
        enabled: !!selectedGroupId,
        staleTime: 300000,
        refetchOnWindowFocus: false,
    });

    const { data: studyingMembers = [] } = useQuery({
        queryKey: ['studyingMembers', myGroupMembers],
        queryFn: async () => {
            if (myGroupMembers.length === 0) return [];
            return base44.entities.User.filter({ 
                study_status: 'studying',
                email: { $in: myGroupMembers }
            });
        },
        refetchInterval: 10000,
        enabled: myGroupMembers.length > 0,
        refetchOnWindowFocus: false,
    });

    useEffect(() => {
        setSeconds(initialSeconds);
    }, [initialSeconds]);

    useEffect(() => {
        if (isPaused) return;
        
        const interval = setInterval(() => {
            setSeconds(prev => prev + 1);
        }, 1000);
        
        return () => clearInterval(interval);
    }, [isPaused]);

    const handleStop = useCallback(() => {
        onStopSession();
    }, [onStopSession]);
    
    const togglePause = useCallback(() => {
        setIsPaused(prev => !prev);
    }, []);

    const toggleFocusMode = useCallback(() => {
        setFocusMode(prev => !prev);
    }, []);

    const handleGroupChange = useCallback((groupId) => {
        setSelectedGroupId(groupId === 'none' ? null : groupId);
        const newGroup = groupId === 'none' ? null : myGroups.find(g => g.id === groupId);
        onGroupChange?.(newGroup);
    }, [myGroups, onGroupChange]);

    const formattedTime = useMemo(() => formatTime(seconds), [seconds]);

    const currentGroupName = selectedGroupId ? myGroups.find(g => g.id === selectedGroupId)?.name : 'No Group';

    return (
        <div className="min-h-screen bg-gradient-to-br from-orange-50 to-rose-50 p-6 md:p-8 w-full">
            <header className="flex justify-between items-center mb-10">
                {!isFocusMode && (
                    <div className="bg-white px-4 py-2 rounded-lg shadow-sm">
                        <p className="text-4xl font-mono font-bold text-orange-600">{formattedTime}</p>
                        <div className="flex items-center gap-2 mt-2">
                            <p className="text-sm text-gray-500">Study Session: {studyingMembers.length} member(s)</p>
                            <span className="text-gray-400">•</span>
                            <Select value={selectedGroupId || 'none'} onValueChange={handleGroupChange}>
                                <SelectTrigger className="h-7 text-xs border-none bg-transparent hover:bg-gray-100 w-auto min-w-[120px]">
                                    <SelectValue>
                                        <div className="flex items-center gap-1">
                                            <Users className="w-3 h-3" />
                                            <span>{currentGroupName}</span>
                                        </div>
                                    </SelectValue>
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="none">
                                        <div className="flex items-center gap-2">
                                            <Users className="w-4 h-4" />
                                            <span>No Group</span>
                                        </div>
                                    </SelectItem>
                                    {myGroups.map(g => (
                                        <SelectItem key={g.id} value={g.id}>
                                            <div className="flex items-center gap-2">
                                                <Users className="w-4 h-4" />
                                                <span>{g.name}</span>
                                            </div>
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                )}
                {isFocusMode && <div></div>}
                <div className="flex items-center gap-2">
                    <Button variant="outline" className="bg-white" onClick={toggleFocusMode}>
                        {isFocusMode ? (
                          <><Minimize className="w-4 h-4 mr-2" /> Exit Focus</>
                        ) : (
                          <><Maximize className="w-4 h-4 mr-2" /> Focus Mode</>
                        )}
                    </Button>
                    <Button variant="outline" className="bg-white" onClick={togglePause}>
                        {isPaused ? (
                          <><Play className="w-4 h-4 mr-2" /> Resume</>
                        ) : (
                          <><Pause className="w-4 h-4 mr-2" /> Pause</>
                        )}
                    </Button>
                    <Button variant="outline" className="bg-white" onClick={handleStop}>
                      <StopCircle className="w-4 h-4 mr-2" /> Stop
                    </Button>
                    <Button variant="ghost" onClick={onExit}>
                      <X className="w-4 h-4 mr-2" /> Exit
                    </Button>
                </div>
            </header>

            <main>
                {isFocusMode ? (
                    <div className="flex flex-col items-center justify-center h-[60vh] text-center">
                        <p className="text-8xl md:text-9xl font-mono font-bold text-orange-600 tracking-wider">
                            {formattedTime}
                        </p>
                        <p className="text-gray-500 mt-4">Stay focused. You can do this.</p>
                    </div>
                ) : (
                    <>
                        <h2 className="text-2xl font-bold text-gray-800 mb-6">
                            Studying Now {currentGroupName !== 'No Group' && `in ${currentGroupName}`}
                        </h2>
                        {studyingMembers.length > 0 ? (
                            <div className="flex flex-wrap gap-6">
                                {studyingMembers.map(member => (
                                    <MemberCard key={member.id} member={member} currentUser={currentUser} />
                                ))}
                            </div>
                        ) : (
                            <p className="text-gray-500 mt-10 text-center">
                              {selectedGroupId 
                                ? "No one from your group is studying right now. Be the first!" 
                                : "You're studying alone. Select a group above to study with others."}
                            </p>
                        )}
                    </>
                )}
            </main>
        </div>
    );
}
