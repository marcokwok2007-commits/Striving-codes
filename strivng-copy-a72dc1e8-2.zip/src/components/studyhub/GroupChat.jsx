import React, { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Loader2, Send } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const Message = ({ msg, isCurrentUser }) => {
    const formattedTime = (() => {
        try {
            const timestamp = new Date(msg.created_date);
            
            // Add 8 hours to fix the timezone offset
            timestamp.setHours(timestamp.getHours() + 8);
            
            const day = timestamp.getDate().toString().padStart(2, '0');
            const month = (timestamp.getMonth() + 1).toString().padStart(2, '0');
            const year = timestamp.getFullYear();
            const hours = timestamp.getHours().toString().padStart(2, '0');
            const minutes = timestamp.getMinutes().toString().padStart(2, '0');
            
            return `${day}/${month}/${year}, ${hours}:${minutes}`;
        } catch (error) {
            console.error('Error formatting time:', error);
            return 'Invalid date';
        }
    })();

    return (
        <div className={`flex items-start gap-3 ${isCurrentUser ? 'flex-row-reverse' : ''}`}>
            {!isCurrentUser && (
                <Avatar className="w-8 h-8">
                    <AvatarImage src={msg.user_avatar_url} />
                    <AvatarFallback>{msg.user_full_name?.charAt(0) || '?'}</AvatarFallback>
                </Avatar>
            )}
            <div className={`flex flex-col ${isCurrentUser ? 'items-end' : 'items-start'}`}>
                <div className={`p-3 rounded-lg max-w-xs md:max-w-md ${isCurrentUser ? 'bg-orange-500 text-white' : 'bg-gray-100'}`}>
                    {!isCurrentUser && <p className="font-semibold text-sm mb-1">{msg.user_full_name}</p>}
                    <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                </div>
                <p className="text-xs text-gray-400 mt-1">{formattedTime}</p>
            </div>
        </div>
    );
};

export default function GroupChat({ groupId }) {
    const [newMessage, setNewMessage] = useState('');
    const queryClient = useQueryClient();
    const messagesEndRef = useRef(null);

    const { data: currentUser } = useQuery({ queryKey: ['currentUser'], queryFn: () => base44.auth.me() });

    const { data: messages = [], isLoading } = useQuery({
        queryKey: ['messages', groupId],
        queryFn: () => base44.entities.GroupMessage.filter({ group_id: groupId }, '-created_date', 50),
        refetchInterval: 5000,
    });

    const mutation = useMutation({
        mutationFn: (messageData) => base44.entities.GroupMessage.create(messageData),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['messages', groupId] });
            setNewMessage('');
        }
    });

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const handleSend = (e) => {
        e.preventDefault();
        if (!newMessage.trim() || !currentUser) return;

        mutation.mutate({
            group_id: groupId,
            content: newMessage.trim(),
            user_full_name: currentUser.full_name,
            user_avatar_url: currentUser.avatar_url,
        });
    };
    
    const sortedMessages = messages.slice().reverse();

    return (
        <div className="flex flex-col h-[60vh] border rounded-lg bg-white mt-4">
            <div className="flex-1 p-4 space-y-4 overflow-y-auto">
                {isLoading && <Loader2 className="mx-auto w-6 h-6 animate-spin" />}
                {!isLoading && sortedMessages.length === 0 && (
                    <p className="text-center text-gray-500">No messages yet. Start the conversation!</p>
                )}
                {sortedMessages.map(msg => (
                    <Message key={msg.id} msg={msg} isCurrentUser={msg.created_by === currentUser?.email} />
                ))}
                <div ref={messagesEndRef} />
            </div>
            <div className="p-4 border-t bg-gray-50">
                <form onSubmit={handleSend} className="flex gap-2">
                    <Input
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Type a message..."
                        disabled={mutation.isPending}
                    />
                    <Button type="submit" disabled={mutation.isPending || !newMessage.trim()}>
                        {mutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                    </Button>
                </form>
            </div>
        </div>
    );
}