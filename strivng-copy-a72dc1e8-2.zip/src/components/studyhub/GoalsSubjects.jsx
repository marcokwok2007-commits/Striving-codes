
import React, { useState, useCallback, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Plus, CheckCircle, Calendar as CalendarIcon, Trash2, Edit, Star } from "lucide-react";
import { format, subDays, isAfter } from 'date-fns';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const GoalForm = ({ goal, onFinished }) => {
    const [title, setTitle] = useState(goal?.title || '');
    const [subject, setSubject] = useState(goal?.subject || '');
    const [targetDate, setTargetDate] = useState(goal?.target_date ? new Date(goal.target_date) : null);
    const [priority, setPriority] = useState(goal?.priority || 'medium');
    const queryClient = useQueryClient();

    const mutation = useMutation({
        mutationFn: (goalData) => {
            // Ensure is_ultimate is not accidentally set from the form
            const dataToSubmit = { ...goalData };
            delete dataToSubmit.is_ultimate; 
            return goal ? base44.entities.Goal.update(goal.id, dataToSubmit) : base44.entities.Goal.create(dataToSubmit);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['goals'] });
            queryClient.invalidateQueries({ queryKey: ['ultimateGoal'] }); // Invalidate ultimate goal too, in case an existing ultimate goal was updated.
            onFinished();
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!title) {
            alert("Title is required.");
            return;
        }
        mutation.mutate({ 
            title, 
            subject, 
            target_date: targetDate ? format(targetDate, 'yyyy-MM-dd') : null, 
            priority 
        });
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 p-4 bg-gray-50 rounded-lg">
            <Input placeholder="Goal Title" value={title} onChange={e => setTitle(e.target.value)} required />
            <Input placeholder="Subject (e.g., Math, History)" value={subject} onChange={e => setSubject(e.target.value)} />
            <div className="flex gap-4">
                <Popover>
                    <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal">
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {targetDate ? format(targetDate, 'PPP') : <span>Pick a target date</span>}
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={targetDate} onSelect={setTargetDate} initialFocus /></PopoverContent>
                </Popover>
                <Select onValueChange={setPriority} defaultValue={priority}>
                    <SelectTrigger><SelectValue placeholder="Priority" /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                </Select>
            </div>
            <div className="flex justify-end gap-2">
                <Button type="button" variant="ghost" onClick={onFinished}>Cancel</Button>
                <Button type="submit" disabled={mutation.isPending}>
                    {mutation.isPending ? 'Saving...' : (goal ? 'Update Goal' : 'Create Goal')}
                </Button>
            </div>
        </form>
    );
};

export default function GoalsSubjects() {
    const [showForm, setShowForm] = useState(false);
    const [editingGoal, setEditingGoal] = useState(null);
    const queryClient = useQueryClient();

    const { data: goals = [], isLoading } = useQuery({
        queryKey: ['goals'],
        queryFn: async () => {
            const user = await base44.auth.me();
            return base44.entities.Goal.filter({ created_by: user.email }, '-target_date');
        },
        staleTime: 60000,
    });
    
    const { data: ultimateGoal, isLoading: isLoadingUltimate } = useQuery({
        queryKey: ['ultimateGoal'],
        queryFn: async () => {
            const user = await base44.auth.me();
            const goals = await base44.entities.Goal.filter({
                created_by: user.email,
                is_ultimate: true,
            });
            return goals[0] || null;
        },
        staleTime: 300000,
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.Goal.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['goals'] });
            queryClient.invalidateQueries({ queryKey: ['ultimateGoal'] });
        }
    });
    
    const updateStatusMutation = useMutation({
        mutationFn: ({id, status}) => base44.entities.Goal.update(id, {status}),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['goals'] });
            queryClient.invalidateQueries({ queryKey: ['ultimateGoal'] });
        }
    });

    const setUltimateGoalMutation = useMutation({
        mutationFn: async (goalToMakeUltimate) => {
            if (ultimateGoal && ultimateGoal.id === goalToMakeUltimate.id) {
                await base44.entities.Goal.update(ultimateGoal.id, { is_ultimate: false });
            } else {
                if (ultimateGoal) {
                    await base44.entities.Goal.update(ultimateGoal.id, { is_ultimate: false });
                }
                await base44.entities.Goal.update(goalToMakeUltimate.id, { is_ultimate: true });
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['goals'] });
            queryClient.invalidateQueries({ queryKey: ['ultimateGoal'] });
        },
    });

    const handleEdit = useCallback((goal) => {
        setEditingGoal(goal);
        setShowForm(true);
    }, []);

    const handleFormFinished = useCallback(() => {
        setEditingGoal(null);
        setShowForm(false);
    }, []);

    const pendingGoals = useMemo(() => goals.filter(g => g.status !== 'completed'), [goals]);
    
    const completedGoals = useMemo(() => {
        const sevenDaysAgo = subDays(new Date(), 7);
        return goals.filter(g => 
            g.status === 'completed' && isAfter(new Date(g.updated_date), sevenDaysAgo)
        );
    }, [goals]);

    return (
        <div className="space-y-6">
            <Card className="bg-white border rounded-xl shadow-sm">
                <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle className="flex items-center gap-2 text-orange-600">
                        <CheckCircle className="w-5 h-5" />
                        Manage Goals
                    </CardTitle>
                    <Button onClick={() => { setEditingGoal(null); setShowForm(!showForm); }}>
                        <Plus className="w-4 h-4 mr-2" /> {showForm ? 'Cancel' : 'New Goal'}
                    </Button>
                </CardHeader>
                <CardContent>
                    {showForm && <GoalForm goal={editingGoal} onFinished={handleFormFinished} />}
                    
                    <div className="space-y-4 mt-4">
                        <h3 className="font-semibold text-lg">Upcoming Goals</h3>
                        {isLoading && <p>Loading...</p>}
                        {pendingGoals.length === 0 && !isLoading && <p className="text-gray-500 text-sm">No upcoming goals. Create one to get started!</p>}
                        {pendingGoals.map(goal => (
                            <div key={goal.id} className="flex items-center justify-between p-3 bg-orange-50/50 rounded-lg border border-orange-100">
                                <div className="flex items-center gap-3">
                                    <button onClick={() => updateStatusMutation.mutate({id: goal.id, status: 'completed'})} className="p-1.5 rounded-full text-gray-400 hover:bg-green-100 hover:text-green-600 transition-colors">
                                        <CheckCircle className="w-5 h-5"/>
                                    </button>
                                    <div>
                                        <p className="font-medium text-gray-800">{goal.title}</p>
                                        <p className="text-sm text-gray-500">
                                            {goal.target_date ? format(new Date(goal.target_date), 'MMM dd, yyyy') : 'No due date'} {goal.subject && `- ${goal.subject}`}
                                        </p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-1">
                                    <Button 
                                        variant="ghost" 
                                        size="icon" 
                                        onClick={() => setUltimateGoalMutation.mutate(goal)}
                                        disabled={setUltimateGoalMutation.isPending || isLoadingUltimate}
                                        title={ultimateGoal?.id === goal.id ? "Unset Ultimate Goal" : "Set as Ultimate Goal"}
                                    >
                                        <Star className={`w-4 h-4 transition-colors ${ultimateGoal?.id === goal.id ? 'text-yellow-400 fill-yellow-400' : 'text-gray-400 hover:text-yellow-400'}`}/>
                                    </Button>
                                    <Button variant="ghost" size="icon" onClick={() => handleEdit(goal)}><Edit className="w-4 h-4"/></Button>
                                    <AlertDialog>
                                        <AlertDialogTrigger asChild><Button variant="ghost" size="icon"><Trash2 className="w-4 h-4 text-red-500"/></Button></AlertDialogTrigger>
                                        <AlertDialogContent>
                                            <AlertDialogHeader><AlertDialogTitle>Are you sure?</AlertDialogTitle><AlertDialogDescription>This will permanently delete your goal.</AlertDialogDescription></AlertDialogHeader>
                                            <AlertDialogFooter>
                                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                                <AlertDialogAction onClick={() => deleteMutation.mutate(goal.id)}>Delete</AlertDialogAction>
                                            </AlertDialogFooter>
                                        </AlertDialogContent>
                                    </AlertDialog>
                                </div>
                            </div>
                        ))}
                    </div>

                    <div className="space-y-4 mt-8">
                        <h3 className="font-semibold text-lg">Recently Completed Goals (Last 7 Days)</h3>
                        {completedGoals.length === 0 && <p className="text-gray-500 text-sm">No recently completed goals.</p>}
                        {completedGoals.map(goal => (
                             <div key={goal.id} className="flex items-center gap-3 p-3 bg-green-50 rounded-lg text-gray-500 line-through">
                                <CheckCircle className="w-5 h-5 text-green-500"/>
                                <p>{goal.title}</p>
                            </div>
                        ))}
                    </div>

                </CardContent>
            </Card>
        </div>
    );
}
