
import React, { useState, useEffect, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, Plus, Loader2, ArrowRight, Settings, Trash2, LogOut, Copy, MessageSquare, Layers } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { format, startOfWeek, startOfMonth } from 'date-fns';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog";
import GroupChat from './GroupChat';
import SharedResources from './SharedResources';
import { toast } from "sonner";

const GroupCard = ({ group, onSelect, isMember }) => (
    <Card className="hover:shadow-lg transition-shadow">
        <CardHeader>
            <CardTitle>{group.name}</CardTitle>
            <CardDescription>{group.description}</CardDescription>
        </CardHeader>
        <CardFooter className="flex justify-between">
            <span className="text-sm text-gray-500">{group.members?.length || 0} members</span>
            <Button onClick={() => onSelect(group)} size="sm">
                {isMember ? 'View' : 'Join'} <ArrowRight className="w-4 h-4 ml-2"/>
            </Button>
        </CardFooter>
    </Card>
);

const GroupSettings = ({ group, onBack }) => {
    const queryClient = useQueryClient();
    const {data: currentUser} = useQuery({ 
        queryKey: ['currentUser'], 
        queryFn: () => base44.auth.me(),
        staleTime: Infinity,
    });
    const [isPrivate, setIsPrivate] = useState(group.is_private === true);
    
    const { data: memberDetails = [] } = useQuery({
        queryKey: ['groupMemberDetails', group.members],
        queryFn: () => base44.entities.User.filter({ email: { $in: group.members || [] } }),
        enabled: !!group.members && group.members.length > 0,
        staleTime: 60000,
    });
    
    const updateGroupMutation = useMutation({
        mutationFn: async (data) => base44.entities.StudyGroup.update(group.id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['myGroups'] });
            queryClient.invalidateQueries({ queryKey: ['publicGroups'] });
            queryClient.invalidateQueries({ queryKey: ['groupMemberDetails'] });
            toast.success('Group settings updated!');
        },
        onError: (error) => toast.error('Failed to update: ' + error.message)
    });

    const deleteGroupMutation = useMutation({
        mutationFn: (id) => base44.entities.StudyGroup.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['myGroups'] });
            queryClient.invalidateQueries({ queryKey: ['publicGroups'] });
            onBack();
            toast.success('Group deleted successfully!');
        },
        onError: (error) => toast.error('Failed to delete: ' + error.message)
    });
    
    const kickMember = (email) => {
        const updatedMembers = (group.members || []).filter(m => m !== email);
        updateGroupMutation.mutate({ members: updatedMembers });
    };
    
    const handleTogglePrivacy = (checked) => {
        setIsPrivate(checked);
        updateGroupMutation.mutate({ is_private: checked });
    };

    const inviteLink = `${window.location.origin}${window.location.pathname}?join_group_id=${group.id}`;

    return (
        <DialogContent>
            <DialogHeader>
                <DialogTitle>Group Settings</DialogTitle>
                <DialogDescription>Manage settings for "{group.name}"</DialogDescription>
            </DialogHeader>
            <div className="space-y-6 pt-4 max-h-[60vh] overflow-y-auto pr-2">
                <div>
                    <h4 className="font-semibold mb-2">Invite Link</h4>
                    <div className="flex items-center gap-2 mt-2">
                        <Input value={inviteLink} readOnly/>
                        <Button onClick={() => {
                            navigator.clipboard.writeText(inviteLink);
                            toast.info('Link copied!');
                        }} size="sm"><Copy className="w-4 h-4 mr-2"/>Copy</Button>
                    </div>
                </div>
                <div>
                    <h4 className="font-semibold mb-2">Privacy Settings</h4>
                    <div className="flex items-center justify-between space-x-2 p-3 bg-gray-50 rounded-lg">
                        <div className="flex-1">
                            <Label htmlFor="privacy-mode" className="font-medium">Private Group</Label>
                            <p className="text-sm text-gray-500">Only members with the invite link can join</p>
                        </div>
                        <Switch 
                            id="privacy-mode" 
                            checked={isPrivate} 
                            onCheckedChange={handleTogglePrivacy}
                            disabled={updateGroupMutation.isPending}
                        />
                    </div>
                </div>
                <div>
                   <h4 className="font-semibold mb-2">Manage Members ({group.members?.length || 0})</h4>
                   <div className="space-y-2">
                       {memberDetails.map(member => (
                           <div key={member.email} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                               <span className="text-sm font-medium">{member.full_name}</span>
                               {member.email !== currentUser?.email ? (
                                    <Button variant="ghost" size="sm" onClick={() => {
                                        if(confirm(`Remove ${member.full_name}?`)) kickMember(member.email);
                                    }}>
                                        <LogOut className="w-4 h-4 text-red-500"/>
                                    </Button>
                               ) : (
                                   <span className="text-xs text-gray-500 bg-orange-100 px-2 py-1 rounded">Admin</span>
                               )}
                           </div>
                       ))}
                   </div>
                </div>
                <div className="pt-4 border-t">
                   <h4 className="font-semibold text-red-600 mb-2">Danger Zone</h4>
                    <AlertDialog>
                        <AlertDialogTrigger asChild>
                            <Button variant="destructive" className="w-full" disabled={deleteGroupMutation.isPending}>
                                <Trash2 className="w-4 h-4 mr-2"/> {deleteGroupMutation.isPending ? 'Deleting...' : 'Delete Group'}
                            </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                            <AlertDialogHeader>
                                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                    This action cannot be undone. This will permanently delete your group.
                                </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => deleteGroupMutation.mutate(group.id)}>Delete</AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                    </AlertDialog>
                </div>
            </div>
        </DialogContent>
    );
};

const MembersOverview = React.memo(({ members }) => {
    const { data: memberDetails, isLoading } = useQuery({
        queryKey: ['groupMemberDetails', members],
        queryFn: () => base44.entities.User.filter({ email: { $in: members } }),
        enabled: !!members && members.length > 0,
        staleTime: 60000,
    });

    if (isLoading) return <Loader2 className="w-6 h-6 animate-spin my-4 mx-auto"/>;
    if (!memberDetails || memberDetails.length === 0) return <p className="text-gray-500 text-center py-4">No members found.</p>;

    const statusConfig = {
        studying: { text: "Studying", color: "bg-green-500" },
        online: { text: "Online", color: "bg-blue-500" },
        offline: { text: "Offline", color: "bg-gray-400" },
    };

    return (
        <div className="space-y-3 mt-4">
            {memberDetails.map(member => (
                <div key={member.id} className="flex justify-between items-center p-3 bg-orange-50/50 rounded-lg">
                    <p className="font-semibold">{member.full_name}</p>
                    <div className="flex items-center gap-2 text-sm">
                        <div className={`w-2.5 h-2.5 rounded-full ${statusConfig[member.study_status]?.color || 'bg-gray-400'}`} />
                        <span>{statusConfig[member.study_status]?.text || 'Unknown'}</span>
                    </div>
                </div>
            ))}
        </div>
    );
});

MembersOverview.displayName = 'MembersOverview';


const GroupDetails = ({ group, onBack }) => {
    const queryClient = useQueryClient();
    const [leaderboardData, setLeaderboardData] = useState([]);
    const [timeRange, setTimeRange] = useState('day');
    const [isLoading, setIsLoading] = useState(true);
    
    const {data: currentUser} = useQuery({ 
        queryKey: ['currentUser'], 
        queryFn: () => base44.auth.me(),
        staleTime: Infinity,
    });
    
    const isAdmin = group?.created_by === currentUser?.email;
    
    const { data: memberDetails = [] } = useQuery({
        queryKey: ['groupMemberDetailsForLeaderboard', group?.members],
        queryFn: () => base44.entities.User.filter({ email: { $in: group.members || [] } }),
        enabled: !!group?.members && group.members.length > 0,
        staleTime: 60000,
    });

    const startDate = useMemo(() => {
        const today = new Date();
        if (timeRange === 'day') return format(today, 'yyyy-MM-dd');
        if (timeRange === 'week') return format(startOfWeek(today), 'yyyy-MM-dd');
        return format(startOfMonth(today), 'yyyy-MM-dd');
    }, [timeRange]);

    useEffect(() => {
        let isMounted = true;
        
        const fetchLeaderboard = async () => {
            if (!group || !group.members || group.members.length === 0) {
                 if (isMounted) {
                     setLeaderboardData([]);
                     setIsLoading(false);
                 }
                 return;
            }

            setIsLoading(true);

            try {
                const sessions = await base44.entities.StudySession.filter({
                    session_date: { $gte: startDate },
                    created_by: { $in: group.members }
                });
                
                const memberTotals = group.members.map(memberEmail => {
                    const memberSessions = sessions.filter(s => s.created_by === memberEmail);
                    const totalMinutes = memberSessions.reduce((sum, s) => sum + (s.duration_minutes || 0), 0);
                    const memberInfo = memberDetails.find(m => m.email === memberEmail);
                    return { 
                        email: memberEmail, 
                        name: memberInfo?.full_name || 'Unknown',
                        minutes: totalMinutes 
                    };
                });

                if (isMounted) {
                    setLeaderboardData(memberTotals.sort((a, b) => b.minutes - a.minutes));
                    setIsLoading(false);
                }
            } catch (error) {
                console.error('Error fetching leaderboard:', error);
                if (isMounted) {
                    setLeaderboardData([]);
                    setIsLoading(false);
                }
            }
        };

        fetchLeaderboard();
        const interval = setInterval(fetchLeaderboard, 30000);
        
        return () => {
            isMounted = false;
            clearInterval(interval);
        };

    }, [group, startDate, memberDetails]);

    if (!group) {
        return (
            <Card className="bg-white border rounded-xl shadow-sm p-8 text-center">
                <Loader2 className="w-8 h-8 animate-spin mx-auto text-orange-500" />
                <p className="mt-4 text-gray-500">Loading group details...</p>
            </Card>
        );
    }

    return (
        <Card className="bg-white border rounded-xl shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between">
                <div>
                    <Button onClick={onBack} variant="ghost" className="mb-2 -ml-4">← Back to groups</Button>
                    <CardTitle>{group.name}</CardTitle>
                    <CardDescription>{group.description}</CardDescription>
                </div>
                {isAdmin && (
                     <Dialog>
                        <DialogTrigger asChild>
                            <Button variant="outline" size="icon">
                                <Settings className="w-4 h-4"/>
                            </Button>
                        </DialogTrigger>
                        <GroupSettings group={group} onBack={onBack} />
                    </Dialog>
                )}
            </CardHeader>
            <CardContent>
                <Tabs defaultValue="leaderboard">
                    <TabsList className="grid w-full grid-cols-4">
                        <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
                        <TabsTrigger value="chat"><MessageSquare className="w-4 h-4 mr-2"/>Chat</TabsTrigger>
                        <TabsTrigger value="resources"><Layers className="w-4 h-4 mr-2"/>Resources</TabsTrigger>
                        <TabsTrigger value="overview">Members</TabsTrigger>
                    </TabsList>
                    <TabsContent value="leaderboard" className="mt-4">
                        <Tabs defaultValue="day" onValueChange={setTimeRange}>
                            <TabsList className="grid w-full grid-cols-3">
                                <TabsTrigger value="day">Day</TabsTrigger>
                                <TabsTrigger value="week">Week</TabsTrigger>
                                <TabsTrigger value="month">Month</TabsTrigger>
                            </TabsList>
                            <TabsContent value={timeRange}>
                                {isLoading && <Loader2 className="w-6 h-6 animate-spin my-4 mx-auto"/>}
                                <div className="space-y-2 mt-4">
                                    {!isLoading && leaderboardData.map((member, index) => (
                                        <div key={member.email} className="flex justify-between items-center p-3 bg-orange-50/50 rounded-lg">
                                            <p><span className="font-bold mr-2">{index + 1}.</span>{member.name}</p>
                                            <p className="font-semibold">{Math.floor(member.minutes / 60)}h {member.minutes % 60}m</p>
                                        </div>
                                    ))}
                                    {!isLoading && (!leaderboardData || leaderboardData.length === 0) && (
                                        <p className="text-gray-500 text-center py-4">No study sessions recorded for this period yet.</p>
                                    )}
                                </div>
                            </TabsContent>
                        </Tabs>
                    </TabsContent>
                    <TabsContent value="chat">
                        <GroupChat groupId={group.id} />
                    </TabsContent>
                     <TabsContent value="resources">
                        <SharedResources groupId={group.id} />
                    </TabsContent>
                    <TabsContent value="overview">
                        <MembersOverview members={group.members} />
                    </TabsContent>
                </Tabs>
            </CardContent>
        </Card>
    );
}

const CreateGroupForm = ({ onCreated }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const queryClient = useQueryClient();

    const createMutation = useMutation({
        mutationFn: async (data) => {
            const user = await base44.auth.me();
            return base44.entities.StudyGroup.create({ ...data, created_by: user.email, members: [user.email] });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['myGroups'] });
            onCreated();
            toast.success('Group created successfully!');
        },
        onError: (error) => {
            console.error('Failed to create group:', error);
            toast.error('Failed to create group: ' + error.message);
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!name) {
            toast.error('Group name is required.');
            return;
        }
        createMutation.mutate({ name, description });
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 p-4">
            <Input placeholder="Group Name" value={name} onChange={e => setName(e.target.value)} required disabled={createMutation.isPending}/>
            <Input placeholder="Group Description" value={description} onChange={e => setDescription(e.target.value)} disabled={createMutation.isPending} />
            <Button type="submit" disabled={createMutation.isPending}>{createMutation.isPending ? 'Creating...' : 'Create Group'}</Button>
        </form>
    )
}

export default function Groups() {
    const [view, setView] = useState('list');
    const [selectedGroup, setSelectedGroup] = useState(null);
    const [showCreateForm, setShowCreateForm] = useState(false);
    const queryClient = useQueryClient();

    const { data: currentUser } = useQuery({ queryKey: ['currentUser'], queryFn: () => base44.auth.me() });

    const joinMutation = useMutation({
        mutationFn: async (groupToJoin) => {
            const fullGroup = await base44.entities.StudyGroup.get(groupToJoin.id);
            const user = await base44.auth.me();
            const newMembers = [...(fullGroup.members || []), user.email];
            const updatedGroup = await base44.entities.StudyGroup.update(groupToJoin.id, { members: Array.from(new Set(newMembers)) });
            return updatedGroup;
        },
        onSuccess: (joinedGroup) => {
            queryClient.invalidateQueries({ queryKey: ['myGroups'] });
            queryClient.invalidateQueries({ queryKey: ['publicGroups'] });
            queryClient.invalidateQueries({ queryKey: ['groupMemberDetails', joinedGroup.members] }); // Invalidate for MembersOverview
            queryClient.invalidateQueries({ queryKey: ['groupMemberDetailsForLeaderboard', joinedGroup.members] }); // Invalidate for Leaderboard
            handleSelectGroup(joinedGroup);
            toast.success(`Joined group "${joinedGroup.name}"!`);
        },
        onError: (error) => {
            console.error('Failed to join group:', error);
            toast.error('Failed to join group: ' + error.message);
        }
    });

    const { data: myGroups, isLoading: isLoadingMyGroups } = useQuery({
        queryKey: ['myGroups'],
        queryFn: async () => {
            if (!currentUser?.email) return [];
            return base44.entities.StudyGroup.filter({ members: { $in: [currentUser.email] } });
        },
        enabled: !!currentUser
    });

    useEffect(() => {
        const joinGroupFromUrl = async () => {
            const urlParams = new URLSearchParams(window.location.search);
            const joinGroupId = urlParams.get('join_group_id');
            if (joinGroupId && currentUser && !joinMutation.isPending) {
                const existingGroup = myGroups?.find(g => g.id === joinGroupId);
                if (existingGroup) {
                    handleSelectGroup(existingGroup);
                    toast.info(`Already a member of "${existingGroup.name}"`);
                } else {
                    try {
                        const groupToJoin = await base44.entities.StudyGroup.get(joinGroupId);
                        if (groupToJoin.is_private && !groupToJoin.members.includes(currentUser.email)) {
                            toast.error('This is a private group. You need to be explicitly invited.');
                        } else {
                            await joinMutation.mutateAsync({ id: joinGroupId });
                        }
                    } catch (error) {
                        console.error('Error joining group from URL:', error);
                        toast.error('Could not find or join group from link.');
                    }
                }
                window.history.replaceState({}, document.title, window.location.pathname);
            }
        };
        if (currentUser && Array.isArray(myGroups)) {
            joinGroupFromUrl();
        }
    }, [currentUser, myGroups, joinMutation]);
    
    const { data: publicGroups, isLoading: isLoadingPublicGroups } = useQuery({
        queryKey: ['publicGroups'],
        queryFn: async () => {
            if (!currentUser?.email) return [];
            return base44.entities.StudyGroup.filter({ is_private: { $ne: true }, members: { $nin: [currentUser.email] } });
        },
        enabled: !!currentUser
    });
    
    const handleSelectGroup = (group) => {
        setSelectedGroup(group);
        setView('details');
    };
    
    const handleJoinGroup = (group) => {
        joinMutation.mutate(group);
    };

    if (view === 'details' && selectedGroup) {
        return <GroupDetails group={selectedGroup} onBack={() => setView('list')} />;
    }

    return (
        <Card className="bg-white border rounded-xl shadow-sm">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-orange-600"><Users className="w-5 h-5"/>Study Groups</CardTitle>
            </CardHeader>
            <CardContent>
                <Tabs defaultValue="my-groups">
                    <TabsList className="w-full grid grid-cols-2">
                        <TabsTrigger value="my-groups">My Groups</TabsTrigger>
                        <TabsTrigger value="public-groups">Public Groups</TabsTrigger>
                    </TabsList>
                    <TabsContent value="my-groups" className="mt-4">
                        <Button onClick={() => setShowCreateForm(!showCreateForm)} className="mb-4">
                           <Plus className="w-4 h-4 mr-2"/> {showCreateForm ? 'Hide Form' : 'New Group'}
                        </Button>
                        {showCreateForm && <CreateGroupForm onCreated={() => setShowCreateForm(false)}/>}
                        {isLoadingMyGroups ? <Loader2 className="w-6 h-6 animate-spin"/> : (
                           <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                                {myGroups?.map(g => <GroupCard key={g.id} group={g} onSelect={handleSelectGroup} isMember={true} />)}
                                {myGroups?.length === 0 && !showCreateForm && <p className="text-gray-500 p-4 col-span-full">You haven't joined any groups yet. Create one or check public groups!</p>}
                           </div>
                        )}
                    </TabsContent>
                    <TabsContent value="public-groups" className="mt-4">
                        {isLoadingPublicGroups || joinMutation.isPending ? <Loader2 className="w-6 h-6 animate-spin"/> : (
                           <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                                {publicGroups?.map(g => <GroupCard key={g.id} group={g} onSelect={handleJoinGroup} isMember={false} />)}
                           </div>
                        )}
                        {publicGroups?.length === 0 && !isLoadingPublicGroups && <p className="text-gray-500 p-4">No public groups to join right now.</p>}
                    </TabsContent>
                </Tabs>
            </CardContent>
        </Card>
    );
}
