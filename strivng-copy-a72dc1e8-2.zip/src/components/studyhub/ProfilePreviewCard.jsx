import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { User, MapPin, GraduationCap, Clock } from 'lucide-react';
import { format } from 'date-fns';

export default function ProfilePreviewCard({ member }) {
    const { data: currentUser } = useQuery({ 
        queryKey: ['currentUser'], 
        queryFn: () => base44.auth.me() 
    });
    
    const isOwnProfile = currentUser?.email === member.email;
    const displayName = member.full_name || 'Student';

    const { data: sessions = [] } = useQuery({
        queryKey: ['memberSessions', member.email],
        queryFn: () => base44.entities.StudySession.filter({ created_by: member.email }),
        enabled: !!member.email
    });

    const totalStudyMinutes = sessions.reduce((sum, s) => sum + s.duration_minutes, 0);
    const totalStudyHours = Math.floor(totalStudyMinutes / 60);

    return (
        <Card className="bg-gradient-to-br from-orange-50 to-amber-50">
            <CardContent className="p-6 space-y-6">
                <div className="flex items-start gap-4">
                    <Avatar className="w-24 h-24">
                        <AvatarImage src={member.avatar_url} />
                        <AvatarFallback><User className="w-12 h-12" /></AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                        <h2 className="text-2xl font-bold text-gray-800">{displayName}</h2>
                        {isOwnProfile && (
                            <p className="text-sm text-gray-500 mt-1">{member.email}</p>
                        )}
                        {member.bio && <p className="text-gray-600 mt-2">{member.bio}</p>}
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    {member.education_level && (
                        <div className="flex items-center gap-2 text-gray-700">
                            <GraduationCap className="w-5 h-5 text-orange-500" />
                            <div>
                                <p className="text-xs text-gray-500">Education Level</p>
                                <p className="font-medium">{member.education_level}</p>
                            </div>
                        </div>
                    )}
                    {member.location && (
                        <div className="flex items-center gap-2 text-gray-700">
                            <MapPin className="w-5 h-5 text-orange-500" />
                            <div>
                                <p className="text-xs text-gray-500">Location</p>
                                <p className="font-medium">{member.location}</p>
                            </div>
                        </div>
                    )}
                    <div className="flex items-center gap-2 text-gray-700">
                        <Clock className="w-5 h-5 text-orange-500" />
                        <div>
                            <p className="text-xs text-gray-500">Total Study Time</p>
                            <p className="font-medium">{totalStudyHours}h</p>
                        </div>
                    </div>
                    {member.current_session_start && member.study_status === 'studying' && (
                        <div className="flex items-center gap-2 text-gray-700">
                            <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
                            <div>
                                <p className="text-xs text-gray-500">Currently Studying</p>
                                <p className="font-medium">{member.current_goal_title || 'Active Session'}</p>
                            </div>
                        </div>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}