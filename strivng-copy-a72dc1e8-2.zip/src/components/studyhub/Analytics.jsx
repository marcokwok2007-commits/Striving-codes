import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock, Loader2 } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

const COLORS = ['#ef4444', '#f97316', '#84cc16', '#3b82f6', '#8b5cf6', '#ec4899'];

const CustomLegend = React.memo(({ payload, totalMinutes }) => {
    return (
      <ul className="flex flex-col gap-3">
        {payload.map((entry, index) => {
          const percentage = totalMinutes > 0 ? Math.round((entry.payload.value / totalMinutes) * 100) : 0;
          const hours = Math.floor(entry.payload.value / 60);
          const minutes = entry.payload.value % 60;
          const timeString = hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;

          return (
            <li key={`item-${index}`} className="flex justify-between items-center text-sm">
                <div className="flex items-center">
                    <div className="w-2.5 h-2.5 rounded-full mr-2" style={{ backgroundColor: entry.color }} />
                    <span className="text-gray-700">{entry.value}</span>
                </div>
                <span className="font-medium text-gray-600">{timeString} ({percentage}%)</span>
            </li>
          );
        })}
      </ul>
    );
});

CustomLegend.displayName = 'CustomLegend';

export default function Analytics() {
    const { data: sessions = [], isLoading } = useQuery({
        queryKey: ['studySessions'],
        queryFn: async () => {
            const user = await base44.auth.me();
            return base44.entities.StudySession.filter({ created_by: user.email });
        },
        staleTime: 60000,
        refetchOnWindowFocus: false,
    });

    const { bySubject, totalMinutes, legendData } = useMemo(() => {
        if (!sessions || sessions.length === 0) {
            return { bySubject: [], totalMinutes: 0, legendData: [] };
        }

        const subjectTotals = sessions.reduce((acc, session) => {
            const subject = session.subject || "General";
            acc[subject] = (acc[subject] || 0) + (session.duration_minutes || 0);
            return acc;
        }, {});
        
        const bySubject = Object.entries(subjectTotals).map(([name, value]) => ({ name, value }));
        const totalMinutes = bySubject.reduce((sum, item) => sum + item.value, 0);
        
        const legendData = bySubject.map((item, index) => ({
            value: item.name,
            type: 'circle',
            id: item.name,
            color: COLORS[index % COLORS.length],
            payload: { value: item.value }
        }));

        return { bySubject, totalMinutes, legendData };
    }, [sessions]);

    if (isLoading) {
        return (
            <Card className="bg-white border rounded-xl shadow-sm">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-orange-600">
                        <Clock className="w-5 h-5" />
                        Study Time by Subject
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="text-center py-10">
                        <Loader2 className="h-8 w-8 animate-spin mx-auto text-orange-500"/>
                    </div>
                </CardContent>
            </Card>
        );
    }

    return (
        <Card className="bg-white border rounded-xl shadow-sm">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-orange-600">
                    <Clock className="w-5 h-5" />
                    Study Time by Subject
                </CardTitle>
            </CardHeader>
            <CardContent>
                {sessions.length === 0 ? (
                     <div className="text-center py-10">
                        <h3 className="text-lg font-semibold text-gray-700">No Data Yet</h3>
                        <p className="text-sm text-gray-500 mt-1">Complete a study session to see your analytics.</p>
                    </div>
                ) : (
                    <div className="grid md:grid-cols-2 gap-8 items-center">
                         <div className="w-full h-64">
                            <ResponsiveContainer>
                                <PieChart>
                                    <Pie
                                        data={bySubject}
                                        cx="50%"
                                        cy="50%"
                                        labelLine={false}
                                        innerRadius={60}
                                        outerRadius={80}
                                        fill="#8884d8"
                                        paddingAngle={5}
                                        dataKey="value"
                                    >
                                        {bySubject.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                        ))}
                                    </Pie>
                                </PieChart>
                            </ResponsiveContainer>
                        </div>
                        <div>
                             <CustomLegend totalMinutes={totalMinutes} payload={legendData}/>
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}