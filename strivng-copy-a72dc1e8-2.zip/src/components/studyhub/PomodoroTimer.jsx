import React, { useState, useCallback, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Timer, Play, Target, Users } from "lucide-react";

const priorityColors = {
    high: "bg-red-500",
    medium: "bg-yellow-500",
    low: "bg-green-500",
};

const formatDuration = (minutes) => {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    if (h > 0 && m > 0) return `${h}h ${m}m`;
    if (h > 0) return `${h}h`;
    return `${m}m`;
};

export default function StudyTimer({ onStartSession, dailyHours }) {
    const [selectedGoalId, setSelectedGoalId] = useState(null);
    const [selectedGroupId, setSelectedGroupId] = useState(null);

    const { data: user } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me(),
        staleTime: Infinity,
    });

    const { data: goals = [], isLoading: isLoadingGoals } = useQuery({
        queryKey: ['goals'],
        queryFn: async () => {
            const user = await base44.auth.me();
            return base44.entities.Goal.filter({ created_by: user.email, status: { $ne: 'completed' } });
        },
        staleTime: 60000,
    });

    const { data: myGroups = [], isLoading: isLoadingGroups } = useQuery({
        queryKey: ['myGroups'],
        queryFn: async () => {
            if (!user?.email) return [];
            return base44.entities.StudyGroup.filter({ members: { $in: [user.email] } });
        },
        enabled: !!user,
        staleTime: 300000,
    });

    const handleStart = useCallback(() => {
        if (!selectedGoalId) {
            alert("Please select a goal before starting.");
            return;
        }
        const goal = goals.find(g => g.id === selectedGoalId);
        const group = selectedGroupId ? myGroups.find(g => g.id === selectedGroupId) : null;
        if (goal) {
            onStartSession(goal, group);
        }
    }, [selectedGoalId, selectedGroupId, goals, myGroups, onStartSession]);

    const formattedDailyHours = useMemo(() => formatDuration(dailyHours || 0), [dailyHours]);

    const canStart = selectedGoalId && !isLoadingGoals;

    return (
        <Card className="bg-white border rounded-xl shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-orange-600">
                    <Timer className="w-5 h-5" />
                    Start a Study Session
                </CardTitle>
                <div className="bg-orange-100 text-orange-700 font-semibold px-4 py-2 rounded-lg text-sm">
                    Today: {formattedDailyHours}
                </div>
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center py-10 space-y-8">
                <div className="text-7xl font-bold font-mono text-gray-800 tracking-wider">
                    00:00:00
                </div>
                
                <div className="flex flex-col md:flex-row items-center gap-4 w-full max-w-2xl">
                    <div className="flex items-center gap-2 flex-1 w-full">
                        <Target className="w-5 h-5 text-gray-500" />
                        <Select onValueChange={setSelectedGoalId} value={selectedGoalId || ""}>
                            <SelectTrigger className="flex-1">
                                <SelectValue placeholder="Select a goal to focus on..." />
                            </SelectTrigger>
                            <SelectContent>
                                {isLoadingGoals ? (
                                    <SelectItem value="loading" disabled>Loading goals...</SelectItem>
                                ) : goals.length > 0 ? (
                                    goals.map(goal => (
                                        <SelectItem key={goal.id} value={goal.id}>
                                            <div className="flex items-center gap-2">
                                                <div className={`w-2 h-2 rounded-full ${priorityColors[goal.priority] || 'bg-gray-400'}`} />
                                                <span>{goal.title}</span>
                                            </div>
                                        </SelectItem>
                                    ))
                                ) : (
                                    <SelectItem value="no-goals" disabled>No goals found. Create one first.</SelectItem>
                                )}
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="flex items-center gap-2 flex-1 w-full">
                        <Users className="w-5 h-5 text-gray-500" />
                        <Select onValueChange={setSelectedGroupId} value={selectedGroupId || ""}>
                            <SelectTrigger className="flex-1">
                                <SelectValue placeholder="Study group (optional)..." />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="none">No group</SelectItem>
                                {isLoadingGroups ? (
                                    <SelectItem value="loading" disabled>Loading groups...</SelectItem>
                                ) : myGroups.length > 0 ? (
                                    myGroups.map(group => (
                                        <SelectItem key={group.id} value={group.id}>
                                            {group.name}
                                        </SelectItem>
                                    ))
                                ) : (
                                    <SelectItem value="no-groups" disabled>No groups available</SelectItem>
                                )}
                            </SelectContent>
                        </Select>
                    </div>

                    <Button onClick={handleStart} disabled={!canStart} className="bg-green-500 hover:bg-green-600 md:w-auto w-full">
                        <Play className="mr-2 h-4 w-4" />
                        Start
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}