import { base44 } from './base44Client';


export const Goal = base44.entities.Goal;

export const StudySession = base44.entities.StudySession;

export const StudyGroup = base44.entities.StudyGroup;

export const Deck = base44.entities.Deck;

export const Enrollment = base44.entities.Enrollment;

export const Course = base44.entities.Course;

export const Lesson = base44.entities.Lesson;

export const Rating = base44.entities.Rating;

export const GroupMessage = base44.entities.GroupMessage;

export const SharedResource = base44.entities.SharedResource;

export const DeckProgress = base44.entities.DeckProgress;

export const SharedDeck = base44.entities.SharedDeck;

export const DeckContribution = base44.entities.DeckContribution;

export const GroupGoal = base44.entities.GroupGoal;

export const Payment = base44.entities.Payment;

export const Subscription = base44.entities.Subscription;



// auth sdk:
export const User = base44.auth;