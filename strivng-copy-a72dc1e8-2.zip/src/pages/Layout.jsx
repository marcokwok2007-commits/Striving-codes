
import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  BookOpen,
  Calendar,
  Layers,
  Briefcase,
  Video,
  PlusCircle,
  User,
  Settings,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(() => {
    const saved = localStorage.getItem('sidebarCollapsed');
    return saved ? JSON.parse(saved) : false;
  });
  
  const { data: user, isLoading } = useQuery({
    queryKey: ['currentUser'],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
    retry: false,
    staleTime: Infinity,
    refetchOnWindowFocus: false,
  });

  // All hooks must be called before any conditional returns
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    localStorage.setItem('sidebarCollapsed', JSON.stringify(isSidebarCollapsed));
  }, [isSidebarCollapsed]);

  const navigationItems = [
    { title: "Study Hub", url: createPageUrl("StudyHub"), icon: BookOpen },
    { title: "Calendar", url: createPageUrl("Calendar"), icon: Calendar },
    { title: "Deck", url: createPageUrl("Deck"), icon: Layers },
    { title: "EduTube", url: createPageUrl("EduTube"), icon: Video },
    { title: "Career Center", url: createPageUrl("CareerCenter"), icon: Briefcase },
    ...(user?.creator_mode ? [
      { title: "Creator Dashboard", url: createPageUrl("Create"), icon: PlusCircle }
    ] : []),
    { title: "Profile", url: createPageUrl("Profile"), icon: User },
    { title: "Settings", url: createPageUrl("Settings"), icon: Settings },
  ];

  // Check if we're on the Home page (case-insensitive and also check root path)
  const isHomePage = currentPageName?.toLowerCase() === 'home' || location.pathname === '/' || location.pathname === '/Home';
  const shouldShowLayout = !isHomePage || (!isLoading && user);

  if (!shouldShowLayout) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen flex flex-col lg:flex-row w-full bg-gray-50 text-gray-800">
      {/* Mobile Header */}
      <header className="lg:hidden sticky top-0 z-40 bg-white border-b shadow-sm px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center overflow-hidden">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ead5d076c2b7a3765c1ee0/ab4d088ff_PHOTO-2025-10-08-15-31-34.jpg" 
                alt="Striving Logo" 
                className="w-full h-full object-cover"
              />
            </div>
            <h2 className="font-bold text-lg text-orange-600">Striving</h2>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </Button>
        </div>
      </header>

      {/* Mobile Navigation Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="lg:hidden fixed inset-0 z-30 bg-black/50"
          onClick={() => setIsMobileMenuOpen(false)}
        >
          <nav 
            className="absolute right-0 top-[57px] bottom-0 w-64 bg-white shadow-xl overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <ul className="p-3 space-y-1">
              {navigationItems.map((item) => (
                <li key={item.title}>
                  <Link 
                    to={item.url}
                    className={cn(
                      "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors",
                      location.pathname === item.url
                        ? "bg-orange-500 text-white"
                        : "text-gray-700 hover:bg-gray-100"
                    )}
                  >
                    <item.icon className="w-5 h-5 shrink-0" />
                    <span className="font-medium">{item.title}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      )}

      {/* Desktop Sidebar */}
      <aside className={cn(
        "hidden lg:flex flex-col bg-white border-r shadow-sm transition-all duration-300",
        isSidebarCollapsed ? "w-16" : "w-64"
      )}>
        <div className="p-4 border-b flex items-center justify-between">
          {!isSidebarCollapsed && (
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0 overflow-hidden">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ead5d076c2b7a3765c1ee0/ab4d088ff_PHOTO-2025-10-08-15-31-34.jpg" 
                  alt="Striving Logo" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <h2 className="font-bold text-xl text-orange-600">Striving</h2>
              </div>
            </div>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
            className="h-8 w-8"
          >
            {isSidebarCollapsed ? (
              <ChevronRight className="h-4 w-4" />
            ) : (
              <ChevronLeft className="h-4 w-4" />
            )}
          </Button>
        </div>

        <nav className="flex-1 p-3 overflow-y-auto">
          <ul className="space-y-1">
            {navigationItems.map((item) => (
              <li key={item.title}>
                <Link 
                  to={item.url}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors",
                    location.pathname === item.url
                      ? "bg-orange-500 text-white"
                      : "text-gray-700 hover:bg-gray-100"
                  )}
                  title={isSidebarCollapsed ? item.title : undefined}
                >
                  <item.icon className="w-5 h-5 shrink-0" />
                  {!isSidebarCollapsed && <span className="font-medium">{item.title}</span>}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 overflow-auto">
          {children}
        </div>
      </main>
    </div>
  );
}
