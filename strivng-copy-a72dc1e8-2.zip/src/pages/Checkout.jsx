import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, CreditCard, Lock, CheckCircle2, AlertCircle } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";

export default function CheckoutPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(location.search);
  
  const courseId = urlParams.get('courseId');
  const plan = urlParams.get('plan');
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [paymentError, setPaymentError] = useState(null);
  
  // Mock card details for demonstration
  const [cardDetails, setCardDetails] = useState({
    cardNumber: '',
    expiry: '',
    cvc: '',
    name: ''
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: course } = useQuery({
    queryKey: ['course', courseId],
    queryFn: () => base44.entities.Course.get(courseId),
    enabled: !!courseId,
  });

  const planDetails = {
    pro: { name: 'Pro', price: 9.99, features: ['Unlimited AI decks', 'Advanced analytics', 'Priority support'] },
    premium: { name: 'Premium', price: 19.99, features: ['Everything in Pro', '1-on-1 tutoring', 'Custom templates'] }
  };

  const selectedPlan = plan ? planDetails[plan] : null;
  const amount = course ? course.price : (selectedPlan ? selectedPlan.price : 0);
  const itemName = course ? course.title : (selectedPlan ? `${selectedPlan.name} Plan` : 'Purchase');

  // 🔥 BACKEND FUNCTION NEEDED: createPaymentIntent
  const handlePayment = async () => {
    setIsProcessing(true);
    setPaymentError(null);

    try {
      // ⚠️ TODO: Replace this with actual backend function call
      // This should call a backend function that creates a Stripe Payment Intent
      // 
      // Example backend function structure:
      // POST /api/functions/createPaymentIntent
      // Body: { amount, currency, courseId, plan, userEmail }
      // Returns: { clientSecret, paymentIntentId }
      
      // MOCK: Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // MOCK: Create payment record
      await base44.entities.Payment.create({
        user_email: user.email,
        stripe_payment_intent_id: 'pi_mock_' + Date.now(),
        stripe_customer_id: user.stripe_customer_id || 'cus_mock_' + Date.now(),
        amount: amount,
        currency: 'usd',
        status: 'succeeded',
        payment_type: courseId ? 'course_purchase' : 'subscription',
        course_id: courseId,
        subscription_plan: plan,
        metadata: {
          item_name: itemName,
          card_last4: cardDetails.cardNumber.slice(-4)
        }
      });

      // Update user based on purchase type
      if (courseId) {
        // Course purchase - add to purchased courses and enroll
        const currentPurchases = user.purchased_courses || [];
        await base44.auth.updateMe({
          purchased_courses: [...currentPurchases, courseId]
        });
        
        await base44.entities.Enrollment.create({
          user_email: user.email,
          course_id: courseId
        });
      } else if (plan) {
        // Subscription purchase - update user plan
        await base44.auth.updateMe({
          subscription_plan: plan
        });
        
        // Create subscription record
        const today = new Date();
        const nextMonth = new Date(today.setMonth(today.getMonth() + 1));
        
        await base44.entities.Subscription.create({
          user_email: user.email,
          stripe_subscription_id: 'sub_mock_' + Date.now(),
          stripe_customer_id: user.stripe_customer_id || 'cus_mock_' + Date.now(),
          plan: plan,
          status: 'active',
          current_period_start: new Date().toISOString().split('T')[0],
          current_period_end: nextMonth.toISOString().split('T')[0],
          billing_interval: 'month'
        });
      }

      setPaymentSuccess(true);
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
      
      toast.success('Payment successful!');
      
      // Redirect after success
      setTimeout(() => {
        if (courseId) {
          navigate(createPageUrl(`CourseViewer?courseId=${courseId}`));
        } else {
          navigate(createPageUrl('Settings'));
        }
      }, 2000);

    } catch (error) {
      console.error('Payment error:', error);
      setPaymentError(error.message || 'Payment failed. Please try again.');
      toast.error('Payment failed');
    } finally {
      setIsProcessing(false);
    }
  };

  if (!user) {
    return (
      <div className="p-8 text-center">
        <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4" />
        <p>Loading...</p>
      </div>
    );
  }

  if (paymentSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-gray-50">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6 text-center">
            <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Payment Successful!</h2>
            <p className="text-gray-600 mb-4">
              {courseId ? 'You now have access to this course.' : 'Your subscription is now active.'}
            </p>
            <p className="text-sm text-gray-500">Redirecting...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gray-50">
      <div className="max-w-4xl w-full grid md:grid-cols-2 gap-6">
        {/* Order Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Order Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between py-3 border-b">
              <span className="font-medium">{itemName}</span>
              <span className="font-semibold">${amount.toFixed(2)}</span>
            </div>
            
            {selectedPlan && (
              <div className="space-y-2">
                <p className="text-sm font-semibold text-gray-700">Includes:</p>
                <ul className="text-sm text-gray-600 space-y-1">
                  {selectedPlan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            
            <div className="flex justify-between py-3 border-t font-bold text-lg">
              <span>Total</span>
              <span>${amount.toFixed(2)}</span>
            </div>
            
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-800">
              <Lock className="w-4 h-4 inline mr-2" />
              Payments are securely processed by Stripe
            </div>
          </CardContent>
        </Card>

        {/* Payment Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="w-5 h-5" />
              Payment Details
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-sm text-yellow-800 mb-4">
                <AlertCircle className="w-4 h-4 inline mr-2" />
                <strong>Demo Mode:</strong> This is a demonstration. Real Stripe integration requires backend functions.
              </div>

              <div>
                <Label htmlFor="name">Cardholder Name</Label>
                <Input
                  id="name"
                  placeholder="John Doe"
                  value={cardDetails.name}
                  onChange={(e) => setCardDetails({ ...cardDetails, name: e.target.value })}
                />
              </div>

              <div>
                <Label htmlFor="cardNumber">Card Number</Label>
                <Input
                  id="cardNumber"
                  placeholder="4242 4242 4242 4242"
                  value={cardDetails.cardNumber}
                  onChange={(e) => setCardDetails({ ...cardDetails, cardNumber: e.target.value })}
                  maxLength={19}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="expiry">Expiry Date</Label>
                  <Input
                    id="expiry"
                    placeholder="MM/YY"
                    value={cardDetails.expiry}
                    onChange={(e) => setCardDetails({ ...cardDetails, expiry: e.target.value })}
                    maxLength={5}
                  />
                </div>
                <div>
                  <Label htmlFor="cvc">CVC</Label>
                  <Input
                    id="cvc"
                    placeholder="123"
                    value={cardDetails.cvc}
                    onChange={(e) => setCardDetails({ ...cardDetails, cvc: e.target.value })}
                    maxLength={4}
                  />
                </div>
              </div>

              {paymentError && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-800">
                  <AlertCircle className="w-4 h-4 inline mr-2" />
                  {paymentError}
                </div>
              )}

              <Button
                onClick={handlePayment}
                disabled={isProcessing || !cardDetails.name || !cardDetails.cardNumber}
                className="w-full"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing Payment...
                  </>
                ) : (
                  <>
                    <Lock className="mr-2 h-4 w-4" />
                    Pay ${amount.toFixed(2)}
                  </>
                )}
              </Button>

              <p className="text-xs text-gray-500 text-center">
                By confirming your purchase, you agree to our Terms of Service
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}