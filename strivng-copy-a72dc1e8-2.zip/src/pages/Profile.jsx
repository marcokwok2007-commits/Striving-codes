import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User, Edit, Loader2, UploadCloud, Clock, BarChart2, Share2, Check } from "lucide-react";
import { format, startOfMonth, isThisMonth } from 'date-fns';
import StudyAgent from "../components/StudyAgent";
import { Combobox } from "@/components/ui/combobox";

const educationLevels = [
    { value: "High School", label: "High School" },
    { value: "Grade 12", label: "Grade 12" },
    { value: "Grade 11", label: "Grade 11" },
    { value: "Grade 10", label: "Grade 10" },
    { value: "Undergraduate", label: "Undergraduate" },
    { value: "Postgraduate", label: "Postgraduate" },
    { value: "Doctorate", label: "Doctorate" },
    { value: "Other", label: "Other" },
];

const locations = [
    { value: "HKDSE (Hong Kong)", label: "HKDSE (Hong Kong)" },
    { value: "IB (International Baccalaureate)", label: "IB (International Baccalaureate)" },
    { value: "GCE A-Level (UK)", label: "GCE A-Level (UK)" },
    { value: "SAT/AP (US)", label: "SAT/AP (US)" },
    { value: "Gaokao (China)", label: "Gaokao (China)" },
    { value: "Other", label: "Other" },
];

const ProfileForm = ({ user, onSave }) => {
    const [formData, setFormData] = useState({
        full_name: user?.full_name || '',
        bio: user?.bio || '',
        education_level: user?.education_level || '',
        location: user?.location || '',
    });
    const [avatarFile, setAvatarFile] = useState(null);
    const [isUploading, setIsUploading] = useState(false);
    const queryClient = useQueryClient();

    const mutation = useMutation({
        mutationFn: (data) => base44.auth.updateMe(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['currentUser'] });
            onSave();
        },
    });

    const handleFileChange = (e) => {
        if (e.target.files[0]) {
            setAvatarFile(e.target.files[0]);
        }
    };
    
    const handleSubmit = async (e) => {
        e.preventDefault();
        let dataToUpdate = { ...formData };
        if (avatarFile) {
            setIsUploading(true);
            try {
                const { file_url } = await base44.integrations.Core.UploadFile({ file: avatarFile });
                dataToUpdate.avatar_url = file_url;
            } catch (error) {
                console.error("Avatar upload failed:", error);
                alert("Avatar upload failed. Please try again.");
                setIsUploading(false);
                return;
            }
            setIsUploading(false);
        }
        mutation.mutate(dataToUpdate);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex flex-col items-center space-y-4">
                <Avatar className="w-24 h-24">
                    <AvatarImage src={avatarFile ? URL.createObjectURL(avatarFile) : user?.avatar_url} />
                    <AvatarFallback><User className="w-12 h-12" /></AvatarFallback>
                </Avatar>
                <Button type="button" variant="outline" onClick={() => document.getElementById('avatar-upload').click()}>
                    <UploadCloud className="w-4 h-4 mr-2" /> Change Avatar
                </Button>
                <input type="file" id="avatar-upload" className="hidden" accept="image/*" onChange={handleFileChange} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <Label htmlFor="full_name">Username</Label>
                    <Input id="full_name" value={formData.full_name} onChange={e => setFormData({ ...formData, full_name: e.target.value })} />
                </div>
                <div>
                    <Label htmlFor="location">Location / Education System</Label>
                    <Combobox
                        options={locations}
                        value={formData.location}
                        onChange={(value) => setFormData({ ...formData, location: value })}
                        placeholder="Select a system..."
                    />
                </div>
            </div>
             <div>
                <Label htmlFor="education_level">Education Level</Label>
                 <Combobox
                    options={educationLevels}
                    value={formData.education_level}
                    onChange={(value) => setFormData({ ...formData, education_level: value })}
                    placeholder="Select a level..."
                />
            </div>
            <div>
                <Label htmlFor="bio">Bio</Label>
                <Textarea id="bio" value={formData.bio} onChange={e => setFormData({ ...formData, bio: e.target.value })} />
            </div>
            <div className="flex justify-end">
                <Button type="submit" disabled={mutation.isPending || isUploading}>
                    {(mutation.isPending || isUploading) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Save Changes
                </Button>
            </div>
        </form>
    );
};

export default function ProfilePage() {
    const [isEditing, setIsEditing] = useState(false);
    const [linkCopied, setLinkCopied] = useState(false);
    
    const { data: user, isLoading: isLoadingUser } = useQuery({ queryKey: ['currentUser'], queryFn: () => base44.auth.me() });
    
    const { data: sessions, isLoading: isLoadingSessions } = useQuery({
        queryKey: ['studySessions'],
        queryFn: () => base44.entities.StudySession.filter({ created_by: user.email }),
        enabled: !!user,
    });
    
    const studyStats = React.useMemo(() => {
        if (!sessions) return { totalHours: 0, monthlyAverageHours: 0 };
        
        const totalMinutes = sessions.reduce((sum, s) => sum + s.duration_minutes, 0);
        const totalHours = (totalMinutes / 60).toFixed(1);

        const monthlySessions = sessions.filter(s => isThisMonth(new Date(s.session_date)));
        const monthlyMinutes = monthlySessions.reduce((sum, s) => sum + s.duration_minutes, 0);
        const monthlyAverageHours = (monthlyMinutes / 60).toFixed(1);

        return { totalHours, monthlyAverageHours };
    }, [sessions]);

    const shareableUrl = user ? `${window.location.origin}/profile/${user.id}` : '';

    const handleShareProfile = () => {
        if (shareableUrl) {
            navigator.clipboard.writeText(shareableUrl);
            setLinkCopied(true);
            setTimeout(() => setLinkCopied(false), 2000);
        } else {
            alert("Unable to generate shareable link. Please try again later.");
        }
    };

    if (isLoadingUser || isLoadingSessions) {
        return <div className="p-8 text-center"><Loader2 className="w-8 h-8 animate-spin mx-auto" /></div>;
    }

    return (
        <div className="p-6 md:p-8 bg-gray-50 min-h-screen">
            <div className="max-w-5xl mx-auto">
                {isEditing ? (
                    <Card>
                        <CardHeader><CardTitle>Edit Your Profile</CardTitle></CardHeader>
                        <CardContent><ProfileForm user={user} onSave={() => setIsEditing(false)} /></CardContent>
                    </Card>
                ) : (
                    <Card className="overflow-hidden">
                        <CardContent className="pt-6 flex flex-col md:flex-row items-center gap-6">
                            <Avatar className="w-24 h-24">
                                <AvatarImage src={user?.avatar_url} />
                                <AvatarFallback><User className="w-12 h-12" /></AvatarFallback>
                            </Avatar>
                            <div className="text-center md:text-left">
                                <h2 className="text-2xl font-bold">{user?.full_name}</h2>
                                <p className="text-gray-500">{user?.email}</p>
                                {user?.location && <p className="text-sm text-gray-500 mt-1">{user.location}</p>}
                                {user?.education_level && <p className="text-sm text-gray-500">{user.education_level}</p>}
                                {user?.bio && <p className="mt-2 text-gray-600 max-w-lg">{user.bio}</p>}
                            </div>
                        </CardContent>
                        <div className="bg-orange-50/50 p-6 border-t">
                             <h3 className="text-lg font-semibold flex items-center gap-2 text-orange-700 mb-4"><BarChart2 className="w-5 h-5"/>Study Statistics</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="p-4 bg-white rounded-lg border">
                                    <p className="text-sm text-orange-700 font-semibold">Total Study Hours</p>
                                    <p className="text-3xl font-bold text-orange-900">{studyStats.totalHours}</p>
                                </div>
                                <div className="p-4 bg-white rounded-lg border">
                                    <p className="text-sm text-amber-700 font-semibold">This Month's Study Hours</p>
                                    <p className="text-3xl font-bold text-amber-900">{studyStats.monthlyAverageHours}</p>
                                </div>
                            </div>
                        </div>
                        <div className="p-6 border-t bg-white flex justify-end gap-3">
                            <Button variant="outline" onClick={handleShareProfile}>
                                {linkCopied ? (
                                    <>
                                        <Check className="w-4 h-4 mr-2" /> Link Copied!
                                    </>
                                ) : (
                                    <>
                                        <Share2 className="w-4 h-4 mr-2" /> Share Profile
                                    </>
                                )}
                            </Button>
                            <Button variant="outline" onClick={() => setIsEditing(!isEditing)}>
                                <Edit className="w-4 h-4 mr-2" /> Edit Profile
                            </Button>
                        </div>
                    </Card>
                )}
            </div>
            <StudyAgent />
        </div>
    );
}