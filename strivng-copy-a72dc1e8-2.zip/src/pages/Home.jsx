
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Navigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { 
  BookOpen, 
  Brain, 
  Users, 
  Target, 
  Video,
  Briefcase,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Timer,
  Instagram,
} from 'lucide-react';

const FeatureCard = ({ icon: Icon, title, description }) => (
  <Card className="bg-white/80 backdrop-blur-sm border-orange-200 hover:border-orange-400 transition-all hover:shadow-lg group">
    <CardContent className="p-6">
      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-400 to-amber-500 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
        <Icon className="w-6 h-6 text-white" />
      </div>
      <h3 className="text-xl font-semibold mb-2 text-gray-800">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </CardContent>
  </Card>
);

export default function HomePage() {
  const { data: isAuthenticated, isLoading } = useQuery({
    queryKey: ['isAuthenticated'],
    queryFn: async () => {
      try {
        const authenticated = await base44.auth.isAuthenticated();
        return authenticated;
      } catch (error) {
        console.log('Auth check error:', error);
        return false;
      }
    },
    retry: false,
    staleTime: 5000,
    gcTime: 0,
  });

  // If user is logged in, redirect to StudyHub
  if (!isLoading && isAuthenticated) {
    return <Navigate to={createPageUrl('StudyHub')} replace />;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-orange-50 via-amber-50 to-orange-100">
        <div className="text-center">
          <div className="w-16 h-16 rounded-full border-4 border-orange-500 border-t-transparent animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-orange-100">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 backdrop-blur-xl bg-white/70 border-b border-orange-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ead5d076c2b7a3765c1ee0/ab4d088ff_PHOTO-2025-10-08-15-31-34.jpg" 
                alt="Striving Logo" 
                className="w-10 h-10 rounded-xl"
              />
              <span className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                Striving
              </span>
            </div>
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => window.open('https://www.instagram.com/striving.ai', '_blank')}
                className="hidden md:inline-flex"
              >
                <Instagram className="w-5 h-5" />
              </Button>
              <Button 
                variant="ghost" 
                onClick={() => base44.auth.redirectToLogin(createPageUrl('StudyHub'))}
                className="hidden md:inline-flex"
              >
                Sign In
              </Button>
              <Button 
                onClick={() => base44.auth.redirectToLogin(createPageUrl('StudyHub'))}
                className="bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white"
              >
                Get Started Free
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-100/50 via-transparent to-amber-100/50" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="inline-flex items-center gap-2 bg-orange-100 border border-orange-300 text-orange-800 px-4 py-2 rounded-full text-sm font-medium">
                <Sparkles className="w-4 h-4" />
                AI-Powered Study Platform
              </div>
              
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-tight">
                <span className="text-gray-900">Study </span>
                <span className="bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                  Smarter
                </span>
                <br />
                <span className="text-gray-900">with AI</span>
              </h1>
              
              <p className="text-2xl font-semibold text-orange-600 italic">
                "Strive for excellence, and become extraordinary"
              </p>
              
              <p className="text-xl text-gray-600 max-w-lg">
                Transform any content into interactive flashcards, mind maps, and quizzes. 
                Track your progress, study with friends, and achieve your goals faster.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  onClick={() => base44.auth.redirectToLogin(createPageUrl('StudyHub'))}
                  className="bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white text-lg h-14 px-8"
                >
                  Start Learning Free
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline"
                  onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
                  className="border-2 border-orange-300 hover:bg-orange-50 text-lg h-14 px-8"
                >
                  See How It Works
                </Button>
              </div>
              
              <div className="flex items-center gap-4 pt-4">
                <Button 
                  variant="outline"
                  onClick={() => window.open('https://www.instagram.com/striving.ai', '_blank')}
                  className="flex items-center gap-2"
                >
                  <Instagram className="w-5 h-5" />
                  Follow us on Instagram
                </Button>
              </div>
            </div>
            
            <div className="relative">
              <div className="relative bg-white/80 backdrop-blur-xl rounded-2xl shadow-2xl border-2 border-orange-200 p-8 transform rotate-1 hover:rotate-0 transition-transform">
                <div className="absolute -top-4 -left-4 w-24 h-24 bg-gradient-to-br from-orange-400 to-amber-500 rounded-2xl opacity-20 blur-2xl" />
                <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-gradient-to-br from-orange-400 to-amber-500 rounded-2xl opacity-20 blur-2xl" />
                
                <div className="space-y-4">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-400 to-amber-500 flex items-center justify-center">
                      <Brain className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-800">AI Study Deck</div>
                      <div className="text-sm text-gray-500">Generated in 2 minutes</div>
                    </div>
                  </div>
                  
                  <Card className="bg-orange-50 border-orange-200">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                        <div>
                          <div className="font-medium text-gray-800">World War II History</div>
                          <div className="text-sm text-gray-600 mt-1">45 flashcards • Interactive mind map • Summary notes</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-blue-50 border-blue-200">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <Timer className="w-5 h-5 text-orange-600 mt-1 flex-shrink-0 animate-pulse" />
                        <div>
                          <div className="font-medium text-gray-800">Active Study Session</div>
                          <div className="text-sm text-gray-600 mt-1">Track your progress in real-time</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-purple-50 border-purple-200">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <Users className="w-5 h-5 text-purple-600 mt-1 flex-shrink-0" />
                        <div>
                          <div className="font-medium text-gray-800">Study Group Collaboration</div>
                          <div className="text-sm text-gray-600 mt-1">Learn together with peers</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Everything You Need to <span className="text-orange-600">Excel</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              All-in-one platform designed for modern students who want to achieve more
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard
              icon={Brain}
              title="AI-Powered Decks"
              description="Upload any PDF or text. Get comprehensive flashcards, mind maps, and summaries instantly."
            />
            <FeatureCard
              icon={Timer}
              title="Smart Study Timer"
              description="Track your study sessions with Pomodoro timer. Build consistent habits and see your progress."
            />
            <FeatureCard
              icon={Target}
              title="Goal Management"
              description="Set deadlines, track milestones, and stay motivated with visual progress indicators."
            />
            <FeatureCard
              icon={Users}
              title="Study Groups"
              description="Collaborate with classmates, share resources, and compete on leaderboards."
            />
            <FeatureCard
              icon={Video}
              title="EduTube Courses"
              description="Access thousands of courses created by educators. Learn from the best."
            />
            <FeatureCard
              icon={Briefcase}
              title="Career Center"
              description="Discover internships, scholarships, and opportunities tailored to your interests."
            />
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Get Started in <span className="text-orange-600">3 Easy Steps</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-orange-400 to-amber-500 flex items-center justify-center text-white text-2xl font-bold">
                1
              </div>
              <h3 className="text-2xl font-bold mb-3 text-gray-800">Upload Content</h3>
              <p className="text-gray-600">
                Drop your PDFs, notes, or type in topics you want to study
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-orange-400 to-amber-500 flex items-center justify-center text-white text-2xl font-bold">
                2
              </div>
              <h3 className="text-2xl font-bold mb-3 text-gray-800">AI Generates Materials</h3>
              <p className="text-gray-600">
                Get comprehensive flashcards, mind maps, and summaries in minutes
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-orange-400 to-amber-500 flex items-center justify-center text-white text-2xl font-bold">
                3
              </div>
              <h3 className="text-2xl font-bold mb-3 text-gray-800">Study & Track Progress</h3>
              <p className="text-gray-600">
                Use quiz mode, spaced repetition, and analytics to master any subject
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gradient-to-br from-orange-100/50 to-amber-100/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Loved by <span className="text-orange-600">Students Worldwide</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { name: "Sarah Chen", role: "High School Student", quote: "Striving helped me raise my grades from B to A. The AI flashcards are a game-changer!" },
              { name: "Marcus Johnson", role: "University Student", quote: "Study groups feature is incredible. We collaborate on difficult subjects and everyone benefits." },
              { name: "Emily Rodriguez", role: "IB Student", quote: "Cut my study time in half with smart mind maps. Now I actually understand complex topics!" }
            ].map((testimonial, idx) => (
              <Card key={idx} className="bg-white/80 backdrop-blur-sm border-orange-200">
                <CardContent className="p-6">
                  <div className="flex gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <CheckCircle2 key={i} className="w-5 h-5 text-orange-500 fill-orange-500" />
                    ))}
                  </div>
                  <p className="text-gray-700 mb-4 italic">"{testimonial.quote}"</p>
                  <div>
                    <div className="font-semibold text-gray-800">{testimonial.name}</div>
                    <div className="text-sm text-gray-500">{testimonial.role}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-gradient-to-br from-orange-500 to-amber-600 rounded-3xl p-12 shadow-2xl text-white">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Ready to Transform Your Study Habits?
            </h2>
            <p className="text-xl mb-8 text-orange-50">
              Join students who are already studying smarter, not harder.
            </p>
            <Button 
              size="lg"
              onClick={() => base44.auth.redirectToLogin(createPageUrl('StudyHub'))}
              className="bg-white text-orange-600 hover:bg-gray-100 text-lg h-14 px-8"
            >
              Start Free Today
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <p className="text-sm mt-4 text-orange-100">
              No credit card required • Free forever plan available
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-orange-200 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-3">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ead5d076c2b7a3765c1ee0/ab4d088ff_PHOTO-2025-10-08-15-31-34.jpg" 
                alt="Striving Logo" 
                className="w-8 h-8 rounded-lg"
              />
              <span className="font-bold text-xl text-gray-800">Striving</span>
            </div>
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost"
                size="sm"
                onClick={() => window.open('https://www.instagram.com/striving.ai', '_blank')}
                className="flex items-center gap-2"
              >
                <Instagram className="w-4 h-4" />
                <span>Follow us</span>
              </Button>
              <div className="text-gray-600 text-sm">
                © 2025 Striving. Strive for excellence, and become extraordinary.
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
