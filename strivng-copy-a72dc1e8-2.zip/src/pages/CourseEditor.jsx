
import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, ArrowLeft, Plus, Trash2, Edit, Save, X, Eye, FileText, Video, Download } from 'lucide-react';
import { Combobox } from '@/components/ui/combobox';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import ReactMarkdown from 'react-markdown';

const categoryOptions = [
    { value: "Technology", label: "Technology" },
    { value: "Science", label: "Science" },
    { value: "Arts", label: "Arts" },
    { value: "Business", label: "Business" },
    { value: "Health", label: "Health" },
    { value: "Math", label: "Math" },
    { value: "History", label: "History" },
    { value: "Engineering", label: "Engineering" },
    { value: "Literature", label: "Literature" },
    { value: "Music", label: "Music" },
];
const languages = ["English", "Cantonese", "Mandarin", "Spanish"];
const educationLevels = ["High School", "Undergraduate", "Postgraduate", "Professional"];
const educationSystems = ["General", "HKDSE", "IB", "GCE A-Level", "SAT/AP"];


// --- CourseDetailsForm (No changes needed) ---
const CourseDetailsForm = ({ course }) => {
    const [details, setDetails] = useState({ ...course });
    const [thumbnailFile, setThumbnailFile] = useState(null);
    const queryClient = useQueryClient();

    const mutation = useMutation({
        mutationFn: async (updatedDetails) => {
            let updatePayload = { ...updatedDetails };
            if (thumbnailFile) {
                const { file_url } = await base44.integrations.Core.UploadFile({ file: thumbnailFile });
                updatePayload.thumbnail_url = file_url;
            }
            const { id, created_by, created_date, updated_date, ...finalPayload } = updatePayload;
            return base44.entities.Course.update(course.id, finalPayload);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['course', course.id] });
            queryClient.invalidateQueries({ queryKey: ['createdCourses'] });
            setThumbnailFile(null);
        }
    });

    const handleSave = () => {
        mutation.mutate(details);
    };

    return (
        <Card className="mb-8">
            <CardHeader>
                <CardTitle>Course Details</CardTitle>
                <CardDescription>Edit the main information for your course.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                 <div className="flex items-center gap-6">
                    <img 
                        src={thumbnailFile ? URL.createObjectURL(thumbnailFile) : details.thumbnail_url} 
                        alt="Thumbnail preview" 
                        className="w-48 h-27 object-cover rounded-lg bg-gray-100 border aspect-video"
                    />
                    <div className="grid w-full max-w-sm items-center gap-1.5">
                        <Label htmlFor="thumbnail-upload">Course Thumbnail</Label>
                        <Input id="thumbnail-upload" type="file" accept="image/*" onChange={e => setThumbnailFile(e.target.files[0])} />
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <Label htmlFor="title">Title</Label>
                        <Input id="title" value={details.title} onChange={e => setDetails(p => ({...p, title: e.target.value}))} />
                    </div>
                     <div>
                        <Label>Category</Label>
                        <Combobox
                            options={categoryOptions}
                            value={details.category}
                            onChange={v => setDetails(p => ({...p, category: v}))}
                            placeholder="Select category..."
                            creatable={true}
                        />
                    </div>
                </div>
                <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea id="description" value={details.description} onChange={e => setDetails(p => ({...p, description: e.target.value}))} />
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    <Select value={details.language} onValueChange={v => setDetails(p => ({...p, language: v}))}>
                        <SelectTrigger><SelectValue placeholder="Language"/></SelectTrigger>
                        <SelectContent>{languages.map(c=><SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                    <Select value={details.education_level} onValueChange={v => setDetails(p => ({...p, education_level: v}))}>
                        <SelectTrigger><SelectValue placeholder="Education Level"/></SelectTrigger>
                        <SelectContent>{educationLevels.map(c=><SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                    <Select value={details.education_system} onValueChange={v => setDetails(p => ({...p, education_system: v}))}>
                        <SelectTrigger><SelectValue placeholder="Education System"/></SelectTrigger>
                        <SelectContent>{educationSystems.map(c=><SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                    <div>
                        <Label htmlFor="price" className="sr-only">Price</Label>
                        <Input id="price" type="number" value={details.price} onChange={e => setDetails(p => ({...p, price: parseFloat(e.target.value) || 0}))} placeholder="Price" />
                    </div>
                </div>
                 <div className="flex justify-end">
                    <Button onClick={handleSave} disabled={mutation.isPending}>
                        {mutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin"/>}
                        Save Details
                    </Button>
                </div>
            </CardContent>
        </Card>
    )
}

// --- NEW/UPDATED LessonForm Component ---
const LessonForm = ({ courseId, lesson, onCancel, nextOrder }) => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [contentType, setContentType] = useState('video');
    const [content, setContent] = useState('');
    const [contentFile, setContentFile] = useState(null);
    const [notes, setNotes] = useState('');
    const [downloads, setDownloads] = useState([]);
    const queryClient = useQueryClient();

    useEffect(() => {
        if (lesson) {
            setTitle(lesson.title || '');
            setDescription(lesson.description || '');
            setContentType(lesson.content_type || 'video');
            setContent(lesson.content || '');
            setNotes(lesson.notes || '');
            setDownloads(lesson.downloads?.map(d => ({ ...d, file: null })) || []);
        } else {
            setTitle('');
            setDescription('');
            setContentType('video');
            setContent('');
            setNotes('');
            setDownloads([]);
        }
        setContentFile(null);
    }, [lesson]);

    const mutation = useMutation({
        mutationFn: async (formData) => {
            let payload = { ...formData };
            
            // 1. Upload main content file if it exists
            if (contentFile) {
                const { file_url } = await base44.integrations.Core.UploadFile({ file: contentFile });
                payload.content = file_url;
            }

            // 2. Sequentially upload download files to prevent timeouts
            const finalDownloads = [];
            if (payload.downloads) {
                for (const download of payload.downloads) {
                    if (download.file) { // If a new file is attached
                        const { file_url } = await base44.integrations.Core.UploadFile({ file: download.file });
                        finalDownloads.push({ name: download.name, url: file_url });
                    } else if (download.url) { // If it's an existing file
                        finalDownloads.push({ name: download.name, url: download.url });
                    }
                }
            }
            payload.downloads = finalDownloads.filter(d => d.name && d.url);

            // 3. Save lesson data
            if (lesson?.id) {
                return base44.entities.Lesson.update(lesson.id, payload);
            } else {
                return base44.entities.Lesson.create({ ...payload, course_id: courseId, order: nextOrder });
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['lessons', courseId] });
            onCancel();
        },
        onError: (err) => {
            alert(`Failed to save lesson: ${err.message}`);
        }
    });

    const handleSubmit = () => {
        if (!title) {
            alert("Please enter a title for the lesson.");
            return;
        }
        const formData = { title, description, content_type: contentType, content, notes, downloads };
        mutation.mutate(formData);
    };
    
    const handleAddDownload = () => {
        setDownloads([...downloads, { name: '', url: null, file: null }]);
    };

    const handleDownloadChange = (index, field, value) => {
        const newDownloads = [...downloads];
        newDownloads[index][field] = value;
        if(field === 'file' && value instanceof File && !newDownloads[index].name) {
            newDownloads[index].name = value.name; // Auto-fill name if empty
        }
        setDownloads(newDownloads);
    };
    
    const handleRemoveDownload = (index) => {
        setDownloads(downloads.filter((_, i) => i !== index));
    };

    return (
        <DialogContent className="max-w-2xl">
            <DialogHeader>
                <DialogTitle>{lesson?.id ? 'Edit Lesson' : 'Add New Lesson'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4 max-h-[70vh] overflow-y-auto pr-4">
                {/* --- Main Content Section --- */}
                <div className="space-y-2">
                    <Label htmlFor="lesson-title" className="font-semibold">Title</Label>
                    <Input id="lesson-title" value={title} onChange={e => setTitle(e.target.value)} />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="lesson-description">Description (optional)</Label>
                    <Textarea id="lesson-description" value={description} onChange={e => setDescription(e.target.value)} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                      <Label>Content Type</Label>
                      <Select value={contentType} onValueChange={setContentType}>
                          <SelectTrigger><SelectValue/></SelectTrigger>
                          <SelectContent>
                              <SelectItem value="video">Video</SelectItem>
                              <SelectItem value="pdf">PDF</SelectItem>
                              <SelectItem value="text">Text</SelectItem>
                          </SelectContent>
                      </Select>
                  </div>
                   <div className="space-y-2">
                     <Label>Main Content</Label>
                      {contentType === 'text' ? (
                          <Textarea placeholder="Write content..." value={content} onChange={e => setContent(e.target.value)} rows={3} />
                      ) : (
                          <Input type="file" accept={contentType === 'video' ? 'video/*' : 'application/pdf'} onChange={e => setContentFile(e.target.files[0])} />
                      )}
                      {(contentType === 'video' || contentType === 'pdf') && content && !contentFile && (
                          <p className="text-xs text-gray-500 mt-1">Current file: <a href={content} target="_blank" rel="noreferrer" className="underline">{content.split('/').pop()}</a></p>
                      )}
                  </div>
                </div>

                {/* --- Lesson Resources Section --- */}
                <div className="space-y-4 pt-4 mt-4 border-t">
                    <h3 className="font-semibold text-lg">Lesson Resources</h3>
                    <div className="space-y-2">
                        <Label htmlFor="lesson-notes">Notes / Transcript</Label>
                        <Textarea id="lesson-notes" placeholder="Add notes here. Markdown is supported." value={notes} onChange={e => setNotes(e.target.value)} rows={8} />
                    </div>
                    
                    <div className="space-y-2">
                        <Label>Downloads</Label>
                        <div className="space-y-3">
                            {downloads.map((download, index) => (
                                <div key={index} className="flex items-center gap-2 p-2 border rounded-md">
                                    <Input placeholder="File display name" value={download.name} onChange={(e) => handleDownloadChange(index, 'name', e.target.value)} className="flex-grow"/>
                                    <div className="flex-shrink-0 w-48 text-sm">
                                        <Input type="file" onChange={(e) => handleDownloadChange(index, 'file', e.target.files[0])} />
                                        {download.url && !download.file && (
                                            <p className="text-xs text-gray-500 mt-1 truncate">Current: <a href={download.url} target="_blank" rel="noreferrer" className="underline">{download.url.split('/').pop()}</a></p>
                                        )}
                                    </div>
                                    <Button variant="ghost" size="icon" onClick={() => handleRemoveDownload(index)}><Trash2 className="w-4 h-4 text-red-500"/></Button>
                                </div>
                            ))}
                        </div>
                        <Button variant="outline" size="sm" onClick={handleAddDownload} className="mt-2">
                            <Plus className="w-4 h-4 mr-2"/> Add Downloadable File
                        </Button>
                    </div>
                </div>
            </div>
            <DialogFooter>
                <Button variant="ghost" onClick={onCancel}>Cancel</Button>
                <Button onClick={handleSubmit} disabled={mutation.isPending}>
                    {mutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                    Save Lesson
                </Button>
            </DialogFooter>
        </DialogContent>
    );
};


// --- LessonItem (No functional changes needed, but for context) ---
const LessonItem = ({ lesson, onEdit, onDelete }) => (
    <Card className="mb-2">
        <CardContent className="p-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
                {lesson.content_type === 'video' ? <Video className="w-5 h-5 text-orange-600" /> : <FileText className="w-5 h-5 text-orange-600" />}
                <div>
                    <p className="font-medium">{lesson.title}</p>
                    <p className="text-sm text-gray-500 truncate">{lesson.description || 'No description'}</p>
                </div>
            </div>
            <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" onClick={() => onEdit(lesson)}><Edit className="w-4 h-4" /></Button>
                <AlertDialog>
                    <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="icon"><Trash2 className="w-4 h-4 text-red-500" /></Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                        <AlertDialogHeader><AlertDialogTitle>Are you sure?</AlertDialogTitle><AlertDialogDescription>This will permanently delete the lesson.</AlertDialogDescription></AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => onDelete(lesson.id)}>Delete</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            </div>
        </CardContent>
    </Card>
);

// --- REBUILT CourseEditorPage ---
export default function CourseEditorPage() {
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = urlParams.get('courseId');
    const queryClient = useQueryClient();

    const [isFormOpen, setFormOpen] = useState(false);
    const [selectedLesson, setSelectedLesson] = useState(null);

    const { data: course, isLoading: isLoadingCourse } = useQuery({
        queryKey: ['course', courseId],
        queryFn: () => base44.entities.Course.get(courseId),
        enabled: !!courseId,
    });

    const { data: lessons = [], isLoading: isLoadingLessons } = useQuery({
        queryKey: ['lessons', courseId],
        queryFn: () => base44.entities.Lesson.filter({ course_id: courseId }, 'order'),
        enabled: !!courseId,
    });
    
    const deleteMutation = useMutation({
        mutationFn: (lessonId) => base44.entities.Lesson.delete(lessonId),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['lessons', courseId] });
        }
    });

    const handleAddLesson = () => {
        setSelectedLesson(null);
        setFormOpen(true);
    };

    const handleEditLesson = (lesson) => {
        setSelectedLesson(lesson);
        setFormOpen(true);
    };

    if (isLoadingCourse) {
        return <div className="flex items-center justify-center h-screen"><Loader2 className="w-12 h-12 animate-spin text-orange-500" /></div>;
    }

    if (!course) {
        return <div className="text-center py-20">Course not found. Return to the <Link to={createPageUrl('Create')} className="text-orange-600 underline">Creator Dashboard</Link>.</div>;
    }

    return (
        <div className="p-6 md:p-8">
            <div className="max-w-4xl mx-auto">
                <Link to={createPageUrl('Create')} className="text-sm text-gray-500 hover:text-orange-600 flex items-center gap-2 mb-4">
                    <ArrowLeft className="w-4 h-4"/> Back to Creator Dashboard
                </Link>

                <CourseDetailsForm course={course} />

                <Card>
                    <CardHeader className="flex flex-row items-center justify-between">
                        <div>
                            <CardTitle>Lessons</CardTitle>
                            <CardDescription>Manage the lessons for your course.</CardDescription>
                        </div>
                        <Button onClick={handleAddLesson}>
                            <Plus className="w-4 h-4 mr-2"/> Add New Lesson
                        </Button>
                    </CardHeader>
                    <CardContent>
                        {isLoadingLessons && <Loader2 className="w-6 h-6 animate-spin mx-auto"/>}

                        {!isLoadingLessons && lessons.length === 0 && (
                            <p className="text-center text-gray-500 py-8">No lessons yet. Click "Add New Lesson" to get started.</p>
                        )}
                        
                        <div className="space-y-2">
                          {!isLoadingLessons && lessons.map((lesson) => (
                              <LessonItem 
                                  key={lesson.id} 
                                  lesson={lesson} 
                                  onEdit={handleEditLesson} 
                                  onDelete={deleteMutation.mutate}
                              />
                          ))}
                        </div>
                    </CardContent>
                </Card>
            </div>
            
            <Dialog open={isFormOpen} onOpenChange={setFormOpen}>
                <LessonForm 
                    courseId={courseId} 
                    lesson={selectedLesson} 
                    onCancel={() => setFormOpen(false)}
                    nextOrder={lessons.length + 1}
                />
            </Dialog>
        </div>
    );
}
