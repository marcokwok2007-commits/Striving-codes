
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { add, format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, eachDayOfInterval, isSameMonth, isSameDay, sub } from "date-fns";
import { ChevronLeft, ChevronRight, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import StudyAgent from "../components/StudyAgent";
import EventEditor from "../components/calendar/EventEditor";

const priorityColors = {
  high: 'bg-red-100 text-red-800',
  medium: 'bg-yellow-100 text-yellow-800',
  low: 'bg-green-100 text-green-800'
}

const formatTime12h = (time) => {
    if (!time) return '';
    const [hours, minutes] = time.split(':');
    const h = parseInt(hours);
    const m = parseInt(minutes);
    const ampm = h >= 12 ? 'pm' : 'am';
    const hour12 = h % 12 || 12;
    return `${hour12}:${m.toString().padStart(2, '0')} ${ampm}`;
};

const DayDetailsDialog = ({ day, events, onClose, onAddNew, onDelete }) => {
  return (
    <DialogContent className="sm:max-w-[500px]">
      <DialogHeader>
        <DialogTitle>Events on {format(day, 'MMMM d, yyyy')}</DialogTitle>
      </DialogHeader>
      <div className="py-4">
        {events.length === 0 ? (
          <p className="text-center text-gray-500 py-8">No events scheduled for this day.</p>
        ) : (
          <div className="space-y-3">
            {events.map(event => (
              <div key={event.id} className={`p-3 rounded-lg ${event.duration_minutes ? 'bg-blue-50 border border-blue-200' : 'bg-orange-50 border border-orange-200'}`}>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      {event.target_time && <span className="font-bold text-sm">{formatTime12h(event.target_time)}</span>}
                      <span className="font-semibold">{event.title || event.goal_title}</span>
                    </div>
                    {event.description && <p className="text-sm text-gray-600 mt-1">{event.description}</p>}
                    {event.subject && <p className="text-xs text-gray-500 mt-1">Subject: {event.subject}</p>}
                  </div>
                  <div className="flex items-start gap-2">
                    {event.priority && (
                      <span className={`px-2 py-1 rounded text-xs ${priorityColors[event.priority]}`}>
                        {event.priority}
                      </span>
                    )}
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Event</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete "{event.title || event.goal_title}"? This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => onDelete(event)}>Delete</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <DialogFooter className="gap-2">
        <Button onClick={onAddNew} variant="outline">
          <Plus className="w-4 h-4 mr-2" /> Add New Event
        </Button>
        <Button onClick={onClose}>Close</Button>
      </DialogFooter>
    </DialogContent>
  );
};

export default function CalendarPage() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(null);
  const [isDayDetailsOpen, setIsDayDetailsOpen] = useState(false);
  const [selectedDayForDetails, setSelectedDayForDetails] = useState(null);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({ 
    queryKey: ['currentUser'], 
    queryFn: () => base44.auth.me(),
    staleTime: Infinity,
    refetchOnWindowFocus: false,
  });

  const { data: goals = [] } = useQuery({
    queryKey: ["goals", user?.email],
    queryFn: () => base44.entities.Goal.filter({ created_by: user.email }),
    enabled: !!user,
    staleTime: 30000,
    refetchOnWindowFocus: false,
  });

  const { data: sessions = [] } = useQuery({
    queryKey: ["studySessions", user?.email],
    queryFn: () => base44.entities.StudySession.filter({ created_by: user.email }),
    enabled: !!user,
    staleTime: 30000,
    refetchOnWindowFocus: false,
  });

  const deleteGoalMutation = useMutation({
    mutationFn: (goalId) => base44.entities.Goal.delete(goalId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['goals'] });
    }
  });

  const deleteSessionMutation = useMutation({
    mutationFn: (sessionId) => base44.entities.StudySession.delete(sessionId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['studySessions'] });
    }
  });

  const firstDayOfMonth = startOfMonth(currentDate);
  const lastDayOfMonth = endOfMonth(currentDate);
  const firstDayOfCalendar = startOfWeek(firstDayOfMonth);
  const lastDayOfCalendar = endOfWeek(lastDayOfMonth);
  const days = eachDayOfInterval({ start: firstDayOfCalendar, end: lastDayOfCalendar });

  const getEventsForDay = (day) => {
    const dayGoals = goals.filter(g => g.target_date && new Date(g.target_date).toDateString() === day.toDateString());
    const daySessions = sessions.filter(s => new Date(s.session_date).toDateString() === day.toDateString());
    return [...dayGoals, ...daySessions];
  };

  const handleDayClick = (day, events) => {
    setSelectedDayForDetails(day);
    setIsDayDetailsOpen(true);
  };

  const handleAddNewFromDetails = () => {
    setIsDayDetailsOpen(false);
    setSelectedDate(selectedDayForDetails);
    setIsEditorOpen(true);
  };

  const handleDeleteEvent = async (event) => {
    if (event.duration_minutes !== undefined) {
      await deleteSessionMutation.mutateAsync(event.id);
    } else {
      await deleteGoalMutation.mutateAsync(event.id);
    }
  };

  return (
    <div className="p-6 md:p-8 bg-orange-50/20 min-h-full">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" onClick={() => setCurrentDate(sub(currentDate, { months: 1 }))}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <h2 className="text-xl font-semibold text-gray-700 w-40 text-center">
              {format(currentDate, "MMMM yyyy")}
            </h2>
            <Button variant="outline" size="icon" onClick={() => setCurrentDate(add(currentDate, { months: 1 }))}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="hidden md:flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-red-200"></div>High</div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-yellow-200"></div>Medium</div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-green-200"></div>Low</div>
          </div>
        </div>

        <Card className="bg-white border rounded-xl shadow-sm">
          <CardContent className="p-2">
            <div className="grid grid-cols-7 text-center font-medium text-gray-500 border-b">
              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(day => (
                <div key={day} className="py-3">{day}</div>
              ))}
            </div>

            <div className="grid grid-cols-7">
              {days.map((day) => {
                const events = getEventsForDay(day);
                return (
                  <div
                    key={day.toString()}
                    className={`h-32 border-b border-r p-2 flex flex-col cursor-pointer hover:bg-orange-50/50 transition-colors ${
                      !isSameMonth(day, currentDate) ? "bg-gray-50 text-gray-400" : ""
                    }`}
                    onClick={() => handleDayClick(day, events)}
                  >
                    <span className={`font-medium ${isSameDay(day, new Date()) ? 'bg-orange-500 text-white rounded-full w-7 h-7 flex items-center justify-center' : ''}`}>
                      {format(day, "d")}
                    </span>
                    <div className="mt-1 space-y-1 overflow-y-auto text-xs">
                      {events.slice(0, 3).map(event => (
                        <div key={event.id} className={`p-1 rounded-md truncate ${event.duration_minutes ? 'bg-blue-100 text-blue-800' : priorityColors[event.priority] || 'bg-gray-100'}`}>
                          {event.target_time && <span className="font-bold">{formatTime12h(event.target_time)} </span>} {event.title || event.goal_title}
                        </div>
                      ))}
                      {events.length > 3 && (
                        <div className="text-xs text-gray-500 font-semibold">+{events.length - 3} more</div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Dialog open={isEditorOpen} onOpenChange={setIsEditorOpen}>
        {selectedDate && <EventEditor date={selectedDate} onFinished={() => setIsEditorOpen(false)} />}
      </Dialog>
      
      <Dialog open={isDayDetailsOpen} onOpenChange={setIsDayDetailsOpen}>
        {selectedDayForDetails && (
          <DayDetailsDialog 
            day={selectedDayForDetails} 
            events={getEventsForDay(selectedDayForDetails)} 
            onClose={() => setIsDayDetailsOpen(false)}
            onAddNew={handleAddNewFromDetails}
            onDelete={handleDeleteEvent}
          />
        )}
      </Dialog>
      
      <StudyAgent />
    </div>
  );
}
