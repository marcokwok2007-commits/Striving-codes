import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlusCircle, Lock, Loader2, Edit, BarChartHorizontal, Trash2, Users, DollarSign, Video, TrendingUp, Star, BookOpen } from "lucide-react";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import StudyAgent from "../components/StudyAgent";
import { Dialog, DialogTrigger } from "@/components/ui/dialog";
import CreateCourseDialog from "../components/creator/CreateCourseDialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const CreatorCourseCard = ({ course, onDelete }) => {
    return (
        <Card className="overflow-hidden border rounded-xl group bg-white flex flex-col">
            <div className="aspect-video overflow-hidden bg-gray-100 flex items-center justify-center">
                {course.thumbnail_url ? (
                    <img
                        src={course.thumbnail_url}
                        alt={course.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                ) : (
                    <span className="text-sm text-gray-400">No thumbnail</span>
                )}
            </div>
            <CardContent className="p-4 flex-grow flex flex-col">
                <h3 className="font-semibold text-base leading-snug flex-grow">{course.title}</h3>
                <p className="text-sm text-gray-500 mt-1">{course.category}</p>
            </CardContent>
            <div className="p-4 border-t grid grid-cols-2 gap-2">
                <Button asChild variant="outline">
                   <Link to={createPageUrl(`CourseEditor?courseId=${course.id}`)}>
                     <Edit className="w-4 h-4 mr-2"/> Edit
                   </Link>
                </Button>
                <AlertDialog>
                    <AlertDialogTrigger asChild>
                        <Button variant="destructive-outline" size="sm">
                            <Trash2 className="w-4 h-4 mr-2"/> Delete
                        </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete this course and all of its associated lessons.
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => onDelete(course.id)}>Continue</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            </div>
        </Card>
    );
};

export default function CreatePage() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const queryClient = useQueryClient();

  const { data: user, isLoading: isLoadingUser } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: createdCourses, isLoading: isLoadingCourses } = useQuery({
    queryKey: ['createdCourses', user?.email],
    queryFn: () => base44.entities.Course.filter({ created_by: user.email }, '-created_date'),
    enabled: !!user,
    initialData: []
  });

  const { data: allEnrollments, isLoading: isLoadingEnrollments } = useQuery({
    queryKey: ['creatorEnrollments', user?.email],
    queryFn: async () => {
      if (!createdCourses || createdCourses.length === 0) return [];
      const courseIds = createdCourses.map(c => c.id);
      const enrollments = await base44.entities.Enrollment.filter({
        course_id: { $in: courseIds }
      });
      return enrollments;
    },
    enabled: !!createdCourses && createdCourses.length > 0,
    initialData: []
  });

  const { data: allRatings, isLoading: isLoadingRatings } = useQuery({
    queryKey: ['creatorRatings', user?.email],
    queryFn: async () => {
      if (!createdCourses || createdCourses.length === 0) return [];
      const courseIds = createdCourses.map(c => c.id);
      const ratings = await base44.entities.Rating.filter({
        course_id: { $in: courseIds }
      });
      return ratings;
    },
    enabled: !!createdCourses && createdCourses.length > 0,
    initialData: []
  });

  const stats = React.useMemo(() => {
    if (!createdCourses || !allEnrollments || !allRatings) {
      return {
        totalCourses: 0,
        totalStudents: 0,
        totalRevenue: 0,
        averageRating: 0,
        totalRatings: 0,
      };
    }

    const totalStudents = allEnrollments.length;
    const totalRevenue = createdCourses.reduce((sum, course) => {
      const enrollmentCount = allEnrollments.filter(e => e.course_id === course.id).length;
      return sum + (course.price * enrollmentCount);
    }, 0);

    const totalRatingsSum = allRatings.reduce((sum, r) => sum + r.rating, 0);
    const averageRating = allRatings.length > 0 ? (totalRatingsSum / allRatings.length).toFixed(1) : 0;

    return {
      totalCourses: createdCourses.length,
      totalStudents,
      totalRevenue,
      averageRating,
      totalRatings: allRatings.length,
    };
  }, [createdCourses, allEnrollments, allRatings]);

  const deleteCourseMutation = useMutation({
      mutationFn: async (courseId) => {
          const lessonsToDelete = await base44.entities.Lesson.filter({ course_id: courseId });
          for (const lesson of lessonsToDelete) {
              await base44.entities.Lesson.delete(lesson.id);
          }
          return base44.entities.Course.delete(courseId);
      },
      onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ['createdCourses', user.email] });
          queryClient.invalidateQueries({ queryKey: ['courses'] });
      }
  });

  if (isLoadingUser) {
    return (
      <div className="p-6 md:p-8 text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto"/>
      </div>
    );
  }

  if (!user?.creator_mode) {
    return (
      <div className="p-6 md:p-8">
        <div className="max-w-7xl mx-auto">
          <Card className="bg-white border rounded-xl shadow-sm">
            <CardContent className="py-24 text-center">
              <Lock className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <h3 className="text-xl font-semibold text-gray-700">Creator Mode Required</h3>
              <p className="text-gray-500 mt-2 mb-6">You need to enable Creator Mode in your settings to access course creation tools.</p>
              <Button asChild>
                <Link to={createPageUrl('Settings')}>Go to Settings</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
        <StudyAgent />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Analytics Section */}
        {createdCourses.length > 0 && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Creator Analytics</h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-8">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Total Students</CardTitle>
                  <Users className="w-5 h-5 text-blue-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-gray-900">{stats.totalStudents}</div>
                  <p className="text-xs text-gray-500 mt-1">Across all courses</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Total Revenue</CardTitle>
                  <DollarSign className="w-5 h-5 text-green-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-gray-900">${stats.totalRevenue.toFixed(2)}</div>
                  <p className="text-xs text-gray-500 mt-1">Lifetime earnings</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Total Courses</CardTitle>
                  <Video className="w-5 h-5 text-purple-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-gray-900">{stats.totalCourses}</div>
                  <p className="text-xs text-gray-500 mt-1">Published courses</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Average Rating</CardTitle>
                  <Star className="w-5 h-5 text-yellow-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-gray-900">{stats.averageRating}</div>
                  <p className="text-xs text-gray-500 mt-1">From {stats.totalRatings} ratings</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Avg. Students/Course</CardTitle>
                  <TrendingUp className="w-5 h-5 text-orange-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-gray-900">
                    {stats.totalCourses > 0 ? Math.round(stats.totalStudents / stats.totalCourses) : 0}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Engagement metric</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Avg. Revenue/Course</CardTitle>
                  <DollarSign className="w-5 h-5 text-green-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-gray-900">
                    ${stats.totalCourses > 0 ? (stats.totalRevenue / stats.totalCourses).toFixed(2) : '0.00'}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Per course earnings</p>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* Courses Section */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">My Courses</h2>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <PlusCircle className="w-4 h-4 mr-2" />
                Create New Course
              </Button>
            </DialogTrigger>
            <CreateCourseDialog user={user} setDialogOpen={setIsCreateDialogOpen} />
          </Dialog>
        </div>

        <div>
          {isLoadingCourses && <div className="text-center"><Loader2 className="w-8 h-8 animate-spin mx-auto"/></div>}
          {!isLoadingCourses && createdCourses?.length === 0 ? (
              <Card className="bg-white border rounded-xl shadow-sm">
                <CardContent className="py-24 text-center">
                  <Video className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                  <h3 className="text-xl font-semibold text-gray-700">No Courses Yet</h3>
                  <p className="text-gray-500 mt-2 mb-6">You haven't created any courses yet. Click "Create New Course" to get started.</p>
                </CardContent>
              </Card>
          ) : (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-6 gap-y-8">
                  {createdCourses?.map(course => (
                      <CreatorCourseCard key={course.id} course={course} onDelete={deleteCourseMutation.mutate} />
                  ))}
              </div>
          )}
        </div>
      </div>
      <StudyAgent />
    </div>
  );
}