
import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Loader2 } from "lucide-react";
import FilterBar from "../components/edutube/FilterBar";
import StudyAgent from "../components/StudyAgent";
import { useDebounce } from "../components/hooks/useDebounce";
import StarRating from "../components/ui/StarRating";

function CourseCard({ course }) {
  return (
    <Card className="overflow-hidden border-none shadow-none rounded-xl group bg-transparent flex flex-col">
      <Link to={createPageUrl(`CourseViewer?courseId=${course.id}`)} className="block">
        <div className="aspect-video overflow-hidden rounded-lg bg-gray-100 flex items-center justify-center">
          {course.thumbnail_url ? (
            <img
              src={course.thumbnail_url}
              alt={course.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <span className="text-sm text-gray-400">No thumbnail</span>
          )}
        </div>
      </Link>
      <CardContent className="p-4 pl-0 flex-grow">
        <div className="flex items-start gap-3">
           <Avatar className="w-9 h-9 mt-1">
              <AvatarImage src={course.creator_avatar_url} />
              <AvatarFallback>{course.creator_name ? course.creator_name.charAt(0) : '?'}</AvatarFallback>
            </Avatar>
          <div className="flex-grow">
            <Link to={createPageUrl(`CourseViewer?courseId=${course.id}`)} className="block">
              <h3 className="font-semibold text-base leading-snug group-hover:text-orange-600 transition-colors">{course.title}</h3>
            </Link>
            <p className="text-sm text-gray-500 mt-1">{course.creator_name}</p>
            <div className="flex items-center gap-4 mt-1">
                <StarRating rating={course.average_rating} count={course.rating_count} interactive={false} size="sm" />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function EduTubePage() {
  const [filters, setFilters] = useState({
    category: '',
    price: 'all',
    language: '',
    education_level: '',
    education_system: '',
    searchTerm: '',
    myCoursesOnly: false,
  });
  
  const debouncedSearchTerm = useDebounce(filters.searchTerm, 300);

  const { data: user } = useQuery({ 
    queryKey: ['currentUser'], 
    queryFn: () => base44.auth.me(),
    staleTime: Infinity,
    refetchOnWindowFocus: false,
  });

  const { data: enrollments, isLoading: isLoadingEnrollments } = useQuery({
    queryKey: ["enrollments", user?.email],
    queryFn: () => base44.entities.Enrollment.filter({ user_email: user.email }),
    enabled: !!user && filters.myCoursesOnly,
    staleTime: 60000,
    refetchOnWindowFocus: false,
  });

  const { data: courses, isLoading: isLoadingCourses } = useQuery({
    queryKey: ["courses", filters.category, filters.price, filters.language, filters.education_level, filters.education_system, debouncedSearchTerm, filters.myCoursesOnly, enrollments],
    queryFn: () => {
      const queryFilters = {};
      if (debouncedSearchTerm) {
          queryFilters.$text = { $search: debouncedSearchTerm };
      }
      Object.entries(filters).forEach(([key, value]) => {
        if (value && value !== 'all' && !['searchTerm', 'myCoursesOnly'].includes(key)) {
          if (key === 'price') {
            if (value === 'free') queryFilters.price = 0;
            if (value === 'paid') queryFilters.price = { $gt: 0 };
          } else {
            queryFilters[key] = value;
          }
        }
      });
      
      if (filters.myCoursesOnly) {
        if (!enrollments || enrollments.length === 0) return [];
        const enrolledCourseIds = enrollments.map(e => e.course_id);
        queryFilters.id = { $in: enrolledCourseIds };
      }

      return base44.entities.Course.filter(queryFilters);
    },
    enabled: !filters.myCoursesOnly || (filters.myCoursesOnly && !isLoadingEnrollments),
    initialData: [],
    staleTime: 60000,
    refetchOnWindowFocus: false,
  });

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const isLoading = isLoadingCourses || (filters.myCoursesOnly && isLoadingEnrollments);

  return (
    <div className="p-6 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <FilterBar filters={filters} onFilterChange={handleFilterChange} />
        </div>
        
        {isLoading ? (
          <div className="text-center py-16">
            <Loader2 className="mx-auto h-12 w-12 text-orange-500 animate-spin" />
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-6 gap-y-4">
            {courses.map(course => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        )}
        
        {!isLoading && courses.length === 0 && (
            <div className="text-center py-24">
                <p className="text-gray-500">No courses found matching your criteria. Try adjusting the filters.</p>
            </div>
        )}
      </div>
      <StudyAgent />
    </div>
  );
}
