import Layout from "./Layout.jsx";

import Settings from "./Settings";

import Calendar from "./Calendar";

import StudyHub from "./StudyHub";

import Deck from "./Deck";

import EduTube from "./EduTube";

import Create from "./Create";

import Profile from "./Profile";

import CareerCenter from "./CareerCenter";

import CourseViewer from "./CourseViewer";

import CourseEditor from "./CourseEditor";

import Home from "./Home";

import CreatorDashboard from "./CreatorDashboard";

import Checkout from "./Checkout";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Settings: Settings,
    
    Calendar: Calendar,
    
    StudyHub: StudyHub,
    
    Deck: Deck,
    
    EduTube: EduTube,
    
    Create: Create,
    
    Profile: Profile,
    
    CareerCenter: CareerCenter,
    
    CourseViewer: CourseViewer,
    
    CourseEditor: CourseEditor,
    
    Home: Home,
    
    CreatorDashboard: CreatorDashboard,
    
    Checkout: Checkout,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Settings />} />
                
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Calendar" element={<Calendar />} />
                
                <Route path="/StudyHub" element={<StudyHub />} />
                
                <Route path="/Deck" element={<Deck />} />
                
                <Route path="/EduTube" element={<EduTube />} />
                
                <Route path="/Create" element={<Create />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/CareerCenter" element={<CareerCenter />} />
                
                <Route path="/CourseViewer" element={<CourseViewer />} />
                
                <Route path="/CourseEditor" element={<CourseEditor />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/CreatorDashboard" element={<CreatorDashboard />} />
                
                <Route path="/Checkout" element={<Checkout />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}