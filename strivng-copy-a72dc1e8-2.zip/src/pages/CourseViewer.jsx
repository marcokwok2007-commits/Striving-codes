
import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { Link, useLocation } from "react-router-dom";
import ReactMarkdown from 'react-markdown';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import CustomVideoPlayer from '../components/edutube/CustomVideoPlayer';
import StarRating from '../components/ui/StarRating';
import { Loader2, PlayCircle, Lock, Download, CheckCircle, ArrowLeft, Users, Clock, ChevronLeft, ChevronRight, FileText, Video, CreditCard } from 'lucide-react';
import { cn } from '@/lib/utils';

const LessonContent = ({ lesson, isEnrolled }) => {
  if (!lesson) return <p className="text-center text-gray-500 p-8">Select a lesson to begin.</p>;
  
  if (!isEnrolled && !lesson.is_free_preview) {
    return (
      <div className="flex flex-col items-center justify-center h-96 bg-gray-50 rounded-lg text-center p-8">
        <Lock className="w-16 h-16 mb-4 text-gray-300" />
        <h3 className="text-xl font-semibold text-gray-700 mb-2">Lesson Locked</h3>
        <p className="text-gray-500 mb-4">Enroll in the course to unlock this lesson.</p>
      </div>
    );
  }

  if (lesson.content_type === 'video') {
    return <CustomVideoPlayer src={lesson.content} />;
  }
  if (lesson.content_type === 'text') {
    return <ReactMarkdown className="prose max-w-none p-4 bg-gray-50 rounded-lg">{lesson.content}</ReactMarkdown>;
  }
  if (lesson.content_type === 'pdf') {
    return (
      <div className="w-full aspect-video bg-gray-100 rounded-lg">
        <iframe src={lesson.content} className="w-full h-full border-0 rounded-lg" title={lesson.title} allowFullScreen />
      </div>
    );
  }
  return <p className="text-gray-500">Unsupported lesson type.</p>;
};

export default function CourseViewer() {
  const queryClient = useQueryClient();
  const location = useLocation();
  const courseId = new URLSearchParams(location.search).get('courseId');

  const [activeLessonId, setActiveLessonId] = useState(null);
  const [userRating, setUserRating] = useState(0);
  const [isSubmittingRating, setIsSubmittingRating] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  const { data: user } = useQuery({ 
    queryKey: ['currentUser'], 
    queryFn: () => base44.auth.me(),
  });

  const { data: course, isLoading: isLoadingCourse } = useQuery({
    queryKey: ['course', courseId],
    queryFn: () => base44.entities.Course.get(courseId),
    enabled: !!courseId,
  });

  const { data: lessons = [], isLoading: isLoadingLessons } = useQuery({
    queryKey: ['lessons', courseId],
    queryFn: () => base44.entities.Lesson.filter({ course_id: courseId }, 'order'),
    enabled: !!courseId,
  });

  useEffect(() => {
    if (lessons.length > 0 && !activeLessonId) {
      setActiveLessonId(lessons[0].id);
    }
  }, [lessons, activeLessonId]);

  const { data: enrollment } = useQuery({
    queryKey: ['enrollment', courseId, user?.email],
    queryFn: async () => {
      const enrollments = await base44.entities.Enrollment.filter({ 
        course_id: courseId, 
        user_email: user.email 
      });
      return enrollments[0] || null;
    },
    enabled: !!user && !!courseId,
  });

  // Check if user has purchased this course
  const hasPurchased = user?.purchased_courses?.includes(courseId);
  const isEnrolled = !!enrollment || hasPurchased;

  const { data: ratings = [] } = useQuery({
    queryKey: ['ratings', courseId],
    queryFn: () => base44.entities.Rating.filter({ course_id: courseId }),
    enabled: !!courseId,
  });

  useEffect(() => {
    if (ratings && user) {
      const currentUserRating = ratings.find(r => r.user_email === user.email);
      setUserRating(currentUserRating ? currentUserRating.rating : 0);
    }
  }, [ratings, user]);

  const enrollMutation = useMutation({
    mutationFn: async () => {
      // If course is free, just enroll
      if (course.price === 0) {
        await base44.entities.Enrollment.create({ 
          course_id: courseId, 
          user_email: user.email 
        });
        
        const allEnrollments = await base44.entities.Enrollment.filter({ course_id: courseId });
        await base44.entities.Course.update(courseId, { 
          enrollment_count: allEnrollments.length 
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['enrollment'] });
      queryClient.invalidateQueries({ queryKey: ['course'] });
    }
  });

  const ratingMutation = useMutation({
    mutationFn: async (newRatingValue) => {
      setIsSubmittingRating(true);
      const currentUserRatingRecord = ratings.find(r => r.user_email === user.email);
      const ratingPayload = { 
        course_id: courseId, 
        user_email: user.email, 
        rating: newRatingValue 
      };
      
      if (currentUserRatingRecord) {
        await base44.entities.Rating.update(currentUserRatingRecord.id, ratingPayload);
      } else {
        await base44.entities.Rating.create(ratingPayload);
      }

      const allRatings = await base44.entities.Rating.filter({ course_id: courseId });
      const totalRating = allRatings.reduce((sum, r) => sum + r.rating, 0);
      const ratingCount = allRatings.length;
      const averageRating = ratingCount > 0 ? totalRating / ratingCount : 0;

      await base44.entities.Course.update(courseId, {
        average_rating: parseFloat(averageRating.toFixed(1)),
        rating_count: ratingCount
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ratings'] });
      queryClient.invalidateQueries({ queryKey: ['course'] });
      setIsSubmittingRating(false);
    },
    onError: () => setIsSubmittingRating(false)
  });

  const activeLesson = lessons.find(lesson => lesson.id === activeLessonId) || lessons[0];

  const getContentTypeLabel = (contentType) => {
    const labels = {
      'video': 'Video:',
      'pdf': 'Reading:',
      'text': 'Reading:'
    };
    return labels[contentType] || 'Content:';
  };

  if (isLoadingCourse || isLoadingLessons) {
    return (
      <div className="flex flex-col justify-center items-center h-screen gap-4">
        <Loader2 className="w-16 h-16 animate-spin text-orange-500" />
        <p className="text-gray-600">Loading course content...</p>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="flex justify-center items-center h-screen">
        <p className="text-xl text-gray-600">Course not found.</p>
      </div>
    );
  }

  const hasRated = userRating > 0;

  return (
    <div className="min-h-screen flex w-full bg-gray-50">
      {/* Sidebar */}
      <aside className={cn(
        "bg-white border-r overflow-y-auto transition-all duration-300",
        isSidebarCollapsed ? "w-0" : "w-80"
      )}>
        <div className="p-4">
          <button 
            onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
            className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-700 font-medium mb-4"
          >
            <ChevronLeft className="w-4 h-4" />
            Hide menu
          </button>

          {lessons.length > 0 ? (
            <div className="space-y-1">
              {lessons.map((lesson, index) => {
                const isActive = activeLessonId === lesson.id;
                const isLocked = !isEnrolled && !lesson.is_free_preview;
                
                return (
                  <button
                    key={lesson.id}
                    onClick={() => !isLocked && setActiveLessonId(lesson.id)}
                    disabled={isLocked}
                    className={cn(
                      "w-full text-left p-3 rounded-md transition-colors relative",
                      isActive && "bg-blue-50",
                      !isActive && !isLocked && "hover:bg-gray-100",
                      isLocked && "cursor-not-allowed opacity-60"
                    )}
                  >
                    {isActive && (
                      <div className="absolute left-0 top-0 bottom-0 w-1 bg-blue-600" />
                    )}
                    
                    <div className="flex items-start gap-3 pl-2">
                      <div className="flex-shrink-0 mt-1">
                        {isLocked ? (
                          <Lock className="w-5 h-5 text-gray-400" />
                        ) : lesson.content_type === 'video' ? (
                          <Video className="w-5 h-5 text-gray-400" />
                        ) : (
                          <FileText className="w-5 h-5 text-gray-400" />
                        )}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-gray-900 mb-1">
                          {getContentTypeLabel(lesson.content_type)} {index + 1} {lesson.title}
                        </p>
                        {lesson.duration_minutes && (
                          <p className="text-xs text-gray-500">{lesson.duration_minutes} min</p>
                        )}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          ) : (
            <p className="text-center text-sm text-gray-500 py-8">No lessons available yet.</p>
          )}
        </div>
      </aside>

      {/* Toggle Sidebar Button (when collapsed) */}
      {isSidebarCollapsed && (
        <button
          onClick={() => setIsSidebarCollapsed(false)}
          className="fixed left-0 top-1/2 -translate-y-1/2 bg-blue-600 text-white p-2 rounded-r-md hover:bg-blue-700 z-20"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      )}

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto bg-white">
        {/* Header */}
        <div className="bg-white border-b">
          <div className="max-w-7xl mx-auto px-6 py-4">
            <Link to={createPageUrl('EduTube')} className="inline-flex items-center text-sm text-gray-500 hover:text-orange-600 mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Courses
            </Link>
            
            <div className="flex items-start justify-between gap-6">
              <div className="flex-1">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">{course.title}</h1>
                <p className="text-gray-600 mb-4">{course.description}</p>
                
                <div className="flex items-center gap-4 mb-4">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={course.creator_avatar_url} />
                    <AvatarFallback>{course.creator_name?.charAt(0) || '?'}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold text-gray-900">{course.creator_name}</p>
                    <p className="text-sm text-gray-500">Course Creator</p>
                  </div>
                </div>

                <div className="flex items-center gap-6 text-sm">
                  <div className="flex items-center gap-2">
                    <StarRating rating={course.average_rating || 0} count={course.rating_count || 0} interactive={false} size="sm" />
                  </div>
                  <div className="flex items-center gap-1.5 text-gray-600">
                    <Users className="w-4 h-4" />
                    <span>{course.enrollment_count || 0} students</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-gray-600">
                    <Clock className="w-4 h-4" />
                    <span>{lessons.length} lessons</span>
                  </div>
                </div>
              </div>

              <div>
                {user ? (
                  isEnrolled ? (
                    <Button variant="secondary" disabled>
                      <CheckCircle className="w-4 h-4 mr-2"/> Enrolled
                    </Button>
                  ) : course.price === 0 ? (
                    <Button onClick={() => enrollMutation.mutate()} disabled={enrollMutation.isPending} className="bg-orange-500 hover:bg-orange-600">
                      {enrollMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <PlayCircle className="mr-2 h-4 w-4" />}
                      Enroll for Free
                    </Button>
                  ) : (
                    <Button asChild className="bg-orange-500 hover:bg-orange-600">
                      <Link to={createPageUrl(`Checkout?courseId=${courseId}`)}>
                        <CreditCard className="mr-2 h-4 w-4" />
                        Buy Course - ${course.price}
                      </Link>
                    </Button>
                  )
                ) : (
                  <Link to={createPageUrl('SignIn')}>
                    <Button className="bg-orange-500 hover:bg-orange-600">Sign In to Enroll</Button>
                  </Link>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto p-8">
          {activeLesson && (
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                {activeLesson.title}
              </h2>
              {activeLesson.description && (
                <p className="text-gray-600">{activeLesson.description}</p>
              )}
            </div>
          )}

          <LessonContent lesson={activeLesson} isEnrolled={isEnrolled} />

          {activeLesson?.notes && isEnrolled && (
            <div className="mt-8">
              <h3 className="text-lg font-semibold mb-3">Lesson Notes</h3>
              <div className="bg-gray-50 rounded-lg p-6 border">
                <ReactMarkdown className="prose prose-sm max-w-none">
                  {activeLesson.notes}
                </ReactMarkdown>
              </div>
            </div>
          )}

          {activeLesson?.downloads && activeLesson.downloads.length > 0 && isEnrolled && (
            <div className="mt-8">
              <h3 className="text-lg font-semibold mb-3">Downloads</h3>
              <div className="space-y-2">
                {activeLesson.downloads.map((file, index) => (
                  <a
                    key={index}
                    href={file.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    download={file.name}
                    className="flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-md transition-colors border"
                  >
                    <span className="font-medium text-gray-800">{file.name}</span>
                    <Download className="w-5 h-5 text-gray-500" />
                  </a>
                ))}
              </div>
            </div>
          )}

          {user && !hasRated && isEnrolled && (
            <div className="mt-8">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Rate This Course</CardTitle>
                </CardHeader>
                <CardContent>
                  <StarRating 
                    rating={userRating}
                    onRate={(r) => {
                      setUserRating(r);
                      ratingMutation.mutate(r);
                    }}
                    interactive={true}
                    size="lg"
                  />
                  {isSubmittingRating && (
                    <p className="text-sm text-gray-500 mt-2 flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" /> Saving...
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
