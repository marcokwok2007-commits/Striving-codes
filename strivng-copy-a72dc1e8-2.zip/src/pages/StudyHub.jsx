import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { format, startOfToday, differenceInDays } from 'date-fns';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Timer, X } from "lucide-react";
import StudyTimer from "../components/studyhub/PomodoroTimer";
import GoalsSubjects from "../components/studyhub/GoalsSubjects";
import Analytics from "../components/studyhub/Analytics";
import Groups from "../components/studyhub/Groups";
import StudyAgent from "../components/StudyAgent";
import StudySessionView from "../components/studyhub/StudySessionView";

const getStoredSession = () => {
  try {
    const saved = localStorage.getItem('activeStudySession');
    if (!saved) return { isActive: false, isFullScreen: false, goal: null, group: null, seconds: 0 };
    
    const parsed = JSON.parse(saved);
    return {
      isActive: parsed.isActive || false,
      isFullScreen: parsed.isFullScreen || false,
      goal: parsed.goal || null,
      group: parsed.group || null,
      seconds: parsed.seconds || 0
    };
  } catch {
    localStorage.removeItem('activeStudySession');
    return { isActive: false, isFullScreen: false, goal: null, group: null, seconds: 0 };
  }
};

const BackgroundTimer = React.memo(({ seconds, onExpand, onStop }) => {
    const formatTime = useMemo(() => {
        if (isNaN(seconds) || seconds < 0) return "00:00:00";
        const hours = Math.floor(seconds / 3600).toString().padStart(2, '0');
        const minutes = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
        const secs = (seconds % 60).toString().padStart(2, '0');
        return `${hours}:${minutes}:${secs}`;
    }, [seconds]);

    return (
        <div className="fixed bottom-6 right-6 z-40 bg-green-100 border-2 border-green-500 text-green-800 font-semibold px-6 py-3 rounded-xl shadow-lg flex items-center gap-3">
            <Timer className="w-6 h-6 animate-pulse" />
            <div>
                <p className="text-xs text-green-600">Study Session Active</p>
                <p className="text-lg font-mono font-bold">{formatTime}</p>
            </div>
            <div className="flex gap-2 ml-2">
                <Button size="sm" variant="outline" onClick={onExpand} className="bg-white hover:bg-gray-50">
                    Expand
                </Button>
                <Button size="sm" variant="ghost" onClick={onStop} className="hover:bg-red-50 hover:text-red-600">
                    <X className="w-4 h-4" />
                </Button>
            </div>
        </div>
    );
});

BackgroundTimer.displayName = 'BackgroundTimer';

export default function StudyHub() {
    const [activeSession, setActiveSession] = useState(getStoredSession);
    const queryClient = useQueryClient();

    const { data: dailyHours = 0 } = useQuery({
        queryKey: ['studyHubDailyHours', format(startOfToday(), 'yyyy-MM-dd')],
        queryFn: async () => {
            const user = await base44.auth.me();
            const today = format(startOfToday(), 'yyyy-MM-dd');
            const sessions = await base44.entities.StudySession.filter({
                created_by: user.email,
                session_date: today,
            });
            return sessions.reduce((sum, s) => sum + (s.duration_minutes || 0), 0);
        },
        staleTime: 60000,
        refetchOnWindowFocus: false,
    });
    
    const { data: ultimateGoal } = useQuery({
        queryKey: ['ultimateGoal'],
        queryFn: async () => {
            const user = await base44.auth.me();
            const goals = await base44.entities.Goal.filter({
                created_by: user.email,
                is_ultimate: true,
            });
            return goals[0] || null;
        },
        staleTime: 300000,
        refetchOnWindowFocus: false,
    });

    useEffect(() => {
      if (activeSession.isActive) {
        try {
          localStorage.setItem('activeStudySession', JSON.stringify(activeSession));
        } catch (error) {
          console.error('Failed to save session:', error);
        }
      } else {
        localStorage.removeItem('activeStudySession');
      }
    }, [activeSession]);

    useEffect(() => {
        if (!activeSession.isActive) return;
        
        const interval = setInterval(() => {
            setActiveSession(prev => ({ ...prev, seconds: prev.seconds + 1 }));
        }, 1000);
        
        return () => clearInterval(interval);
    }, [activeSession.isActive]);

    const updateStatusMutation = useMutation({
        mutationFn: (status) => base44.auth.updateMe(status),
        onSuccess: () => queryClient.invalidateQueries({ queryKey: ['studyingMembers'] })
    });

    const createSessionMutation = useMutation({
        mutationFn: (sessionData) => base44.entities.StudySession.create(sessionData),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['studySessions'] });
            queryClient.invalidateQueries({ queryKey: ['studyHubDailyHours'] });
        }
    });

    const handleStartSession = useCallback((goal, group = null) => {
        setActiveSession({ isActive: true, isFullScreen: true, goal, group, seconds: 0 });
        updateStatusMutation.mutate({
            study_status: 'studying',
            current_session_start: new Date().toISOString(),
            current_goal_title: goal.title
        });
    }, [updateStatusMutation]);

    const handleStopSession = useCallback(() => {
        const durationMinutes = Math.floor(activeSession.seconds / 60);
        if (durationMinutes > 0 && activeSession.goal) {
            createSessionMutation.mutate({
                goal_id: activeSession.goal.id,
                goal_title: activeSession.goal.title,
                subject: activeSession.goal.subject || "General",
                session_date: format(new Date(), 'yyyy-MM-dd'),
                duration_minutes: durationMinutes,
            });
        }
        setActiveSession({ isActive: false, isFullScreen: false, goal: null, group: null, seconds: 0 });
        updateStatusMutation.mutate({ 
          study_status: 'online', 
          current_session_start: null, 
          current_goal_title: null 
        });
    }, [activeSession.seconds, activeSession.goal, createSessionMutation, updateStatusMutation]);

    const handleExitFullScreen = useCallback(() => {
        setActiveSession(prev => ({ ...prev, isFullScreen: false }));
    }, []);

    const handleEnterFullScreen = useCallback(() => {
        setActiveSession(prev => ({ ...prev, isFullScreen: true }));
    }, []);

    const handleGroupChange = useCallback((newGroup) => {
        setActiveSession(prev => ({ ...prev, group: newGroup }));
    }, []);

    const daysLeft = useMemo(() => {
        if (!ultimateGoal?.target_date) return null;
        return differenceInDays(new Date(ultimateGoal.target_date), new Date());
    }, [ultimateGoal?.target_date]);

    if (activeSession.isFullScreen) {
        return <StudySessionView 
                    goal={activeSession.goal} 
                    group={activeSession.group}
                    onStopSession={handleStopSession} 
                    onExit={handleExitFullScreen}
                    initialSeconds={activeSession.seconds}
                    onGroupChange={handleGroupChange}
                />;
    }

  return (
    <div className="p-6 md:p-8 bg-orange-50/20 min-h-full">
      <div className="max-w-7xl mx-auto">
        {activeSession.isActive && !activeSession.isFullScreen && (
          <BackgroundTimer 
            seconds={activeSession.seconds} 
            onExpand={handleEnterFullScreen}
            onStop={handleStopSession}
          />
        )}

        {ultimateGoal && (
          <div className="mb-6 text-center md:text-left bg-white rounded-lg p-4 shadow-sm">
            <p className="font-semibold text-gray-800 text-lg mb-1">{ultimateGoal.title}</p>
            {daysLeft !== null && daysLeft >= 0 ? (
              <p className="text-gray-600">
                <span className="font-bold text-3xl text-orange-600">{daysLeft}</span> days left
              </p>
            ) : (
              <p className="text-sm text-red-600">This goal is past its due date.</p>
            )}
          </div>
        )}

        <Tabs defaultValue="timer" className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 mb-8 bg-gray-100 p-1 rounded-lg">
            <TabsTrigger value="timer" className="rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-orange-600">
              Timer
            </TabsTrigger>
            <TabsTrigger value="goals" className="rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-orange-600">
              Goals
            </TabsTrigger>
            <TabsTrigger value="analytics" className="rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-orange-600">
              Analytics
            </TabsTrigger>
            <TabsTrigger value="groups" className="rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-orange-600">
              Groups
            </TabsTrigger>
          </TabsList>

          <TabsContent value="timer">
            <StudyTimer onStartSession={handleStartSession} dailyHours={dailyHours} />
          </TabsContent>
          <TabsContent value="goals">
            <GoalsSubjects />
          </TabsContent>
          <TabsContent value="analytics">
            <Analytics />
          </TabsContent>
          <TabsContent value="groups">
            <Groups />
          </TabsContent>
        </Tabs>
      </div>
      <StudyAgent />
    </div>
  );
}