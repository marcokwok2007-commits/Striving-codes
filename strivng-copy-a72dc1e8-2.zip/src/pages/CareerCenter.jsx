
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Search, Settings, ExternalLink, ThumbsUp, ThumbsDown } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import PreferenceEditor from "../components/career/PreferenceEditor";
import StudyAgent from "../components/StudyAgent";
import { toast } from "sonner";

const OpportunityCard = ({ opportunity }) => {
  return (
    <Card className="hover:shadow-lg transition-shadow h-full flex flex-col">
      <CardContent className="p-6 flex flex-col h-full">
        <div className="flex justify-between items-start gap-3 mb-4">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-red-600 mb-1">{opportunity.title}</h3>
            <p className="text-sm text-gray-600">{opportunity.organization || opportunity.company}</p>
          </div>
          {opportunity.category && (
            <span className="bg-orange-100 text-orange-800 px-2 py-1 rounded text-xs whitespace-nowrap">
              {opportunity.category}
            </span>
          )}
        </div>
        
        <p className="text-gray-700 text-sm mb-4">{opportunity.description}</p>
        
        {opportunity.pros && opportunity.pros.length > 0 && (
          <div className="mb-3">
            <h4 className="font-semibold text-green-700 mb-2 flex items-center gap-2 text-sm">
              <ThumbsUp className="w-4 h-4" /> Pros
            </h4>
            <ul className="list-disc list-inside space-y-1 text-sm text-gray-600">
              {opportunity.pros.map((pro, idx) => (
                <li key={idx}>{pro}</li>
              ))}
            </ul>
          </div>
        )}

        {opportunity.cons && opportunity.cons.length > 0 && (
          <div className="mb-4">
            <h4 className="font-semibold text-red-700 mb-2 flex items-center gap-2 text-sm">
              <ThumbsDown className="w-4 h-4" /> Cons
            </h4>
            <ul className="list-disc list-inside space-y-1 text-sm text-gray-600">
              {opportunity.cons.map((con, idx) => (
                <li key={idx}>{con}</li>
              ))}
            </ul>
          </div>
        )}

        <div className="mt-auto">
          {opportunity.url ? (
            <a href={opportunity.url} target="_blank" rel="noopener noreferrer">
              <Button className="w-full bg-orange-500 hover:bg-orange-600">
                Learn More <ExternalLink className="w-4 h-4 ml-2" />
              </Button>
            </a>
          ) : (
            <Button className="w-full bg-orange-500 hover:bg-orange-600" disabled>
              Learn More
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default function CareerCenter() {
  const [isPreferenceOpen, setIsPreferenceOpen] = useState(false);
  const [opportunities, setOpportunities] = useState([]);
  const [specificRequest, setSpecificRequest] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const userPreferences = user?.career_preferences || {
    disciplines: '',
    locations: '',
    types: []
  };

  const performSearch = async () => {
    setIsSearching(true);
    setOpportunities([]);
    
    try {
      const currentDate = new Date();
      const threeMonthsLater = new Date(currentDate);
      threeMonthsLater.setMonth(currentDate.getMonth() + 3);
      
      let searchQuery = '';
      
      if (userPreferences.types && userPreferences.types.length > 0) {
        const typesLowercase = userPreferences.types.map(t => t.toLowerCase());
        searchQuery += `STRICTLY ${typesLowercase.join(' OR ')} ONLY `;
      } else {
        searchQuery += 'career opportunities ';
      }
      
      if (userPreferences.disciplines && userPreferences.disciplines.trim()) {
        searchQuery += `in ${userPreferences.disciplines} `;
      }
      
      if (userPreferences.locations && userPreferences.locations.trim()) {
        searchQuery += `located in ${userPreferences.locations} `;
      }
      
      if (specificRequest.trim()) {
        searchQuery += specificRequest.trim();
      }
      
      if (!searchQuery.trim()) {
        searchQuery = 'entry level opportunities for students';
      }
      
      let typeRequirements = '';
      if (userPreferences.types && userPreferences.types.length > 0) {
        const typesLowercase = userPreferences.types.map(t => t.toLowerCase());
        typeRequirements = `
CRITICAL TYPE REQUIREMENTS - THIS IS MANDATORY:
- ONLY include opportunities that are EXACTLY: ${typesLowercase.join(' OR ')}
- DO NOT include any other types
- Every result MUST match one of these types: ${typesLowercase.join(', ')}
- category field MUST be one of: ${typesLowercase.join(', ')}
`;
      }
      
      const prompt = `Search for career opportunities matching these STRICT requirements:

${typeRequirements}

Search Query: "${searchQuery}"
Current date: ${currentDate.toLocaleDateString()}
Deadline: Within 3 months (by ${threeMonthsLater.toLocaleDateString()})

MANDATORY FILTERING RULES:
${userPreferences.types && userPreferences.types.length > 0 ? `
1. TYPE FILTER (MOST IMPORTANT): 
   - ONLY return opportunities of type: ${userPreferences.types.join(', ')}
   - REJECT any opportunity that doesn't match these exact types
   - category must be EXACTLY one of: ${userPreferences.types.join(', ')}
` : ''}
${userPreferences.disciplines ? `2. DISCIPLINE FILTER: Must be related to ${userPreferences.disciplines}` : ''}
${userPreferences.locations ? `3. LOCATION FILTER: Must be in ${userPreferences.locations}` : ''}
${specificRequest ? `4. ADDITIONAL REQUIREMENTS: ${specificRequest}` : ''}

Find 8-10 REAL opportunities that match ALL the above criteria.

For each opportunity provide:
- title: Exact title from posting
- organization or company: Official organization name
- description: Brief 2-3 sentence description
- category: MUST be one of the filtered types (${userPreferences.types.length > 0 ? userPreferences.types.join(', ') : 'Job, Internship, Scholarship, Competition'})
- deadline: Application deadline or "Rolling"
- pros: 2-3 specific benefits
- cons: 1-2 considerations
- url: Direct application link

CRITICAL: Type matching is the #1 priority.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            opportunities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  organization: { type: "string" },
                  company: { type: "string" },
                  description: { type: "string" },
                  category: { type: "string" },
                  deadline: { type: "string" },
                  pros: { 
                    type: "array", 
                    items: { type: "string" }
                  },
                  cons: { 
                    type: "array", 
                    items: { type: "string" }
                  },
                  url: { type: "string" }
                },
                required: ["title", "description", "category", "url"]
              }
            }
          }
        }
      });

      if (result && result.opportunities && result.opportunities.length > 0) {
        let filteredOpportunities = result.opportunities;
        
        if (userPreferences.types && userPreferences.types.length > 0) {
          const typesLowercase = userPreferences.types.map(t => t.toLowerCase());
          filteredOpportunities = result.opportunities.filter(opp => {
            const category = opp.category.toLowerCase();
            return typesLowercase.some(type => category.includes(type));
          });
        }
        
        if (filteredOpportunities.length > 0) {
          setOpportunities(filteredOpportunities);
          toast.success(`Found ${filteredOpportunities.length} opportunities!`);
        } else {
          setOpportunities([]);
          toast.error("No opportunities found matching your exact preferences.");
        }
      } else {
        setOpportunities([]);
        toast.error("No opportunities found. Try adjusting your preferences.");
      }
    } catch (error) {
      toast.error("Search failed. Please try again.");
      setOpportunities([]);
    } finally {
      setIsSearching(false);
    }
  };

  const handleSavePreferences = async (newPrefs) => {
    await base44.auth.updateMe({ career_preferences: newPrefs });
    queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    setIsPreferenceOpen(false);
  };

  return (
    <div className="p-6 md:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          {userPreferences.disciplines || userPreferences.locations || userPreferences.types?.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {userPreferences.disciplines && (
                <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                  {userPreferences.disciplines}
                </span>
              )}
              {userPreferences.locations && (
                <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
                  {userPreferences.locations}
                </span>
              )}
              {userPreferences.types?.length > 0 && (
                <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm">
                  {userPreferences.types.join(', ')}
                </span>
              )}
            </div>
          ) : (
            <p className="text-sm text-gray-500">Set your preferences to get personalized opportunities</p>
          )}
        </div>

        <Card className="mb-8">
          <CardContent className="p-6">
            <Input 
              placeholder="Add specific requirements (e.g., 'remote work', 'software engineering')..."
              value={specificRequest}
              onChange={(e) => setSpecificRequest(e.target.value)}
              className="mb-4"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !isSearching) {
                  performSearch();
                }
              }}
            />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Button 
                onClick={performSearch} 
                disabled={isSearching}
                className="bg-black hover:bg-gray-800 text-white"
              >
                {isSearching ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Searching...</>
                ) : (
                  <><Search className="w-4 h-4 mr-2" /> Search Opportunities</>
                )}
              </Button>
              
              <Dialog open={isPreferenceOpen} onOpenChange={setIsPreferenceOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    <Settings className="w-4 h-4 mr-2" />
                    Edit Preferences
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Career Preferences</DialogTitle>
                  </DialogHeader>
                  <PreferenceEditor 
                    initialPreferences={userPreferences} 
                    onSave={handleSavePreferences}
                    onCancel={() => setIsPreferenceOpen(false)}
                  />
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>

        {isSearching && (
          <div className="text-center py-16">
            <Loader2 className="mx-auto h-12 w-12 text-orange-500 animate-spin mb-4" />
            <p className="text-gray-600 font-semibold">Searching for opportunities...</p>
            <p className="text-gray-500 text-sm mt-2">This may take 30-45 seconds. Please wait...</p>
          </div>
        )}

        {!isSearching && opportunities.length === 0 && (
          <div className="text-center py-16">
            <Search className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-xl font-semibold text-gray-700">Ready to Search</h3>
            <p className="text-gray-500 mt-2">Click "Search Opportunities" to find career options matching your preferences.</p>
          </div>
        )}

        {opportunities.length > 0 && (
          <>
            <div className="mb-6 text-center">
              <p className="text-lg font-semibold text-gray-700">
                Found {opportunities.length} opportunities
              </p>
              <p className="text-sm text-gray-500 mt-1">Matching your preferences and criteria</p>
            </div>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {opportunities.map((opportunity, index) => (
                <OpportunityCard key={index} opportunity={opportunity} />
              ))}
            </div>
          </>
        )}
      </div>
      <StudyAgent />
    </div>
  );
}
