
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { LogOut, Bell, Lock, Globe, Trash2, DatabaseZap, CreditCard, Users, CheckCircle2, Zap, Crown } from "lucide-react";
import StudyAgent from "../components/StudyAgent";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner"; // Assuming sonner is used for toasts, common in shadcn/ui projects.

const ClearDataDialog = ({ triggerText, description, onConfirm, isClearing }) => {
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button variant="destructive" size="sm" className="w-full justify-start text-left">
          <Trash2 className="w-4 h-4 mr-2" />
          {triggerText}
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
          <AlertDialogDescription>{description}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={onConfirm} disabled={isClearing}>
            {isClearing ? "Clearing..." : "Continue"}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default function Settings() {
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
    staleTime: Infinity,
    refetchOnWindowFocus: false,
  });

  const { data: subscription } = useQuery({
    queryKey: ['userSubscription', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const subs = await base44.entities.Subscription.filter({ user_email: user.email, status: 'active' });
      return subs[0] || null;
    },
    enabled: !!user?.email,
    select: (data) => data,
    staleTime: 60000,
    refetchOnWindowFocus: false,
  });


  const updateUserMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    },
  });

  const handleLogout = () => {
    base44.auth.logout();
  };
  
  const useClearDataMutation = (entityName, queryKeys) => {
    return useMutation({
      mutationFn: async () => {
        const records = await base44.entities[entityName].list();
        const deletePromises = records.map(record => base44.entities[entityName].delete(record.id));
        await Promise.all(deletePromises);
      },
      onSuccess: () => {
        queryKeys.forEach(key => queryClient.invalidateQueries({ queryKey: [key] }));
      },
    });
  };

  const clearStudySessionsMutation = useClearDataMutation("StudySession", ["studySessions"]);
  const clearGoalsMutation = useClearDataMutation("Goal", ["goals"]);
  const clearGroupsMutation = useClearDataMutation("StudyGroup", ["studyGroups"]);
  const clearDecksMutation = useClearDataMutation("Deck", ["decks"]);

  // New mutation for clearing AI conversation history
  const clearConversationsMutation = useMutation({
    mutationFn: async () => {
      // Clear conversations by invalidating the cache
      queryClient.invalidateQueries({ queryKey: ['conversationHistory'] });
      // Note: Actual server-side deletion is not available via API
      // This clears the local cache and the UI will show fresh data
    },
    onSuccess: () => {
      toast.success('AI conversation history cleared from display');
    }
  });

  const handleCreatorModeToggle = (checked) => {
    updateUserMutation.mutate({ creator_mode: checked });
  };

  const subscriptionPlans = [
    {
      name: 'Free',
      price: '$0',
      period: 'forever',
      features: [
        '10 AI-generated decks per month',
        'Basic flashcards & quiz mode',
        'Join up to 3 study groups',
        'Access to EduTube courses',
        'Basic calendar & goals'
      ],
      current: user?.subscription_plan === 'free' || !user?.subscription_plan,
      cta: 'Current Plan',
      variant: 'outline',
      planKey: 'free'
    },
    {
      name: 'Pro',
      price: '$9.99',
      period: 'per month',
      features: [
        'Unlimited AI-generated decks',
        'Advanced spaced repetition',
        'AI study notes generation',
        'Unlimited study groups',
        'Priority AI processing',
        'Collaborative deck editing',
        'Advanced analytics',
        'Export decks to PDF'
      ],
      badge: 'Popular',
      current: user?.subscription_plan === 'pro',
      cta: user?.subscription_plan === 'pro' ? 'Current Plan' : 'Upgrade to Pro',
      variant: user?.subscription_plan === 'pro' ? 'outline' : 'default',
      icon: Zap,
      planKey: 'pro'
    },
    {
      name: 'Premium',
      price: '$19.99',
      period: 'per month',
      features: [
        'Everything in Pro',
        '1-on-1 AI tutor sessions',
        'Custom AI study plans',
        'Career guidance & mentoring',
        'Exclusive course content',
        'Early access to features',
        'Custom deck templates',
        'API access'
      ],
      badge: 'Best Value',
      current: user?.subscription_plan === 'premium',
      cta: user?.subscription_plan === 'premium' ? 'Current Plan' : 'Upgrade to Premium',
      variant: user?.subscription_plan === 'premium' ? 'outline' : 'default',
      icon: Crown,
      planKey: 'premium'
    }
  ];

  return (
    <div className="p-6 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-orange-600"><Globe className="w-5 h-5" />General</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-2">
                    <Label htmlFor="language">Language</Label>
                    <Select defaultValue="en">
                        <SelectTrigger id="language">
                            <SelectValue placeholder="Select language" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="en">English</SelectItem>
                            <SelectItem value="es" disabled>Español (coming soon)</SelectItem>
                            <SelectItem value="fr" disabled>Français (coming soon)</SelectItem>
                        </SelectContent>
                    </Select>
                    <p className="text-sm text-gray-500">Change the display language of the app.</p>
                </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-orange-600"><Users className="w-5 h-5" />Creator Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-3">
                <Switch 
                  id="creator-mode" 
                  checked={user?.creator_mode || false}
                  onCheckedChange={handleCreatorModeToggle}
                  disabled={updateUserMutation.isPending}
                />
                <div>
                  <Label htmlFor="creator-mode" className="font-semibold">Creator Mode</Label>
                  <p className="text-sm text-gray-500">Enable to access course creation and publishing tools</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-orange-600"><CreditCard className="w-5 h-5" />Subscription Plans</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {subscription && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-semibold text-gray-800">
                        Active Subscription: {subscription.plan.charAt(0).toUpperCase() + subscription.plan.slice(1)}
                      </p>
                      <p className="text-sm text-gray-600">
                        {subscription.cancel_at_period_end 
                          ? `Cancels on ${new Date(subscription.current_period_end).toLocaleDateString()}`
                          : `Renews on ${new Date(subscription.current_period_end).toLocaleDateString()}`
                        }
                      </p>
                    </div>
                    <Button variant="outline" size="sm">
                      Manage Subscription
                    </Button>
                  </div>
                </div>
              )}

              <div className="grid md:grid-cols-3 gap-6">
                {subscriptionPlans.map((plan) => (
                  <Card key={plan.name} className={`relative ${plan.current ? 'border-orange-500 border-2' : ''}`}>
                    {plan.badge && !plan.current && (
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                        <Badge className="bg-orange-500">{plan.badge}</Badge>
                      </div>
                    )}
                    {plan.current && (
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                        <Badge className="bg-green-500">Active</Badge>
                      </div>
                    )}
                    <CardHeader className="text-center pb-4">
                      {plan.icon && <plan.icon className="w-8 h-8 mx-auto mb-2 text-orange-500" />}
                      <h3 className="text-xl font-bold">{plan.name}</h3>
                      <div className="mt-2">
                        <span className="text-3xl font-bold">{plan.price}</span>
                        <span className="text-gray-500 text-sm">/{plan.period}</span>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <ul className="space-y-2">
                        {plan.features.map((feature, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm">
                            <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                      {!plan.current ? (
                        <Button 
                          className="w-full" 
                          variant={plan.variant}
                          asChild
                        >
                          <Link to={createPageUrl(`Checkout?plan=${plan.planKey}`)}>
                            {plan.cta}
                          </Link>
                        </Button>
                      ) : (
                        <Button 
                          className="w-full" 
                          variant="outline"
                          disabled
                        >
                          {plan.cta}
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
              <div className="text-center text-sm text-gray-500 pt-4">
                <p>All plans include: Secure data storage, Mobile app access, Email support</p>
                <p className="mt-2">Need a custom plan? <a href="mailto:support@striving.app" className="text-orange-600 hover:underline">Contact us</a></p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-red-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-600">
                <DatabaseZap className="w-5 h-5" />
                Data Management
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-gray-600 mb-4">
                Permanently delete data from your account. This action cannot be undone.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <ClearDataDialog
                  triggerText="Clear Study History"
                  description="This will permanently delete all your study sessions and analytics data."
                  onConfirm={clearStudySessionsMutation.mutateAsync}
                  isClearing={clearStudySessionsMutation.isPending}
                />
                <ClearDataDialog
                  triggerText="Clear Goals"
                  description="This will permanently delete all your study goals."
                  onConfirm={clearGoalsMutation.mutateAsync}
                  isClearing={clearGoalsMutation.isPending}
                />
                <ClearDataDialog
                  triggerText="Clear Study Groups"
                  description="This will permanently delete all your study groups."
                  onConfirm={clearGroupsMutation.mutateAsync}
                  isClearing={clearGroupsMutation.isPending}
                />
                <ClearDataDialog
                  triggerText="Clear AI Decks"
                  description="This will permanently delete all your AI-generated study decks."
                  onConfirm={clearDecksMutation.mutateAsync}
                  isClearing={clearDecksMutation.isPending}
                />
                <ClearDataDialog
                  triggerText="Clear AI Chat History"
                  description="This will clear your Strive AI conversation history from display. Note: Conversations older than 30 days are automatically hidden to optimize performance."
                  onConfirm={clearConversationsMutation.mutateAsync}
                  isClearing={clearConversationsMutation.isPending}
                />
              </div>
              <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                <p className="text-xs text-blue-800">
                  💡 <strong>Tip:</strong> Your Strive AI chat history is automatically managed - only conversations from the last 30 days are shown to keep things fast and organized.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-orange-600">Account Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <Button
                onClick={handleLogout}
                variant="outline"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Log Out
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
      <StudyAgent />
    </div>
  );
}
