// This page has been merged into pages/Create.js
// Redirecting to Create page...

import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function CreatorDashboard() {
  const navigate = useNavigate();
  
  useEffect(() => {
    navigate(createPageUrl('Create'), { replace: true });
  }, [navigate]);
  
  return null;
}