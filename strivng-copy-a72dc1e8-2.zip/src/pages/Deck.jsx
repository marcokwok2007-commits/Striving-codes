
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, Loader2, Trash2, Eye, Lightbulb, Map, FileText, Share2, MessageSquare, Layers, Upload, FileUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import StudyAgent from "../components/StudyAgent";
import ViewDeckDialog from "../components/deck/ViewDeckDialog";

const CreateDeckDialog = ({ onDeckCreated }) => {
  const [topic, setTopic] = useState("");
  const [file, setFile] = useState(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState("topic");
  const queryClient = useQueryClient();

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);

    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      const fileExtension = droppedFile.name.split('.').pop().toLowerCase();
      if (['pdf', 'txt', 'doc', 'docx'].includes(fileExtension)) {
        setFile(droppedFile);
      } else {
        toast.error("Please upload a PDF, TXT, DOC, or DOCX file");
      }
    }
  };

  const handleFileSelect = (e) => {
    if (e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleGenerate = async () => {
    const isTopicMode = activeTab === "topic";
    const isFileMode = activeTab === "file";

    if (isTopicMode && !topic.trim()) {
      toast.error("Please enter a topic");
      return;
    }

    if (isFileMode && !file) {
      toast.error("Please upload a file");
      return;
    }

    setIsGenerating(true);
    let fileUrl = null;
    let deckTitle = "";

    try {
      if (isFileMode && file) {
        toast.info("Uploading file...");
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        fileUrl = file_url;
        deckTitle = file.name.replace(/\.[^/.]+$/, "");
      } else {
        deckTitle = topic.trim().substring(0, 50);
      }

      toast.info("Generating flashcards and summary...");

      const flashcardsPrompt = `Generate comprehensive study materials for: "${deckTitle}". ${topic ? `Topic: ${topic}` : ""}

Create EXACTLY this JSON structure with HIGH-QUALITY quiz content:

{
  "flashcards": {
    "cards": [
      {
        "front": "Question 1",
        "back": "Correct Answer 1",
        "distractors": ["Similar Wrong Answer 1", "Similar Wrong Answer 2", "Similar Wrong Answer 3"]
      },
      {
        "front": "Question 2",
        "back": "Correct Answer 2",
        "distractors": ["Plausible Wrong Answer 1", "Plausible Wrong Answer 2", "Plausible Wrong Answer 3"]
      }
    ]
  },
  "summary": {
    "summary": "A comprehensive summary..."
  }
}

CRITICAL REQUIREMENTS for flashcards:
- Generate AS MANY flashcards as needed to THOROUGHLY cover the entire topic/content
- For simple topics: aim for 10-15 cards minimum
- For complex topics or long documents: create 20-40+ cards to cover all concepts comprehensively
- Cover ALL major concepts, definitions, facts, dates, people, events, formulas, and processes
- Each question should be clear and specific
- The correct answer should be concise and accurate
- DISTRACTORS MUST be:
  * Plausible and realistic (not obviously wrong)
  * Similar in format and length to the correct answer
  * Related to the topic but factually incorrect
  * Common misconceptions or related concepts
  * For example, if correct answer is "1914", distractors could be "1913", "1916", "1918" (nearby years)
  * For example, if correct answer is "Mitochondria", distractors could be "Chloroplast", "Ribosome", "Nucleus" (other organelles)

For the summary:
- Write 4-6 comprehensive paragraphs
- Cover ALL main concepts and key details from the topic/file
- Use clear, educational language
- Organize logically with proper flow

Return ONLY the JSON structure above.`;

      const flashcardsResponse = await base44.integrations.Core.InvokeLLM({
        prompt: flashcardsPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            flashcards: {
              type: "object",
              properties: {
                cards: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      front: { type: "string" },
                      back: { type: "string" },
                      distractors: {
                        type: "array",
                        items: { type: "string" }
                      }
                    },
                    required: ["front", "back", "distractors"]
                  }
                }
              },
              required: ["cards"]
            },
            summary: {
              type: "object",
              properties: {
                summary: { type: "string" }
              },
              required: ["summary"]
            }
          },
          required: ["flashcards", "summary"]
        },
        file_urls: fileUrl ? [fileUrl] : undefined
      });

      toast.info("Generating mind map...");

      const mindmapPrompt = `Create an EDUCATIONAL and STRUCTURED mind map for: "${deckTitle}". ${topic ? `Topic: ${topic}` : ""}
${fileUrl ? `
IMPORTANT: This mind map is being created from an uploaded file. When referencing specific concepts, examples, or details, INCLUDE the page number from the source file where this information can be found using the "page_reference" field.` : ""}

Generate a comprehensive tree structure organized by EDUCATIONAL CATEGORIES (not just random topics).

Return EXACTLY this JSON structure:
{
  "root": {
    "topic": "Main Topic Name",
    "children": [
      {
        "topic": "Definition & Core Concepts",
        "children": [
          {"topic": "What is it?", "page_reference": "5"},
          {"topic": "Key terminology", "page_reference": "6-7"},
          {"topic": "Fundamental principles", "page_reference": "8"}
        ]
      },
      {
        "topic": "Examples & Applications",
        "children": [
          {"topic": "Real-world example 1", "page_reference": "12"},
          {"topic": "Real-world example 2", "page_reference": "15"},
          {"topic": "Practical applications", "page_reference": "18-20"}
        ]
      },
      {
        "topic": "Mechanism & Process",
        "children": [
          {"topic": "How it works - Step 1", "page_reference": "23"},
          {"topic": "How it works - Step 2", "page_reference": "24"},
          {"topic": "Key mechanisms", "page_reference": "25-27"}
        ]
      },
      {
        "topic": "Important Facts & Details",
        "children": [
          {"topic": "Key dates/figures", "page_reference": "30"},
          {"topic": "Important people", "page_reference": "31"},
          {"topic": "Critical facts", "page_reference": "32-33"}
        ]
      }
    ]
  }
}

CRITICAL REQUIREMENTS:
- Structure the mind map into LOGICAL EDUCATIONAL SECTIONS such as:
  * "Definition & Core Concepts" - what it is, basic understanding
  * "Examples & Applications" - real-world cases, use cases
  * "Mechanism & Process" - how it works, step-by-step
  * "Important Facts & Details" - dates, people, numbers, formulas
  * "Causes & Effects" - for historical/scientific topics
  * "Advantages & Disadvantages" - pros and cons
  * "Related Concepts" - connections to other topics
  * Choose 4-7 categories that best fit the topic

- Each category should have 3-6 specific points
- Aim for 25-40 total nodes to thoroughly cover the topic
- Make it pedagogically structured, not just a random hierarchy
- Focus on helping students UNDERSTAND and LEARN the material
${fileUrl ? `
- MANDATORY: Include page_reference field for EVERY leaf node (third level) with the actual page number(s) from the source file where that information is found
- Format page references as: "5", "6-7", "12", "15-18", etc.
- If a concept spans multiple pages, use range format like "10-12"
- Only the leaf nodes (deepest level children) need page references, not the category titles` : ""}

Return ONLY the JSON structure.`;

      const mindmapResponse = await base44.integrations.Core.InvokeLLM({
        prompt: mindmapPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            root: {
              type: "object",
              properties: {
                topic: { type: "string" },
                children: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      topic: { type: "string" },
                      children: {
                        type: "array",
                        items: {
                          type: "object",
                          properties: {
                            topic: { type: "string" },
                            page_reference: { type: "string" }
                          },
                          required: ["topic"]
                        }
                      }
                    },
                    required: ["topic", "children"]
                  }
                }
              },
              required: ["topic", "children"]
            }
          },
          required: ["root"]
        },
        file_urls: fileUrl ? [fileUrl] : undefined
      });

      if (mindmapResponse.root.children) {
        mindmapResponse.root.children = mindmapResponse.root.children.map(child => ({
          ...child,
          children: child.children?.map(leaf => ({
            ...leaf,
            children: []
          })) || []
        }));
      }

      await base44.entities.Deck.create({
        title: deckTitle,
        flashcards: flashcardsResponse.flashcards,
        mindmap: mindmapResponse,
        summary: flashcardsResponse.summary,
        source_file_url: fileUrl || null
      });

      queryClient.invalidateQueries({ queryKey: ['decks'] });
      setIsGenerating(false);
      setTopic("");
      setFile(null);

      toast.success(`Deck "${deckTitle}" created successfully! 🎉`, {
        duration: 5000,
      });

      onDeckCreated();
    } catch (error) {
      console.error("Error generating deck:", error);
      toast.error("Failed to generate deck. Please try again.");
      setIsGenerating(false);
    }
  };

  return (
    <DialogContent className="sm:max-w-[600px] backdrop-blur-2xl bg-white/80 border-white/20 shadow-2xl max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle>Create New Deck</DialogTitle>
      </DialogHeader>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="topic">From Topic</TabsTrigger>
          <TabsTrigger value="file">From File</TabsTrigger>
        </TabsList>

        <TabsContent value="topic" className="space-y-4 mt-4">
          <div>
            <Label>Topic or Subject</Label>
            <Textarea
              placeholder="e.g., World War II History, Calculus Derivatives, Spanish Vocabulary..."
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="h-32 mt-2"
              disabled={isGenerating}
            />
            <p className="text-xs text-gray-500 mt-2">Describe what you want to study. Be specific for better results.</p>
          </div>
        </TabsContent>

        <TabsContent value="file" className="space-y-4 mt-4">
          <div>
            <Label>Upload Study Material</Label>
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`mt-2 border-2 border-dashed rounded-lg p-8 transition-colors ${
                isDragging
                  ? 'border-orange-500 bg-orange-50'
                  : 'border-gray-300 hover:border-gray-400'
              } ${isGenerating ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
              onClick={() => !isGenerating && document.getElementById('file-upload').click()}
            >
              <div className="flex flex-col items-center justify-center text-center">
                {file ? (
                  <>
                    <FileUp className="w-12 h-12 text-green-500 mb-3" />
                    <p className="font-medium text-gray-700">{file.name}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="mt-3"
                      onClick={(e) => {
                        e.stopPropagation();
                        setFile(null);
                      }}
                      disabled={isGenerating}
                    >
                      Remove file
                    </Button>
                  </>
                ) : (
                  <>
                    <Upload className="w-12 h-12 text-gray-400 mb-3" />
                    <p className="font-medium text-gray-700 mb-1">
                      Drop your file here or click to browse
                    </p>
                    <p className="text-xs text-gray-500">
                      Supports PDF, TXT, DOC, and DOCX files
                    </p>
                  </>
                )}
              </div>
              <input
                id="file-upload"
                type="file"
                className="hidden"
                accept=".pdf,.txt,.doc,.docx"
                onChange={handleFileSelect}
                disabled={isGenerating}
              />
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {isGenerating && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-800">
          <Loader2 className="w-4 h-4 inline mr-2 animate-spin" />
          Generating comprehensive study materials... This may take 60-120 seconds for thorough coverage.
        </div>
      )}

      <DialogFooter>
        <Button onClick={handleGenerate} disabled={isGenerating} className="w-full">
          {isGenerating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating...
            </>
          ) : (
            "Generate Deck"
          )}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
};

const ShareToGroupDialog = ({ deck, onClose }) => {
  const { data: user } = useQuery({ queryKey: ['currentUser'], queryFn: () => base44.auth.me() });
  const { data: groups } = useQuery({
    queryKey: ['myGroups'],
    queryFn: async () => {
      if (!user?.email) return [];
      return base44.entities.StudyGroup.filter({ members: { $in: [user.email] } });
    },
    enabled: !!user
  });

  const shareMutation = useMutation({
    mutationFn: (groupId) => base44.entities.SharedResource.create({
      group_id: groupId,
      resource_id: deck.id,
      resource_type: 'deck',
      resource_title: deck.title,
      shared_by_name: user.full_name || user.email
    }),
    onSuccess: (data, groupId) => {
      const sharedGroup = groups?.find(g => g.id === groupId);
      toast.success(`Shared "${deck.title}" to ${sharedGroup?.name || 'group'}!`);
      onClose();
    },
    onError: () => {
      toast.error('Failed to share deck. Please try again.');
    }
  });

  return (
    <DialogContent className="backdrop-blur-2xl bg-white/80 border-white/20 shadow-2xl">
      <DialogHeader><DialogTitle>Share "{deck.title}" to Group</DialogTitle></DialogHeader>
      <div className="space-y-2">
        {groups?.length === 0 ? (
          <p className="text-gray-500 text-sm">You're not in any groups yet. Join or create a group to share.</p>
        ) : (
          groups?.map(group => (
            <Button
              key={group.id}
              variant="outline"
              className="w-full justify-start"
              onClick={() => shareMutation.mutate(group.id)}
              disabled={shareMutation.isPending}
            >
              {shareMutation.isPending ? 'Sharing...' : group.name}
            </Button>
          ))
        )}
      </div>
    </DialogContent>
  );
};

export default function DeckPage() {
  const [isCreateOpen, setCreateOpen] = useState(false);
  const [selectedDeckForStrive, setSelectedDeckForStrive] = useState(null);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
    staleTime: Infinity,
    refetchOnWindowFocus: false,
  });

  const { data: decks = [], isLoading, error } = useQuery({
    queryKey: ['decks'],
    queryFn: async () => {
      const user = await base44.auth.me();
      const results = await base44.entities.Deck.filter({ created_by: user.email });
      return Array.isArray(results) ? results : [];
    },
    staleTime: 30000,
    refetchOnWindowFocus: false,
    retry: 3,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Deck.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['decks'] });
      toast.success('Deck deleted successfully!');
    },
    onError: (error) => {
      toast.error('Failed to delete deck: ' + error.message);
    }
  });

  const handleDeleteDeck = (deckId) => {
    deleteMutation.mutate(deckId);
  };

  if (error) {
    return (
      <div className="p-4 md:p-6 lg:p-8 bg-gray-50 min-h-screen">
        <div className="max-w-7xl mx-auto">
          <Card className="border-red-200 bg-red-50">
            <CardContent className="py-12 text-center">
              <p className="text-red-600 font-semibold mb-2">Failed to load decks</p>
              <p className="text-sm text-gray-600 mb-4">{error.message}</p>
              <Button onClick={() => queryClient.invalidateQueries({ queryKey: ['decks'] })}>
                Try Again
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {isLoading && (
          <div className="text-center py-16">
            <Loader2 className="mx-auto h-12 w-12 text-orange-500 animate-spin" />
            <p className="mt-4 text-gray-600">Loading your decks...</p>
          </div>
        )}

        {!isLoading && (
          <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {/* Create New Deck Card */}
            <Dialog open={isCreateOpen} onOpenChange={setCreateOpen}>
              <DialogTrigger asChild>
                <Card className="border-2 border-dashed border-orange-300 hover:border-orange-400 cursor-pointer transition-colors bg-orange-50/30 hover:bg-orange-50/50 flex items-center justify-center min-h-[280px]">
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <Plus className="w-12 h-12 text-orange-500 mb-3" />
                    <p className="font-semibold text-orange-600 text-center">Create New Deck</p>
                    <p className="text-sm text-orange-500/70 text-center mt-1">Generate AI study materials</p>
                  </CardContent>
                </Card>
              </DialogTrigger>
              <CreateDeckDialog onDeckCreated={() => setCreateOpen(false)} />
            </Dialog>

            {/* Existing Deck Cards */}
            {decks.map(deck => (
              <Card key={deck.id} className="flex flex-col hover:shadow-lg transition-shadow bg-white">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg font-semibold truncate">{deck.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-grow pb-3">
                  <div className="flex flex-wrap gap-2">
                    {deck.flashcards && (
                      <Badge variant="outline" className="text-xs flex items-center gap-1">
                        <Lightbulb className="w-3 h-3" />
                        {deck.flashcards.cards?.length || 0} Cards
                      </Badge>
                    )}
                    {deck.mindmap && (
                      <Badge variant="outline" className="text-xs flex items-center gap-1">
                        <Map className="w-3 h-3" />
                        Map
                      </Badge>
                    )}
                    {deck.summary && (
                      <Badge variant="outline" className="text-xs flex items-center gap-1">
                        <FileText className="w-3 h-3" />
                        Summary
                      </Badge>
                    )}
                    {!deck.flashcards && !deck.mindmap && !deck.summary && (
                      <Badge variant="outline" className="text-xs">Empty Deck</Badge>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="flex flex-col gap-2 pt-3 border-t">
                  <div className="flex gap-2 w-full">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" className="flex-1">
                          <Share2 className="w-4 h-4 mr-1" />
                          Share
                        </Button>
                      </DialogTrigger>
                      <ShareToGroupDialog deck={deck} onClose={() => {}} />
                    </Dialog>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button size="sm" className="flex-1 bg-black hover:bg-gray-800 text-white">
                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                      </DialogTrigger>
                      <ViewDeckDialog deck={deck} />
                    </Dialog>
                  </div>
                  <div className="flex gap-2 w-full">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => setSelectedDeckForStrive(deck)}
                    >
                      <MessageSquare className="w-4 h-4 mr-1" />
                      Ask Strive
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="sm" disabled={deleteMutation.isPending && deleteMutation.variables === deck.id}>
                          {deleteMutation.isPending && deleteMutation.variables === deck.id ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <Trash2 className="w-4 h-4 text-red-500" />
                          )}
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent className="backdrop-blur-2xl bg-white/80 border-white/20 shadow-2xl">
                        <AlertDialogHeader>
                          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                          <AlertDialogDescription>This action cannot be undone. This will permanently delete the deck.</AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => handleDeleteDeck(deck.id)}>Delete</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}

        {/* Empty state message, shown only if NO decks (apart from the 'create new deck' card itself) */}
        {!isLoading && !error && decks.length === 0 && (
            <div className="text-center py-16">
              <Layers className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <h3 className="text-xl font-semibold text-gray-700">No Decks Yet</h3>
              <p className="text-gray-500 mt-2">Click the "Create New Deck" card to generate your first study set.</p>
            </div>
        )}
      </div>

      {selectedDeckForStrive && (
        <StudyAgent
          deckContext={selectedDeckForStrive}
          onClose={() => setSelectedDeckForStrive(null)}
        />
      )}
    </div>
  );
}
